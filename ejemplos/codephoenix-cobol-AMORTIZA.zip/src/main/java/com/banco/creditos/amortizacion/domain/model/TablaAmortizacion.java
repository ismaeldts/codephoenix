package com.banco.creditos.amortizacion.domain.model;

import java.util.List;
import java.util.Objects;

/**
 * Filas de la tabla más los totales acumulados.
 */
// Regla R-16 · AMORTIZA.cbl:170-172
public record TablaAmortizacion(List<FilaAmortizacion> filas, TotalesCredito totales) {

    public TablaAmortizacion {
        Objects.requireNonNull(totales, "totales");
        filas = List.copyOf(filas);
    }
}
package com.banco.siniestros.liquidacion.application.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.siniestros.liquidacion.adapter.out.persistence.PagoSiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.PolizaRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.SiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.domain.exception.LiquidacionException;
import com.banco.siniestros.liquidacion.domain.model.EstadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.service.LiquidadorSiniestro;
import com.banco.siniestros.liquidacion.domain.service.PoliticaCarencia;
import com.banco.siniestros.liquidacion.domain.service.PoliticaTope;
import com.banco.siniestros.liquidacion.domain.specification.CarenciaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.ExclusionCausaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.PolizaNoVigenteSpecification;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LiquidarSiniestroServiceTest {

    private static final LocalDateTime INICIO = LocalDateTime.of(2023, 1, 1, 0, 0);
    private static final LocalDateTime JUNIO = LocalDateTime.of(2023, 6, 1, 0, 0);

    private SiniestroRepositoryEnMemoria siniestros;
    private PolizaRepositoryEnMemoria polizas;
    private PagoSiniestroRepositoryEnMemoria pagos;
    private LiquidarSiniestroService servicio;

    @BeforeEach
    void preparar() {
        siniestros = new SiniestroRepositoryEnMemoria();
        polizas = new PolizaRepositoryEnMemoria();
        pagos = new PagoSiniestroRepositoryEnMemoria();
        LiquidadorSiniestro liquidador = new LiquidadorSiniestro(
                List.of(new PolizaNoVigenteSpecification(),
                        new CarenciaSpecification(new PoliticaCarencia()),
                        new ExclusionCausaSpecification()),
                new PoliticaTope());
        servicio = new LiquidarSiniestroService(siniestros, polizas, pagos, liquidador);
    }

    private static String num(BigDecimal v) {
        return v.stripTrailingZeros().toPlainString();
    }

    private void poliza(long id, String producto, String estado, String deducible, String coaseguro) {
        polizas.agregar(new Poliza(id, producto, estado, INICIO, new BigDecimal("50000.00"),
                new BigDecimal(deducible), new BigDecimal(coaseguro)));
    }

    private void siniestro(long id, long polizaId, LocalDateTime fecha, String reclamado, String causa,
                           String estado, BigDecimal liquidado) {
        siniestros.agregar(new Siniestro(id, polizaId, fecha, new BigDecimal(reclamado), causa, estado, liquidado));
    }

    @Test
    @DisplayName("R-13 TC08 pago liquidado 4500 sin retención se registra y actualiza el siniestro")
    void liquidaYRegistraPago() {
        poliza(1004, "AUTO", "VIGENTE", "500.00", "0.00");
        siniestro(8, 1004, LocalDateTime.of(2023, 1, 31, 0, 0), "5000.00", "COLISION", "ABIERTO", null);

        ResultadoLiquidacion r = servicio.liquidar(8L);

        assertEquals(EstadoLiquidacion.LIQUIDADO, r.estado());
        assertEquals("4500", num(r.montoPagar()));
        List<PagoSiniestro> registrados = pagos.todos();
        assertEquals(1, registrados.size());
        assertEquals(8L, registrados.get(0).siniestroId());
        assertEquals("4500", num(registrados.get(0).monto()));
        assertEquals("0", num(registrados.get(0).retencion()));
        assertEquals("4500", num(registrados.get(0).neto()));
        Siniestro s = siniestros.todos().get(0);
        assertEquals("LIQUIDADO", s.estado());
        assertEquals("4500", num(s.montoLiquidado()));
    }

    @ParameterizedTest
    @DisplayName("R-12 retención solo si el pago supera 10000 (umbral estricto)")
    @CsvSource({
            "10000.00, 10000, 0, 10000",
            "10000.01, 10000.01, 250, 9750.01",
            "20000.00, 20000, 500, 19500"
    })
    void retencionPorUmbral(String reclamado, String monto, String retencion, String neto) {
        poliza(1, "AUTO", "VIGENTE", "0.00", "0.00");
        siniestro(1, 1, JUNIO, reclamado, "COLISION", "ABIERTO", null);

        ResultadoLiquidacion r = servicio.liquidar(1L);

        assertEquals(monto, num(r.montoPagar()));
        PagoSiniestro pago = pagos.todos().get(0);
        assertEquals(retencion, num(pago.retencion()));
        assertEquals(neto, num(pago.neto()));
    }

    @ParameterizedTest
    @DisplayName("R-05 R-08 TC05 TC06 TC11 TC12 rechazos actualizan el siniestro a RECHAZADO con monto 0 y sin pago")
    @CsvSource({
            "AUTO, SUSPENDIDA, COLISION",
            "HOGAR, CANCELADA, INCENDIO",
            "HOGAR, VIGENTE, GUERRA",
            "SALUD, VIGENTE, DOLO",
            "AUTO, VIGENTE, COMPETENCIA"
    })
    void rechazosActualizanSiniestro(String producto, String estadoPoliza, String causa) {
        poliza(10, producto, estadoPoliza, "500.00", "10.00");
        siniestro(5, 10, JUNIO, "5000.00", causa, "ABIERTO", null);

        ResultadoLiquidacion r = servicio.liquidar(5L);

        assertEquals(EstadoLiquidacion.RECHAZADO, r.estado());
        assertEquals("0", num(r.montoPagar()));
        assertTrue(pagos.todos().isEmpty());
        Siniestro s = siniestros.todos().get(0);
        assertEquals("RECHAZADO", s.estado());
        assertEquals("0", num(s.montoLiquidado()));
    }

    @Test
    @DisplayName("R-11 base cero queda SIN_PAGO, sin INSERT y con UPDATE")
    void sinPagoNoInsertaPago() {
        poliza(1, "AUTO", "VIGENTE", "500.00", "0.00");
        siniestro(1, 1, JUNIO, "400.00", "COLISION", "ABIERTO", null);

        ResultadoLiquidacion r = servicio.liquidar(1L);

        assertEquals(EstadoLiquidacion.SIN_PAGO, r.estado());
        assertTrue(pagos.todos().isEmpty());
        Siniestro s = siniestros.todos().get(0);
        assertEquals("SIN_PAGO", s.estado());
        assertEquals("0", num(s.montoLiquidado()));
    }

    @Test
    @DisplayName("R-01 TC01 siniestro inexistente lanza -20010 y no modifica tablas")
    void siniestroNoExiste() {
        poliza(1001, "AUTO", "VIGENTE", "500.00", "10.00");
        siniestro(1, 1001, JUNIO, "5000.00", "COLISION", "ABIERTO", null);

        LiquidacionException e = assertThrows(LiquidacionException.class, () -> servicio.liquidar(999L));

        assertEquals(-20010, e.sqlCode());
        assertEquals("SINIESTRO NO EXISTE", e.getMessage());
        assertEquals("ABIERTO", siniestros.todos().get(0).estado());
        assertNull(siniestros.todos().get(0).montoLiquidado());
        assertTrue(pagos.todos().isEmpty());
    }

    @Test
    @DisplayName("R-01 parámetro NULL equivale a siniestro inexistente")
    void idNuloNoExiste() {
        LiquidacionException e = assertThrows(LiquidacionException.class, () -> servicio.liquidar(null));
        assertEquals(-20010, e.sqlCode());
    }

    @ParameterizedTest
    @DisplayName("R-02 TC02 TC03 estado distinto de ABIERTO falla con -20011 antes de leer la póliza")
    @CsvSource({"LIQUIDADO, 4000.00", "RECHAZADO, 0.00"})
    void siniestroYaProcesado(String estado, String liquidado) {
        siniestro(2, 7777, JUNIO, "5000.00", "COLISION", estado, new BigDecimal(liquidado));

        LiquidacionException e = assertThrows(LiquidacionException.class, () -> servicio.liquidar(2L));

        assertEquals(-20011, e.sqlCode());
        assertEquals("SINIESTRO YA PROCESADO", e.getMessage());
        Siniestro s = siniestros.todos().get(0);
        assertEquals(estado, s.estado());
        assertEquals(num(new BigDecimal(liquidado)), num(s.montoLiquidado()));
    }

    @Test
    @DisplayName("R-03 póliza inexistente propaga NO_DATA_FOUND (100) sin actualizar nada")
    void polizaNoExiste() {
        siniestro(3, 5555, JUNIO, "5000.00", "COLISION", "ABIERTO", null);

        LiquidacionException e = assertThrows(LiquidacionException.class, () -> servicio.liquidar(3L));

        assertEquals(100, e.sqlCode());
        assertEquals("no data found", e.getMessage());
        assertEquals("ABIERTO", siniestros.todos().get(0).estado());
        assertNull(siniestros.todos().get(0).montoLiquidado());
        assertTrue(pagos.todos().isEmpty());
    }
}
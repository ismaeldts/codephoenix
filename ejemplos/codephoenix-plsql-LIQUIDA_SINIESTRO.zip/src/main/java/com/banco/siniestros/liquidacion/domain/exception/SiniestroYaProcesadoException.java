package com.banco.siniestros.liquidacion.domain.exception;

// Regla R-02 · LIQUIDA_SINIESTRO.sql:66-68
public final class SiniestroYaProcesadoException extends LiquidacionException {

    public SiniestroYaProcesadoException() {
        super("E02", -20011, "SINIESTRO YA PROCESADO");
    }
}
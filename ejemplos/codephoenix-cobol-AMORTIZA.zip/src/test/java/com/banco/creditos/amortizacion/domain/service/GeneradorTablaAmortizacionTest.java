package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.TablaAmortizacion;
import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class GeneradorTablaAmortizacionTest {

    private final GeneradorTablaAmortizacion generador = new GeneradorTablaAmortizacion();
    private static final BigDecimal TASA_MENSUAL = new BigDecimal("0.0150000000");

    private static void assertFila(FilaAmortizacion f, int periodo, String cuota, String interes,
            String amortizacion, String seguro, String total, String saldo) {
        assertEquals(periodo, f.periodo());
        assertEquals(cuota, f.cuota().toPlainString());
        assertEquals(interes, f.interes().toPlainString());
        assertEquals(amortizacion, f.amortizacion().toPlainString());
        assertEquals(seguro, f.seguro().toPlainString());
        assertEquals(total, f.total().toPlainString());
        assertEquals(saldo, f.saldo().toPlainString());
    }

    @Test
    @DisplayName("R-12 R-13 R-14 R-15 R-16 tabla TC06 (monto 1000, plazo 6)")
    void tablaTc06() {
        TablaAmortizacion t = generador.generar(
                new BigDecimal("1000.00"), 6, TASA_MENSUAL, new BigDecimal("175.53"));
        assertEquals(6, t.filas().size());
        assertFila(t.filas().get(0), 1, "175.53", "15.00", "160.53", "0.45", "175.98", "839.47");
        assertFila(t.filas().get(1), 2, "175.53", "12.59", "162.94", "0.38", "175.91", "676.53");
        assertFila(t.filas().get(5), 6, "175.50", "2.59", "172.91", "0.08", "175.58", "0.00");
        assertEquals("53.15", t.totales().interes().toPlainString());
        assertEquals("1.59", t.totales().seguro().toPlainString());
        assertEquals("1054.74", t.totales().pagado().toPlainString());
    }

    @Test
    @DisplayName("R-14 R-16 tabla TC01 (monto 10000, plazo 12)")
    void tablaTc01() {
        TablaAmortizacion t = generador.generar(
                new BigDecimal("10000.00"), 12, TASA_MENSUAL, new BigDecimal("916.80"));
        assertEquals(12, t.filas().size());
        assertFila(t.filas().get(0), 1, "916.80", "150.00", "766.80", "4.50", "921.30", "9233.20");
        assertFila(t.filas().get(2), 3, "916.80", "126.82", "789.98", "3.80", "920.60", "7664.92");
        assertFila(t.filas().get(11), 12, "916.81", "13.55", "903.26", "0.41", "917.22", "0.00");
        assertEquals("1001.61", t.totales().interes().toPlainString());
        assertEquals("30.04", t.totales().seguro().toPlainString());
        assertEquals("11031.65", t.totales().pagado().toPlainString());
    }
}
package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ResultadoSimulacionTest {

    @Test
    @DisplayName("R-01 resultado rechazado conserva el código de error y no trae tabla")
    void rechazada() {
        ResultadoSimulacion r = ResultadoSimulacion.rechazada(CodigoError.E01);
        assertTrue(r.rechazada());
        assertEquals(CodigoError.E01, r.error());
        assertEquals(0, r.plazo());
        assertNull(r.cuotaFija());
        assertTrue(r.filas().isEmpty());
    }

    @Test
    @DisplayName("R-01 rechazar con error nulo lanza NullPointerException")
    void rechazadaNula() {
        assertThrows(NullPointerException.class, () -> ResultadoSimulacion.rechazada(null));
    }

    @Test
    @DisplayName("R-16 resultado exitoso expone tasa, plazo, cuota y totales")
    void exitosa() {
        TotalesCredito totales = new TotalesCredito(
                new BigDecimal("53.15"), new BigDecimal("1.59"), new BigDecimal("1054.74"));
        TablaAmortizacion tabla = new TablaAmortizacion(List.of(), totales);
        ResultadoSimulacion r = ResultadoSimulacion.exitosa(
                new BigDecimal("18.0000"), 6, new BigDecimal("175.53"), tabla);
        assertFalse(r.rechazada());
        assertNull(r.error());
        assertEquals("18.0000", r.tasaEfectiva().toPlainString());
        assertEquals(6, r.plazo());
        assertEquals("175.53", r.cuotaFija().toPlainString());
        assertEquals("1054.74", r.totales().pagado().toPlainString());
    }

    @Test
    @DisplayName("R-16 sin error los campos obligatorios no pueden ser nulos")
    void exitosoRequiereCampos() {
        assertThrows(NullPointerException.class,
                () -> new ResultadoSimulacion(null, null, 6, BigDecimal.ONE, null, null));
        assertThrows(NullPointerException.class,
                () -> new ResultadoSimulacion(null, BigDecimal.ONE, 6, null, null, null));
        assertThrows(NullPointerException.class,
                () -> new ResultadoSimulacion(null, BigDecimal.ONE, 6, BigDecimal.ONE, null, null));
    }

    @Test
    @DisplayName("R-01 filas nulas se convierten en lista vacía")
    void filasNulas() {
        ResultadoSimulacion r = new ResultadoSimulacion(CodigoError.E00, null, 0, null, null, null);
        assertTrue(r.filas().isEmpty());
    }
}
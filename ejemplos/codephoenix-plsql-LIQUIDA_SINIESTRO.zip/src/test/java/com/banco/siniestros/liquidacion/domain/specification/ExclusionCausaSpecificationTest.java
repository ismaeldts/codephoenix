package com.banco.siniestros.liquidacion.domain.specification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class ExclusionCausaSpecificationTest {

    private final ExclusionCausaSpecification spec = new ExclusionCausaSpecification();

    private static Poliza poliza(String producto) {
        return new Poliza(1006L, producto, "VIGENTE", LocalDateTime.of(2022, 1, 1, 0, 0),
                new BigDecimal("80000"), BigDecimal.ZERO, BigDecimal.ZERO);
    }

    private static Siniestro siniestro(String causa) {
        return new Siniestro(11L, 1006L, LocalDateTime.of(2023, 6, 1, 0, 0),
                new BigDecimal("9000"), causa, "ABIERTO", null);
    }

    @DisplayName("R-08 GUERRA y DOLO se excluyen siempre; COMPETENCIA solo en AUTO")
    @ParameterizedTest
    @CsvSource({
            "HOGAR,GUERRA,true",
            "SALUD,DOLO,true",
            "AUTO,GUERRA,true",
            "AUTO,COMPETENCIA,true",
            "HOGAR,COMPETENCIA,false",
            "SALUD,COMPETENCIA,false",
            "AUTO,COLISION,false",
            "HOGAR,INCENDIO,false"
    })
    void exclusiones(String producto, String causa, boolean esperado) {
        assertEquals(esperado, spec.seRechaza(siniestro(causa), poliza(producto)));
    }

    @DisplayName("R-08 causa NULL no se excluye")
    @Test
    void causaNula() {
        assertFalse(spec.seRechaza(siniestro(null), poliza("AUTO")));
    }
}
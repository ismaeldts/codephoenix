# Reporte de calidad estática

| Métrica | Valor | Umbral |
|---|---|---|
| Archivos analizados | 19 | - |
| Líneas de código | 661 | - |
| Hallazgos bloqueantes | 0 | 0 |
| Hallazgos críticos | 0 | 0 |
| Complejidad ciclomática máxima por método | 4 | ≤ 10 |

Reglas verificadas: precisión decimal (sin double/float en el núcleo), BigDecimal desde cadena, dependencias hexagonales, secretos en código, catch vacíos, printStackTrace, complejidad.

Sin hallazgos.

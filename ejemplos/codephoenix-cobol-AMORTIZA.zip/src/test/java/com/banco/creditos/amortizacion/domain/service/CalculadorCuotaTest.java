package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.creditos.amortizacion.domain.model.CuotaFrancesa;
import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class CalculadorCuotaTest {

    private final CalculadorCuota calculador = new CalculadorCuota();

    @ParameterizedTest
    @CsvSource({
        "10000.00,12,18.0000,0.0150000000,916.80",
        "1000.00,6,18.0000,0.0150000000,175.53"
    })
    @DisplayName("R-09 R-11 cuota francesa según Golden Master TC01 y TC06")
    void cuotaGoldenMaster(String monto, int plazo, String tasa, String tasaMensual, String cuota) {
        CuotaFrancesa c = calculador.calcular(new BigDecimal(monto), plazo, new BigDecimal(tasa));
        assertEquals(tasaMensual, c.tasaMensual().toPlainString());
        assertEquals(cuota, c.cuotaFija().toPlainString());
    }

    @Test
    @DisplayName("R-09 la tasa mensual se trunca a 10 decimales")
    void tasaMensualTruncada() {
        assertEquals("0.0008333333", calculador.tasaMensual(new BigDecimal("1.0000")).toPlainString());
    }

    @Test
    @DisplayName("R-10 el factor se capitaliza truncando en cada iteración")
    void factor() {
        BigDecimal i = new BigDecimal("0.0150000000");
        assertEquals("1.0000000000", calculador.factorCapitalizacion(i, 0).toPlainString());
        assertEquals("1.0150000000", calculador.factorCapitalizacion(i, 1).toPlainString());
        assertEquals("1.0302250000", calculador.factorCapitalizacion(i, 2).toPlainString());
    }

    @Test
    @DisplayName("R-11 factor igual a 1 (división por cero) deja la cuota en cero")
    void divisionPorCero() {
        BigDecimal cuota = calculador.cuotaFija(
                new BigDecimal("1000.00"), BigDecimal.ZERO, new BigDecimal("1.0000000000"));
        assertEquals("0.00", cuota.toPlainString());
    }
}
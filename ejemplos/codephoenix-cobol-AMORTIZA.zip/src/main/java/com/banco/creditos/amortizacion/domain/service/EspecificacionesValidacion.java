package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.math.BigDecimal;
import java.util.List;
import java.util.function.Predicate;

/**
 * Specifications de admisibilidad, en el orden exacto de 1000-VALIDAR.
 */
public final class EspecificacionesValidacion {

    private static final BigDecimal MONTO_MINIMO = new BigDecimal("1000.00");
    private static final BigDecimal MONTO_MAXIMO = new BigDecimal("500000000.00");
    private static final int PLAZO_MINIMO = 6;
    private static final int PLAZO_MAXIMO = 360;
    private static final int SCORE_MINIMO = 550;

    /** Una especificación: si la condición de rechazo se cumple, devuelve su código. */
    public record Especificacion(CodigoError codigo, Predicate<SolicitudCredito> condicionRechazo) {

        public boolean rechaza(SolicitudCredito solicitud) {
            return condicionRechazo.test(solicitud);
        }
    }

    private static final List<Especificacion> EN_ORDEN = List.of(
            new Especificacion(CodigoError.E01, EspecificacionesValidacion::montoFueraDeRango),
            new Especificacion(CodigoError.E02, EspecificacionesValidacion::plazoFueraDeRango),
            new Especificacion(CodigoError.E03, EspecificacionesValidacion::scoreInsuficiente),
            new Especificacion(CodigoError.E04, EspecificacionesValidacion::tasaAnualCero));

    private EspecificacionesValidacion() {
    }

    public static List<Especificacion> enOrden() {
        return EN_ORDEN;
    }

    // Regla R-02 · AMORTIZA.cbl:95-99
    static boolean montoFueraDeRango(SolicitudCredito s) {
        return s.monto().compareTo(MONTO_MINIMO) < 0 || s.monto().compareTo(MONTO_MAXIMO) > 0;
    }

    // Regla R-03 · AMORTIZA.cbl:100-104
    static boolean plazoFueraDeRango(SolicitudCredito s) {
        return s.plazo() < PLAZO_MINIMO || s.plazo() > PLAZO_MAXIMO;
    }

    // Regla R-04 · AMORTIZA.cbl:105-109
    static boolean scoreInsuficiente(SolicitudCredito s) {
        return s.score() < SCORE_MINIMO;
    }

    // Regla R-05 · AMORTIZA.cbl:110-113
    static boolean tasaAnualCero(SolicitudCredito s) {
        return s.tasaAnual().signum() == 0;
    }
}
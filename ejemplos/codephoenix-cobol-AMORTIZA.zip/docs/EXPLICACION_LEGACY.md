# Explicación del programa legacy

### Propósito
Calcula la tabla de amortización de un crédito de consumo con el sistema francés (cuota fija). Ajusta la tasa según el score crediticio, aplica un tope de usura y añade un seguro de desgravamen mensual.

### Entradas y salidas
**Entrada** (`ACCEPT`, 24 posiciones con decimales implícitos): monto, tasa anual nominal (%), plazo en meses y score.

**Salidas** (`DISPLAY`, separadas por `|`):
- `ERR|código|mensaje` si la validación falla.
- `HDR|` con tasa efectiva, plazo y cuota.
- `DET|` por cada periodo, con cuota, interés, amortización, seguro, total y saldo.
- `TOT|` con totales de interés, seguro y pagado.

### Flujo principal
1. Valida: registro numérico (E00), monto entre 1.000 y 500.000.000 (E01), plazo de 6 a 360 (E02), score ≥ 550 (E03) y tasa distinta de cero (E04).
2. Ajusta la tasa: score ≥ 750 resta 1,5 puntos (mínimo 5); 650–749 sin cambio; menor de 650 suma 2. Después aplica el tope de 36 %.
3. Calcula la tasa mensual (tasa/1200) y la cuota con el factor (1+i)^n, que se obtiene por multiplicación repetida.
4. Genera la tabla: interés y seguro sobre el saldo; en el último periodo la amortización es el saldo restante.
5. Muestra los totales.

### Puntos de atención para la migración
- **Precisión:** `WS-TASA-MENSUAL` tiene 10 decimales y `WS-FACTOR` se trunca a 10 decimales en cada multiplicación (sin `ROUNDED`). Usar `BigDecimal` con escala 10 y truncamiento (`RoundingMode.DOWN`) en esos pasos; `HALF_UP` solo donde hay `ROUNDED` (cuota, interés, seguro).
- **Cuota final:** el último periodo absorbe las diferencias de redondeo, por lo que su cuota difiere de la fija.
- **Reglas tácitas:** el seguro (0,045 %) se calcula sobre el saldo y no forma parte de la cuota base. El piso de 5 % solo aplica en el descuento por score alto. La suma de 2 puntos no se limita salvo por la usura.
- **Validación:** las validaciones usan `GO TO` y se detienen en el primer error. E04 es la última comprobación.
- **Código muerto:** `9000-CALCULAR-MORA` (2,5 % sobre la cuota) no se invoca desde 2009; no migrar salvo confirmación de negocio.
- **Formatos:** los campos editados (`ZZ9.9999`) determinan la salida; replicar el formato exacto.
package com.banco.siniestros.liquidacion.adapter.in.cli;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Entrada interpretada: parámetros PARAM y filas ROW del contrato de caracterización. */
final class EntradaCaracterizacion {

    /** Fila inicial de una tabla con sus columnas en bruto. */
    record Fila(String tabla, Map<String, String> columnas) {
    }

    private final Map<String, String> parametros = new HashMap<>();
    private final List<Fila> filas = new ArrayList<>();

    static EntradaCaracterizacion leer(List<String> lineas) {
        EntradaCaracterizacion entrada = new EntradaCaracterizacion();
        for (String linea : lineas) {
            entrada.interpretar(linea);
        }
        return entrada;
    }

    private void interpretar(String lineaCruda) {
        String linea = quitarRetorno(lineaCruda);
        String[] partes = linea.split("\\|", -1);
        if (partes.length >= 3 && "PARAM".equals(partes[0])) {
            parametros.put(partes[1], partes[2]);
        } else if (partes.length >= 2 && "ROW".equals(partes[0])) {
            filas.add(new Fila(partes[1], columnas(partes)));
        }
    }

    private static String quitarRetorno(String linea) {
        return linea.endsWith("\r") ? linea.substring(0, linea.length() - 1) : linea;
    }

    private static Map<String, String> columnas(String[] partes) {
        Map<String, String> columnas = new LinkedHashMap<>();
        for (int i = 2; i < partes.length; i++) {
            int igual = partes[i].indexOf('=');
            if (igual > 0) {
                columnas.put(partes[i].substring(0, igual), partes[i].substring(igual + 1));
            }
        }
        return columnas;
    }

    /** Un parámetro ausente es NULL. */
    String parametro(String nombre) {
        return parametros.get(nombre);
    }

    List<Fila> filas() {
        return filas;
    }
}
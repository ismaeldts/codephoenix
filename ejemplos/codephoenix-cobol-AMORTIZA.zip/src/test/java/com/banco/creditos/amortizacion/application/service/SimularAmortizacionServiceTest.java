package com.banco.creditos.amortizacion.application.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.service.CalculadorCuota;
import com.banco.creditos.amortizacion.domain.service.CalculadorTasaEfectiva;
import com.banco.creditos.amortizacion.domain.service.GeneradorTablaAmortizacion;
import com.banco.creditos.amortizacion.domain.service.ValidadorSolicitud;
import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class SimularAmortizacionServiceTest {

    private final SimularAmortizacionService servicio = new SimularAmortizacionService(
            new ValidadorSolicitud(),
            new CalculadorTasaEfectiva(),
            new CalculadorCuota(),
            new GeneradorTablaAmortizacion());

    private static SolicitudCredito solicitud(String monto, String tasa, int plazo, int score) {
        return new SolicitudCredito(new BigDecimal(monto), new BigDecimal(tasa), plazo, score);
    }

    @Test
    @DisplayName("R-11 TC01 caso nominal: cabecera, primera y última fila y totales")
    void caso_nominal() {
        ResultadoSimulacion r = servicio.simular(solicitud("10000.00", "18.0000", 12, 700));

        assertFalse(r.rechazada());
        assertNull(r.error());
        assertEquals(new BigDecimal("18.0000"), r.tasaEfectiva());
        assertEquals(12, r.plazo());
        assertEquals(new BigDecimal("916.80"), r.cuotaFija());
        assertEquals(12, r.filas().size());

        FilaAmortizacion primera = r.filas().get(0);
        assertEquals(1, primera.periodo());
        assertEquals(new BigDecimal("916.80"), primera.cuota());
        assertEquals(new BigDecimal("150.00"), primera.interes());
        assertEquals(new BigDecimal("766.80"), primera.amortizacion());
        assertEquals(new BigDecimal("4.50"), primera.seguro());
        assertEquals(new BigDecimal("921.30"), primera.total());
        assertEquals(new BigDecimal("9233.20"), primera.saldo());

        FilaAmortizacion ultima = r.filas().get(11);
        assertEquals(new BigDecimal("916.81"), ultima.cuota());
        assertEquals(new BigDecimal("13.55"), ultima.interes());
        assertEquals(new BigDecimal("903.26"), ultima.amortizacion());
        assertEquals(new BigDecimal("0.41"), ultima.seguro());
        assertEquals(new BigDecimal("917.22"), ultima.total());
        assertEquals(new BigDecimal("0.00"), ultima.saldo());

        assertEquals(new BigDecimal("1001.61"), r.totales().interes());
        assertEquals(new BigDecimal("30.04"), r.totales().seguro());
        assertEquals(new BigDecimal("11031.65"), r.totales().pagado());
    }

    @Test
    @DisplayName("R-14 TC06 borde mínimo: última cuota ajustada y totales")
    void caso_borde_minimo() {
        ResultadoSimulacion r = servicio.simular(solicitud("1000.00", "18.0000", 6, 700));

        assertFalse(r.rechazada());
        assertEquals(new BigDecimal("175.53"), r.cuotaFija());
        assertEquals(6, r.filas().size());
        FilaAmortizacion ultima = r.filas().get(5);
        assertEquals(new BigDecimal("175.50"), ultima.cuota());
        assertEquals(new BigDecimal("172.91"), ultima.amortizacion());
        assertEquals(new BigDecimal("0.00"), ultima.saldo());
        assertEquals(new BigDecimal("53.15"), r.totales().interes());
        assertEquals(new BigDecimal("1.59"), r.totales().seguro());
        assertEquals(new BigDecimal("1054.74"), r.totales().pagado());
    }

    @ParameterizedTest(name = "{0} -> {4}")
    @DisplayName("R-02 R-03 R-04 R-05 rechazos de validación con su código")
    @CsvSource({
        "999.99,18.0000,12,700,E01",
        "500000000.01,18.0000,12,700,E01",
        "10000.00,18.0000,5,700,E02",
        "10000.00,18.0000,361,700,E02",
        "10000.00,18.0000,12,549,E03",
        "10000.00,0.0000,12,700,E04"
    })
    void rechazos(String monto, String tasa, int plazo, int score, CodigoError esperado) {
        ResultadoSimulacion r = servicio.simular(solicitud(monto, tasa, plazo, score));

        assertTrue(r.rechazada());
        assertEquals(esperado, r.error());
        assertTrue(r.filas().isEmpty());
    }

    @Test
    @DisplayName("R-02 el primer fallo manda: monto y plazo inválidos devuelven E01")
    void orden_de_validaciones() {
        ResultadoSimulacion r = servicio.simular(solicitud("999.99", "0.0000", 5, 100));

        assertEquals(CodigoError.E01, r.error());
    }

    @Test
    @DisplayName("R-01 el servicio exige todas sus dependencias")
    void dependencias_obligatorias() {
        ValidadorSolicitud v = new ValidadorSolicitud();
        CalculadorTasaEfectiva t = new CalculadorTasaEfectiva();
        CalculadorCuota c = new CalculadorCuota();
        GeneradorTablaAmortizacion g = new GeneradorTablaAmortizacion();

        assertThrows(NullPointerException.class, () -> new SimularAmortizacionService(null, t, c, g));
        assertThrows(NullPointerException.class, () -> new SimularAmortizacionService(v, null, c, g));
        assertThrows(NullPointerException.class, () -> new SimularAmortizacionService(v, t, null, g));
        assertThrows(NullPointerException.class, () -> new SimularAmortizacionService(v, t, c, null));
    }
}
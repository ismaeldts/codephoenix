package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CuotaFrancesaTest {

    private static final BigDecimal TASA_MENSUAL = new BigDecimal("0.0150000000");
    private static final BigDecimal CUOTA = new BigDecimal("916.80");

    @Test
    @DisplayName("R-09 · TC01 conserva tasa mensual 0.0150000000 y cuota fija 916.80")
    void conservaTasaYCuota() {
        CuotaFrancesa cuota = new CuotaFrancesa(TASA_MENSUAL, CUOTA);

        assertEquals(TASA_MENSUAL, cuota.tasaMensual());
        assertEquals(CUOTA, cuota.cuotaFija());
    }

    @Test
    @DisplayName("R-11 · tasa mensual o cuota nulas se rechazan")
    void rechazaNulos() {
        assertThrows(NullPointerException.class, () -> new CuotaFrancesa(null, CUOTA));
        assertThrows(NullPointerException.class, () -> new CuotaFrancesa(TASA_MENSUAL, null));
    }
}
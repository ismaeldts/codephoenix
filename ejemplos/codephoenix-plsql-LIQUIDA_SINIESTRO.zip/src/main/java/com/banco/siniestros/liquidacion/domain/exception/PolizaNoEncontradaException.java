package com.banco.siniestros.liquidacion.domain.exception;

// Regla R-03 · LIQUIDA_SINIESTRO.sql:70-70
// Equivale a NO_DATA_FOUND (SQLCODE 100, mensaje 'no data found') sin tratamiento.
public final class PolizaNoEncontradaException extends LiquidacionException {

    public PolizaNoEncontradaException() {
        super("E03", 100, "no data found");
    }
}
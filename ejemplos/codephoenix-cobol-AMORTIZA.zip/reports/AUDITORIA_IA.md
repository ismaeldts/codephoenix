# Auditoría de uso de IA

Todo el código enviado al modelo se enmascaró previamente (4 datos sensibles detectados). Se registra el hash SHA-256 de cada prompt, no su contenido.

| Fecha | Agente | Modelo | Hash del prompt | Tokens entrada | Tokens salida | Duración | Resultado |
|---|---|---|---|---|---|---|---|
| 2026-11-13 19:11:51 | Analista | claude-sonnet-5-5 | `dabed6979cb08a83…` | 7942 | 1010 | 8.829 s | OK |
| 2026-11-13 19:12:25 | Extractor de reglas | claude-sonnet-5-5 | `71af0da61988d5f7…` | 12485 | 5945 | 34.199 s | OK |
| 2026-11-13 19:12:50 | Arquitecto | claude-sonnet-5-5 | `823e81b6add03bd2…` | 6829 | 3840 | 22.317 s | OK |
| 2026-11-13 19:13:05 | QA/Tester | claude-sonnet-5-5 | `ed4b2832bfa69db0…` | 9860 | 2873 | 15.801 s | OK |
| 2026-11-13 19:15:43 | Desarrollador | claude-sonnet-5-5 | `410948dcffe78c5e…` | 14807 | 23440 | 156.201 s | OK |
| 2026-11-13 19:16:28 | QA/Tester (pruebas dominio 1) | claude-sonnet-5-5 | `a9ae6d5f95018dd2…` | 22901 | 6732 | 34.58 s | OK |
| 2026-11-13 19:16:43 | QA/Tester (pruebas aplicación y adaptadores) | claude-sonnet-5-5 | `cd1884b094d2d307…` | 22815 | 9074 | 49.444 s | OK |
| 2026-11-13 19:16:49 | QA/Tester (pruebas dominio 2) | claude-sonnet-5-5 | `bae342a0dbdbbd72…` | 22959 | 10598 | 55.583 s | OK |
| 2026-11-13 19:17:37 | QA/Tester (escenarios BDD) | claude-sonnet-5-5 | `67297c50374c7f13…` | 23203 | 17622 | 102.918 s | OK |
| 2026-11-13 19:17:56 | Documentador | claude-sonnet-5-5 | `3d338a745c91d94d…` | 1762 | 1088 | 7.487 s | OK |

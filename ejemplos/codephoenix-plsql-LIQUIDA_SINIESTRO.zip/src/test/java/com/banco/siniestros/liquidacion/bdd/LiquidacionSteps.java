package com.banco.siniestros.liquidacion.bdd;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.siniestros.liquidacion.adapter.out.persistence.PagoSiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.PolizaRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.SiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.application.service.LiquidarSiniestroService;
import com.banco.siniestros.liquidacion.domain.exception.LiquidacionException;
import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.service.LiquidadorSiniestro;
import com.banco.siniestros.liquidacion.domain.service.PoliticaCarencia;
import com.banco.siniestros.liquidacion.domain.service.PoliticaTope;
import com.banco.siniestros.liquidacion.domain.specification.CarenciaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.ExclusionCausaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.PolizaNoVigenteSpecification;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class LiquidacionSteps {

    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final PolizaRepositoryEnMemoria polizas = new PolizaRepositoryEnMemoria();
    private final SiniestroRepositoryEnMemoria siniestros = new SiniestroRepositoryEnMemoria();
    private final PagoSiniestroRepositoryEnMemoria pagos = new PagoSiniestroRepositoryEnMemoria();

    private ResultadoLiquidacion resultado;
    private LiquidacionException error;

    private static LocalDateTime fecha(String texto) {
        if (texto.length() == 10) {
            return LocalDate.parse(texto).atStartOfDay();
        }
        return LocalDateTime.parse(texto, FORMATO);
    }

    private static void assertImporte(String esperado, BigDecimal real) {
        assertNotNull(real);
        assertEquals(0, new BigDecimal(esperado).compareTo(real),
                "esperado " + esperado + " pero fue " + real.toPlainString());
    }

    @Dado("una póliza {int} de producto {string} en estado {string} que inició el {string} con suma asegurada de {string}, deducible de {string} y coaseguro de {string}%")
    public void unaPoliza(int id, String producto, String estado, String inicio, String suma,
                          String deducible, String coaseguro) {
        polizas.agregar(new Poliza(id, producto, estado, fecha(inicio), new BigDecimal(suma),
                new BigDecimal(deducible), new BigDecimal(coaseguro)));
    }

    @Dado("un siniestro {int} de la póliza {int} ocurrido el {string} por un monto reclamado de {string} con causa {string} y estado {string}")
    public void unSiniestro(int id, int polizaId, String ocurrencia, String reclamado, String causa,
                            String estado) {
        siniestros.agregar(new Siniestro(id, polizaId, fecha(ocurrencia), new BigDecimal(reclamado),
                causa, estado, estado.equals("ABIERTO") ? null : BigDecimal.ZERO));
    }

    @Cuando("se liquida el siniestro {int}")
    public void seLiquida(int id) {
        LiquidadorSiniestro liquidador = new LiquidadorSiniestro(
                List.of(new PolizaNoVigenteSpecification(),
                        new CarenciaSpecification(new PoliticaCarencia()),
                        new ExclusionCausaSpecification()),
                new PoliticaTope());
        LiquidarSiniestroService servicio =
                new LiquidarSiniestroService(siniestros, polizas, pagos, liquidador);
        try {
            resultado = servicio.liquidar((long) id);
        } catch (LiquidacionException e) {
            error = e;
        }
    }

    @Entonces("la liquidación falla con código {int} y mensaje {string}")
    public void laLiquidacionFalla(int codigo, String mensaje) {
        assertNotNull(error, "se esperaba un error de negocio");
        assertEquals(codigo, error.sqlCode());
        assertEquals(mensaje, error.getMessage());
    }

    @Entonces("el resultado es estado {string} con monto a pagar {string}")
    public void elResultadoEs(String estado, String monto) {
        assertNull(error, "no se esperaba error");
        assertNotNull(resultado);
        assertEquals(estado, resultado.estado().name());
        assertImporte(monto, resultado.montoPagar());
    }

    @Entonces("no se registra ningún pago")
    public void noSeRegistraPago() {
        assertTrue(pagos.todos().isEmpty());
    }

    @Entonces("se registra para el siniestro {int} un pago de monto {string}, retención {string} y neto {string}")
    public void seRegistraPago(int id, String monto, String retencion, String neto) {
        PagoSiniestro pago = pagos.todos().stream()
                .filter(p -> p.siniestroId() == id).findFirst().orElse(null);
        assertNotNull(pago, "no se registró el pago");
        assertImporte(monto, pago.monto());
        assertImporte(retencion, pago.retencion());
        assertImporte(neto, pago.neto());
    }

    @Entonces("el siniestro {int} queda en estado {string} con monto liquidado {string}")
    public void siniestroConMonto(int id, String estado, String monto) {
        Siniestro s = siniestros.buscarPorId((long) id).orElseThrow();
        assertEquals(estado, s.estado());
        assertImporte(monto, s.montoLiquidado());
    }

    @Entonces("el siniestro {int} queda en estado {string} sin monto liquidado")
    public void siniestroSinMonto(int id, String estado) {
        Siniestro s = siniestros.buscarPorId((long) id).orElseThrow();
        assertEquals(estado, s.estado());
        assertNull(s.montoLiquidado());
    }
}
package com.banco.siniestros.liquidacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PagoSiniestroTest {

    @ParameterizedTest
    @CsvSource({
            "8,4500,0,4500.00,0.00,4500.00",
            "9,12000,300,12000.00,300.00,11700.00"
    })
    @DisplayName("R-13 el pago se registra con neto = monto - retención y escala 2")
    void desdeResultado(long id, String monto, String retencion, String montoEsp, String retEsp, String netoEsp) {
        ResultadoLiquidacion r = ResultadoLiquidacion.liquidado(new BigDecimal(monto), new BigDecimal(retencion));
        PagoSiniestro pago = PagoSiniestro.desde(id, r);
        assertEquals(id, pago.siniestroId());
        assertEquals(new BigDecimal(montoEsp), pago.monto());
        assertEquals(new BigDecimal(retEsp), pago.retencion());
        assertEquals(new BigDecimal(netoEsp), pago.neto());
    }

    @Test
    @DisplayName("R-13 los importes se redondean HALF_UP a 2 decimales al asignar")
    void redondeaHalfUp() {
        PagoSiniestro pago = new PagoSiniestro(1, new BigDecimal("1.005"), new BigDecimal("0.004"),
                new BigDecimal("1.001"));
        assertEquals(new BigDecimal("1.01"), pago.monto());
        assertEquals(new BigDecimal("0.00"), pago.retencion());
        assertEquals(new BigDecimal("1.00"), pago.neto());
    }

    @Test
    @DisplayName("R-13 los importes nulos se rechazan")
    void rechazaNulos() {
        BigDecimal uno = BigDecimal.ONE;
        assertThrows(NullPointerException.class, () -> new PagoSiniestro(1, null, uno, uno));
        assertThrows(NullPointerException.class, () -> new PagoSiniestro(1, uno, null, uno));
        assertThrows(NullPointerException.class, () -> new PagoSiniestro(1, uno, uno, null));
    }
}
package com.banco.creditos.amortizacion.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Detalle de un periodo de la tabla de amortización.
 * Amortización y saldo conservan el signo (campos S9 del legacy); el resto es sin signo.
 */
// Regla R-12 · AMORTIZA.cbl:158-158
// Regla R-15 · AMORTIZA.cbl:168-169
public record FilaAmortizacion(
        int periodo,
        BigDecimal cuota,
        BigDecimal interes,
        BigDecimal amortizacion,
        BigDecimal seguro,
        BigDecimal total,
        BigDecimal saldo) {

    public FilaAmortizacion {
        Objects.requireNonNull(cuota, "cuota");
        Objects.requireNonNull(interes, "interes");
        Objects.requireNonNull(amortizacion, "amortizacion");
        Objects.requireNonNull(seguro, "seguro");
        Objects.requireNonNull(total, "total");
        Objects.requireNonNull(saldo, "saldo");
    }
}
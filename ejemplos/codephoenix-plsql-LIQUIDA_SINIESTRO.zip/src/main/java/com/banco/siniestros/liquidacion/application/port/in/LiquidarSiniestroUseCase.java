package com.banco.siniestros.liquidacion.application.port.in;

import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;

/** Puerto de entrada de la liquidación de siniestros. */
public interface LiquidarSiniestroUseCase {

    /**
     * Liquida el siniestro indicado.
     *
     * @param siniestroId identificador; null equivale a un parámetro NULL (no existe)
     * @throws com.banco.siniestros.liquidacion.domain.exception.LiquidacionException
     *         equivalente a -20010, -20011 o NO_DATA_FOUND
     */
    ResultadoLiquidacion liquidar(Long siniestroId);
}
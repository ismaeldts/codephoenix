package com.banco.siniestros.liquidacion.domain.specification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PolizaNoVigenteSpecificationTest {

    private final PolizaNoVigenteSpecification spec = new PolizaNoVigenteSpecification();

    private static Poliza poliza(String estado) {
        return new Poliza(1002L, "AUTO", estado, LocalDateTime.of(2023, 1, 1, 0, 0),
                new BigDecimal("50000"), new BigDecimal("500"), new BigDecimal("10"));
    }

    private static Siniestro siniestro() {
        return new Siniestro(5L, 1002L, LocalDateTime.of(2023, 6, 1, 0, 0),
                new BigDecimal("5000"), "COLISION", "ABIERTO", null);
    }

    @DisplayName("R-05 póliza SUSPENDIDA o CANCELADA se rechaza (TC05, TC06)")
    @ParameterizedTest
    @CsvSource({"SUSPENDIDA,true", "CANCELADA,true", "VIGENTE,false"})
    void rechazoPorEstado(String estado, boolean esperado) {
        assertEquals(esperado, spec.seRechaza(siniestro(), poliza(estado)));
    }

    @DisplayName("R-05 estado NULL no se rechaza (comparación desconocida)")
    @Test
    void estadoNulo() {
        assertFalse(spec.seRechaza(siniestro(), poliza(null)));
    }
}
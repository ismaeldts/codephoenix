# language: es
Característica: Cálculo de la cuota fija del sistema francés
  Como auditor financiero
  Quiero que la tasa mensual, el factor de capitalización y la cuota reproduzcan los truncamientos del legacy
  Para que la cuota informada al cliente sea idéntica a la del programa original

  @R-09
  Esquema del escenario: La tasa mensual es la tasa efectiva entre 1200 truncada a 10 decimales
    Cuando se calcula la cuota francesa con monto "10000.00", plazo 12 y tasa efectiva "<efectiva>"
    Entonces la tasa mensual es "<mensual>"

    Ejemplos:
      | efectiva | mensual      |
      | 18.0000  | 0.0150000000 |
      | 11.0000  | 0.0091666666 |
      | 10.0000  | 0.0083333333 |
      | 36.0000  | 0.0300000000 |

  @R-10 @R-11
  Esquema del escenario: La cuota fija sale del factor truncado en cada iteración y se redondea a 2 decimales
    Cuando se calcula la cuota francesa con monto "<monto>", plazo <plazo> y tasa efectiva "18.0000"
    Entonces la cuota fija calculada es "<cuota>"

    Ejemplos:
      | monto    | plazo | cuota  |
      | 10000.00 | 12    | 916.80 |
      | 1000.00  | 6     | 175.53 |

  @R-11
  Escenario: La cuota fija se informa en la cabecera de la salida
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces la cuota fija informada es "916.80"
    Y la salida incluye la línea "HDR| 18.0000| 12|      916.80"
# Informe ejecutivo: migración de AMORTIZA.cbl

## Resumen
Se migró el programa COBOL **AMORTIZA.cbl** (164 líneas, 9 párrafos, 10 dependencias, 4 `GO TO`), que calcula la tabla de amortización de créditos de consumo con el sistema francés (cuota fija). Ajusta la tasa según el score, aplica el tope de usura (36 %) y suma un seguro de desgravamen mensual. El proceso automatizado tardó **6,1 minutos** de extremo a extremo, sin contar la revisión humana.

## Reglas de negocio recuperadas
- Se descubrieron **16 reglas**; el ingeniero aprobó o ajustó las 16 y no rechazó ninguna.
- **15 de 16** están trazadas al código moderno.
- Entre ellas, reglas poco visibles: el seguro (0,045 %) se calcula sobre el saldo y no forma parte de la cuota base; el piso de 5 % solo aplica al descuento por score alto; y la última cuota absorbe las diferencias de redondeo.

## Riesgos mitigados
- **Precisión numérica:** se replicaron los truncamientos a 10 decimales y el redondeo solo donde el original lo usa.
- **Formatos de salida:** se respetan los campos editados del original.
- **Código muerto:** `9000-CALCULAR-MORA` no se migró, a la espera de confirmación de negocio.
- **Datos sensibles:** 4 enmascarados antes de usar IA.
- **Ejecución aislada:** el programa original se ejecutó en GnuCOBOL, en un contenedor sin red.

## Evidencia de calidad
- Equivalencia funcional frente al original: **20/20 casos idénticos**.
- Pruebas unitarias: **135/135 exitosas**; cobertura de **98,8 %** en líneas y **97,6 %** en ramas.
- Calidad estática: 0 bloqueantes, 0 críticos; complejidad máxima por método de 4.
- La generación requirió 3 intentos con autocorrección.
- Consumo de IA: 143.801 tokens de entrada y 81.134 de salida.

## Ahorro estimado frente al análisis manual
La estimación manual **parte de supuestos**: 12 líneas analizadas, migradas y probadas por hora, a US$45/hora. Con ellos, el trabajo manual sería de **14 horas (US$630)**, frente a **6,1 minutos** automatizados. La comparación no incluye el tiempo de revisión humana del lado automatizado, y el resultado cambiaría si se modifican los supuestos.

## Próximos pasos
1. Que negocio confirme si `9000-CALCULAR-MORA` debe migrarse o eliminarse definitivamente.
2. Revisar la regla que aún no tiene traza al código moderno (1 de 16).
3. Ampliar los casos de equivalencia más allá de los 20 actuales, con foco en límites de monto, plazo, score y usura.
4. Obtener la aprobación formal de auditoría antes de pasar a producción.
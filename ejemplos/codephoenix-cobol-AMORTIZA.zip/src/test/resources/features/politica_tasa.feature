# language: es
Característica: Política de tasa efectiva según el score crediticio
  Como auditor de riesgo
  Quiero que la tasa efectiva respete las rebajas, recargos, piso y tope de usura
  Para que el precio del crédito coincida con la política vigente

  @R-06
  Esquema del escenario: Score alto recibe rebaja de 1,5 puntos con piso de 5,0000
    Dado una solicitud con monto "10000.00", tasa anual "<tasa>", plazo 12 y score <score>
    Cuando se simula el crédito
    Entonces la tasa efectiva es "<efectiva>"

    Ejemplos:
      | tasa    | score | efectiva |
      | 18.0000 | 750   | 16.5000  |
      | 18.0000 | 820   | 16.5000  |
      | 20.0000 | 750   | 18.5000  |
      | 6.5000  | 750   | 5.0000   |
      | 6.0000  | 800   | 5.0000   |
      | 5.0000  | 800   | 5.0000   |

  @R-07
  Esquema del escenario: Tramo medio de score no cambia la tasa
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score <score>
    Cuando se simula el crédito
    Entonces la tasa efectiva es "18.0000"

    Ejemplos:
      | score |
      | 650   |
      | 700   |
      | 749   |

  @R-07
  Esquema del escenario: Score bajo suma 2 puntos a la tasa
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score <score>
    Cuando se simula el crédito
    Entonces la tasa efectiva es "20.0000"

    Ejemplos:
      | score |
      | 550   |
      | 600   |
      | 649   |

  @R-08
  Esquema del escenario: La tasa efectiva nunca supera el tope de usura de 36,0000
    Dado una solicitud con monto "10000.00", tasa anual "<tasa>", plazo 12 y score <score>
    Cuando se simula el crédito
    Entonces la tasa efectiva es "36.0000"

    Ejemplos:
      | tasa    | score |
      | 35.0000 | 600   |
      | 34.0000 | 600   |
      | 34.5000 | 649   |
      | 40.0000 | 750   |
      | 36.0000 | 700   |
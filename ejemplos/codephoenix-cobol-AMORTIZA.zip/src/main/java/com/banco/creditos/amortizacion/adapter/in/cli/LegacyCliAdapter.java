package com.banco.creditos.amortizacion.adapter.in.cli;

import com.banco.creditos.amortizacion.application.port.in.SimularAmortizacionUseCase;
import com.banco.creditos.amortizacion.application.service.SimularAmortizacionService;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.model.SolicitudInvalidaException;
import com.banco.creditos.amortizacion.domain.service.CalculadorCuota;
import com.banco.creditos.amortizacion.domain.service.CalculadorTasaEfectiva;
import com.banco.creditos.amortizacion.domain.service.GeneradorTablaAmortizacion;
import com.banco.creditos.amortizacion.domain.service.SolicitudFactory;
import com.banco.creditos.amortizacion.domain.service.ValidadorSolicitud;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Adaptador CLI: reproduce el contrato de E/S del programa AMORTIZA (ACCEPT / DISPLAY).
 */
public final class LegacyCliAdapter {

    private static final SolicitudFactory FACTORY = new SolicitudFactory();
    private static final SimularAmortizacionUseCase CASO_DE_USO = new SimularAmortizacionService(
            new ValidadorSolicitud(),
            new CalculadorTasaEfectiva(),
            new CalculadorCuota(),
            new GeneradorTablaAmortizacion());
    private static final FormateadorSalidaLegacy FORMATEADOR = new FormateadorSalidaLegacy();

    private LegacyCliAdapter() {
    }

    // Regla R-01 · AMORTIZA.cbl:72-85
    public static List<String> process(String record) {
        return FORMATEADOR.formatear(simular(record));
    }

    private static ResultadoSimulacion simular(String record) {
        try {
            SolicitudCredito solicitud = FACTORY.desdeRegistro(record);
            return CASO_DE_USO.simular(solicitud);
        } catch (SolicitudInvalidaException rechazo) {
            return ResultadoSimulacion.rechazada(rechazo.codigoError());
        }
    }

    public static void main(String[] args) {
        String linea = leerLinea();
        for (String salida : process(linea)) {
            System.out.println(salida);
        }
    }

    private static String leerLinea() {
        BufferedReader lector =
                new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        try {
            String linea = lector.readLine();
            return linea == null ? "" : linea;
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo leer el registro de entrada", e);
        }
    }
}
package com.banco.siniestros.liquidacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class EntradaCaracterizacionTest {

    @Test
    @DisplayName("R-01 lee parámetro y fila, con retorno de carro")
    void leeParametroYFila() {
        EntradaCaracterizacion e = EntradaCaracterizacion.leer(List.of(
                "PARAM|P_SINIESTRO_ID|5\r",
                "ROW|SINIESTROS|SINIESTRO_ID=5|CAUSA=COLISION|MONTO_LIQUIDADO=\\N"));
        assertEquals("5", e.parametro("P_SINIESTRO_ID"));
        assertEquals(1, e.filas().size());
        assertEquals("SINIESTROS", e.filas().get(0).tabla());
        assertEquals("COLISION", e.filas().get(0).columnas().get("CAUSA"));
        assertEquals("\\N", e.filas().get(0).columnas().get("MONTO_LIQUIDADO"));
    }

    @Test
    @DisplayName("R-01 parámetro ausente es NULL")
    void parametroAusente() {
        EntradaCaracterizacion e = EntradaCaracterizacion.leer(List.of());
        assertNull(e.parametro("P_SINIESTRO_ID"));
        assertTrue(e.filas().isEmpty());
    }

    @Test
    @DisplayName("R-01 ignora líneas incompletas o desconocidas y columnas mal formadas")
    void ignoraLineasInvalidas() {
        EntradaCaracterizacion e = EntradaCaracterizacion.leer(List.of(
                "PARAM|SOLO",
                "ROW",
                "OTRO|X|Y",
                "",
                "ROW|POLIZAS|A=b=c|SINIESTRO|=x|B="));
        assertNull(e.parametro("SOLO"));
        assertEquals(1, e.filas().size());
        assertEquals(2, e.filas().get(0).columnas().size());
        assertEquals("b=c", e.filas().get(0).columnas().get("A"));
        assertEquals("", e.filas().get(0).columnas().get("B"));
    }
}
package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.CuotaFrancesa;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * 3000-CALCULAR-CUOTA: sistema francés con truncamientos idénticos al legacy.
 */
public final class CalculadorCuota {

    private static final MathContext PRECISION_AMPLIA = new MathContext(40, RoundingMode.HALF_UP);
    private static final BigDecimal MESES_POR_100 = new BigDecimal("1200");
    private static final int ESCALA_TASA_FACTOR = 10;
    private static final int ESCALA_CUOTA = 2;

    public CuotaFrancesa calcular(BigDecimal monto, int plazo, BigDecimal tasaEfectiva) {
        BigDecimal tasaMensual = tasaMensual(tasaEfectiva);
        BigDecimal factor = factorCapitalizacion(tasaMensual, plazo);
        return new CuotaFrancesa(tasaMensual, cuotaFija(monto, tasaMensual, factor));
    }

    // Regla R-09 · AMORTIZA.cbl:140-140
    BigDecimal tasaMensual(BigDecimal tasaEfectiva) {
        return tasaEfectiva.divide(MESES_POR_100, PRECISION_AMPLIA)
                .setScale(ESCALA_TASA_FACTOR, RoundingMode.DOWN)
                .abs();
    }

    // Regla R-10 · AMORTIZA.cbl:141-144
    BigDecimal factorCapitalizacion(BigDecimal tasaMensual, int plazo) {
        BigDecimal unoMasTasa = BigDecimal.ONE.add(tasaMensual);
        BigDecimal factor = BigDecimal.ONE.setScale(ESCALA_TASA_FACTOR, RoundingMode.DOWN);
        for (int i = 1; i <= plazo; i++) {
            factor = factor.multiply(unoMasTasa).setScale(ESCALA_TASA_FACTOR, RoundingMode.DOWN);
        }
        return factor;
    }

    // Regla R-11 · AMORTIZA.cbl:145-147
    BigDecimal cuotaFija(BigDecimal monto, BigDecimal tasaMensual, BigDecimal factor) {
        BigDecimal divisor = factor.subtract(BigDecimal.ONE);
        if (divisor.signum() == 0) {
            // División por cero sin SIZE ERROR: WS-CUOTA conserva su valor inicial (cero).
            return BigDecimal.ZERO.setScale(ESCALA_CUOTA, RoundingMode.DOWN);
        }
        return monto.multiply(tasaMensual)
                .multiply(factor)
                .divide(divisor, PRECISION_AMPLIA)
                .setScale(ESCALA_CUOTA, RoundingMode.HALF_UP)
                .abs();
    }
}
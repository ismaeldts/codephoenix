package com.banco.creditos.amortizacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.TablaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.TotalesCredito;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class FormateadorSalidaLegacyTest {

    private final FormateadorSalidaLegacy formateador = new FormateadorSalidaLegacy();

    @ParameterizedTest(name = "{0} [{1}.{2}]")
    @DisplayName("R-15 máscaras editadas Z(n)9.99 / ZZ9 / ZZ9.9999")
    @CsvSource({
        "916.80,9,2,'      916.80'",
        "18.0000,3,4,' 18.0000'",
        "12,3,0,' 12'",
        "6,3,0,'  6'",
        "4.50,7,2,'      4.50'",
        "1001.61,11,2,'       1001.61'",
        "0,9,2,'        0.00'",
        "-581.75,9,2,'      581.75'",
        "1.999,9,2,'        1.99'",
        "1234567890.12,9,2,'234567890.12'",
        "1000000000.05,9,2,'        0.05'"
    })
    void mascaras(BigDecimal valor, int enteros, int decimales, String esperado) {
        assertEquals(esperado, FormateadorSalidaLegacy.editado(valor, enteros, decimales));
    }

    @ParameterizedTest(name = "{0}")
    @DisplayName("R-01 línea de error ERR|código|mensaje")
    @CsvSource({
        "E00,ERR|E00|REGISTRO DE ENTRADA INVALIDO",
        "E01,ERR|E01|MONTO FUERA DE RANGO"
    })
    void linea_de_error(CodigoError error, String esperado) {
        assertEquals(esperado, formateador.lineaError(error));
        assertEquals(List.of(esperado), formateador.formatear(ResultadoSimulacion.rechazada(error)));
    }

    @Test
    @DisplayName("R-16 resultado exitoso: HDR, DET y TOT con el formato del Golden Master")
    void resultado_exitoso() {
        FilaAmortizacion fila = new FilaAmortizacion(
                6,
                new BigDecimal("175.50"),
                new BigDecimal("2.59"),
                new BigDecimal("172.91"),
                new BigDecimal("0.08"),
                new BigDecimal("175.58"),
                new BigDecimal("0.00"));
        TotalesCredito totales = new TotalesCredito(
                new BigDecimal("53.15"), new BigDecimal("1.59"), new BigDecimal("1054.74"));
        ResultadoSimulacion resultado = ResultadoSimulacion.exitosa(
                new BigDecimal("18.0000"),
                6,
                new BigDecimal("175.53"),
                new TablaAmortizacion(List.of(fila), totales));

        List<String> lineas = formateador.formatear(resultado);

        assertEquals(
                List.of(
                        "HDR| 18.0000|  6|      175.53",
                        "DET|  6|      175.50|        2.59|      172.91|      0.08|      175.58|        0.00",
                        "TOT|         53.15|          1.59|       1054.74"),
                lineas);
    }
}
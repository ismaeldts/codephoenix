package com.banco.creditos.amortizacion.domain.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

/**
 * Resultado de la simulación: o bien el cálculo completo, o bien el error de validación.
 */
// Regla R-01 · AMORTIZA.cbl:76-84
public record ResultadoSimulacion(
        CodigoError error,
        BigDecimal tasaEfectiva,
        int plazo,
        BigDecimal cuotaFija,
        List<FilaAmortizacion> filas,
        TotalesCredito totales) {

    public ResultadoSimulacion {
        filas = filas == null ? List.of() : List.copyOf(filas);
        if (error == null) {
            Objects.requireNonNull(tasaEfectiva, "tasaEfectiva");
            Objects.requireNonNull(cuotaFija, "cuotaFija");
            Objects.requireNonNull(totales, "totales");
        }
    }

    public static ResultadoSimulacion rechazada(CodigoError error) {
        Objects.requireNonNull(error, "error");
        return new ResultadoSimulacion(error, null, 0, null, List.of(), null);
    }

    public static ResultadoSimulacion exitosa(
            BigDecimal tasaEfectiva, int plazo, BigDecimal cuotaFija, TablaAmortizacion tabla) {
        return new ResultadoSimulacion(
                null, tasaEfectiva, plazo, cuotaFija, tabla.filas(), tabla.totales());
    }

    public boolean rechazada() {
        return error != null;
    }
}
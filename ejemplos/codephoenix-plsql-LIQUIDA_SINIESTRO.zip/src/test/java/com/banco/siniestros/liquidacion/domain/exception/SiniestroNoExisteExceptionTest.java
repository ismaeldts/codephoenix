package com.banco.siniestros.liquidacion.domain.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class SiniestroNoExisteExceptionTest {

    @Test
    @DisplayName("R-01 siniestro inexistente: -20010 'SINIESTRO NO EXISTE' (TC01)")
    void codigoYMensaje() {
        SiniestroNoExisteException error = new SiniestroNoExisteException();
        assertEquals("E01", error.codigo());
        assertEquals(-20010, error.sqlCode());
        assertEquals("SINIESTRO NO EXISTE", error.getMessage());
    }
}
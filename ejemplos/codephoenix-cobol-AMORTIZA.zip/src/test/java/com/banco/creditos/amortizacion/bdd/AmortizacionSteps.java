package com.banco.creditos.amortizacion.bdd;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.creditos.amortizacion.adapter.in.cli.FormateadorSalidaLegacy;
import com.banco.creditos.amortizacion.adapter.in.cli.LegacyCliAdapter;
import com.banco.creditos.amortizacion.application.port.in.SimularAmortizacionUseCase;
import com.banco.creditos.amortizacion.application.service.SimularAmortizacionService;
import com.banco.creditos.amortizacion.domain.model.CuotaFrancesa;
import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.service.CalculadorCuota;
import com.banco.creditos.amortizacion.domain.service.CalculadorTasaEfectiva;
import com.banco.creditos.amortizacion.domain.service.GeneradorTablaAmortizacion;
import com.banco.creditos.amortizacion.domain.service.ValidadorSolicitud;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import java.math.BigDecimal;
import java.util.List;

/**
 * Pasos BDD del simulador de amortización. Ejercitan el servicio de aplicación,
 * el calculador de cuota del dominio y el adaptador legacy, sin duplicar lógica.
 */
public class AmortizacionSteps {

    private final SimularAmortizacionUseCase casoDeUso = new SimularAmortizacionService(
            new ValidadorSolicitud(),
            new CalculadorTasaEfectiva(),
            new CalculadorCuota(),
            new GeneradorTablaAmortizacion());
    private final FormateadorSalidaLegacy formateador = new FormateadorSalidaLegacy();

    private SolicitudCredito solicitud;
    private String registro;
    private ResultadoSimulacion resultado;
    private List<String> lineas;
    private CuotaFrancesa cuotaCalculada;

    // ---------- Dado ----------

    @Dado("una solicitud con monto {string}, tasa anual {string}, plazo {int} y score {int}")
    public void unaSolicitud(String monto, String tasaAnual, int plazo, int score) {
        solicitud = new SolicitudCredito(new BigDecimal(monto), new BigDecimal(tasaAnual), plazo, score);
    }

    @Dado("el registro de entrada {string}")
    public void elRegistroDeEntrada(String valor) {
        registro = valor;
    }

    // ---------- Cuando ----------

    @Cuando("se simula el crédito")
    public void seSimulaElCredito() {
        resultado = casoDeUso.simular(solicitud);
        lineas = formateador.formatear(resultado);
    }

    @Cuando("se procesa el registro de entrada")
    public void seProcesaElRegistro() {
        lineas = LegacyCliAdapter.process(registro);
    }

    @Cuando("se calcula la cuota francesa con monto {string}, plazo {int} y tasa efectiva {string}")
    public void seCalculaLaCuotaFrancesa(String monto, int plazo, String tasaEfectiva) {
        cuotaCalculada = new CalculadorCuota()
                .calcular(new BigDecimal(monto), plazo, new BigDecimal(tasaEfectiva));
    }

    // ---------- Entonces: salida ----------

    @Entonces("la salida es {string}")
    public void laSalidaEs(String esperada) {
        assertNotNull(lineas);
        assertEquals(1, lineas.size(), "Se esperaba una única línea de salida: " + lineas);
        assertEquals(esperada, lineas.get(0));
    }

    @Entonces("la simulación es aceptada")
    public void laSimulacionEsAceptada() {
        assertNotNull(lineas);
        assertFalse(lineas.isEmpty());
        assertTrue(lineas.get(0).startsWith("HDR|"), "Se esperaba cabecera HDR: " + lineas.get(0));
    }

    @Entonces("la salida incluye la línea {string}")
    public void laSalidaIncluyeLaLinea(String esperada) {
        assertTrue(lineas.contains(esperada), "No se encontró la línea: " + esperada);
    }

    @Entonces("la salida tiene {int} líneas")
    public void laSalidaTieneLineas(int cantidad) {
        assertEquals(cantidad, lineas.size());
    }

    @Entonces("la línea de salida {int} es {string}")
    public void laLineaDeSalidaEs(int numero, String esperada) {
        assertEquals(esperada, lineas.get(numero - 1));
    }

    // ---------- Entonces: tasa y cuota ----------

    @Entonces("la tasa efectiva es {string}")
    public void laTasaEfectivaEs(String esperada) {
        assertImporte(esperada, resultado.tasaEfectiva());
    }

    @Entonces("la tasa mensual es {string}")
    public void laTasaMensualEs(String esperada) {
        assertImporte(esperada, cuotaCalculada.tasaMensual());
        assertEquals(10, cuotaCalculada.tasaMensual().scale());
    }

    @Entonces("la cuota fija calculada es {string}")
    public void laCuotaFijaCalculadaEs(String esperada) {
        assertImporte(esperada, cuotaCalculada.cuotaFija());
    }

    @Entonces("la cuota fija informada es {string}")
    public void laCuotaFijaInformadaEs(String esperada) {
        assertImporte(esperada, resultado.cuotaFija());
    }

    // ---------- Entonces: tabla ----------

    @Entonces("la tabla tiene {int} periodos")
    public void laTablaTienePeriodos(int cantidad) {
        assertEquals(cantidad, resultado.filas().size());
    }

    @Entonces("en el periodo {int} la cuota es {string}")
    public void enElPeriodoLaCuotaEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).cuota());
    }

    @Entonces("en el periodo {int} el interés es {string}")
    public void enElPeriodoElInteresEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).interes());
    }

    @Entonces("en el periodo {int} la amortización es {string}")
    public void enElPeriodoLaAmortizacionEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).amortizacion());
    }

    @Entonces("en el periodo {int} el seguro es {string}")
    public void enElPeriodoElSeguroEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).seguro());
    }

    @Entonces("en el periodo {int} el total a pagar es {string}")
    public void enElPeriodoElTotalEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).total());
    }

    @Entonces("en el periodo {int} el saldo es {string}")
    public void enElPeriodoElSaldoEs(int periodo, String esperada) {
        assertImporte(esperada, fila(periodo).saldo());
    }

    // ---------- Entonces: totales ----------

    @Entonces("el total de intereses es {string}")
    public void elTotalDeInteresesEs(String esperado) {
        assertImporte(esperado, resultado.totales().interes());
    }

    @Entonces("el total de seguros es {string}")
    public void elTotalDeSegurosEs(String esperado) {
        assertImporte(esperado, resultado.totales().seguro());
    }

    @Entonces("el total pagado es {string}")
    public void elTotalPagadoEs(String esperado) {
        assertImporte(esperado, resultado.totales().pagado());
    }

    // ---------- Utilidades ----------

    private FilaAmortizacion fila(int periodo) {
        assertNotNull(resultado, "No hay resultado de simulación");
        assertFalse(resultado.rechazada(), "La solicitud fue rechazada: " + resultado.error());
        return resultado.filas().get(periodo - 1);
    }

    private static void assertImporte(String esperado, BigDecimal real) {
        assertNotNull(real);
        BigDecimal valorEsperado = new BigDecimal(esperado);
        assertEquals(0, valorEsperado.compareTo(real),
                "Esperado " + esperado + " pero fue " + real.toPlainString());
    }
}
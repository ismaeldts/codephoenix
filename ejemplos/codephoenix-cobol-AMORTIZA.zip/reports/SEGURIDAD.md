# Reporte de seguridad

## 1. Protección de datos antes de usar IA

4 datos sensibles (credenciales, cadenas de conexión, correos, IPs, tarjetas) se enmascararon antes de enviar el código a los modelos. Solo se usaron datos sintéticos.

## 2. Análisis estático de seguridad (SAST)

Herramienta: **SpotBugs 4.8.6 + FindSecBugs 1.13.0**, sobre el bytecode compilado, dentro del sandbox sin red. Las vulnerabilidades de prioridad alta o media y los errores de corrección de prioridad alta son críticos y bloquean el quality gate.

| Severidad | Hallazgos |
|---|---|
| Críticos | 0 |
| Mayores | 0 |
| Menores | 0 |

## 3. Dependencias

El código de producción no usa librerías de terceros: solo la biblioteca estándar de Java 21. No hay dependencias de producción que puedan contener vulnerabilidades conocidas (CVE). Las pruebas usan JUnit 5 y Cucumber, que no forman parte de la imagen final.

## 4. Secretos en el código generado

0 secretos detectados en el código generado.

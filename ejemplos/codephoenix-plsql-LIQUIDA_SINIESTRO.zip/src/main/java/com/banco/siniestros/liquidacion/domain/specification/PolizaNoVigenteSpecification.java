package com.banco.siniestros.liquidacion.domain.specification;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;

// Regla R-05 · LIQUIDA_SINIESTRO.sql:75-78
public final class PolizaNoVigenteSpecification implements RechazoSpecification {

    @Override
    public boolean seRechaza(Siniestro siniestro, Poliza poliza) {
        return poliza.noEstaVigente();
    }
}
package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.model.SolicitudInvalidaException;
import java.math.BigDecimal;

/**
 * Factory que interpreta el registro de ancho fijo de 24 posiciones.
 */
// Regla R-01 · AMORTIZA.cbl:90-94
public final class SolicitudFactory {

    private static final int LONGITUD_REGISTRO = 24;

    /**
     * ACCEPT trunca a la longitud declarada; un registro más corto queda relleno con espacios
     * y por tanto NOT NUMERIC.
     */
    // Regla R-01 · AMORTIZA.cbl:90-94
    public SolicitudCredito desdeRegistro(String registro) {
        String texto = normalizar(registro);
        if (texto.length() < LONGITUD_REGISTRO || !soloDigitos(texto)) {
            throw new SolicitudInvalidaException(CodigoError.E00);
        }
        return construir(texto);
    }

    private static String normalizar(String registro) {
        String texto = registro == null ? "" : registro;
        return texto.length() > LONGITUD_REGISTRO ? texto.substring(0, LONGITUD_REGISTRO) : texto;
    }

    private static boolean soloDigitos(String texto) {
        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

    // Regla R-01 · AMORTIZA.cbl:16-20 (posiciones 01-11, 12-18, 19-21, 22-24)
    private static SolicitudCredito construir(String texto) {
        BigDecimal monto = BigDecimal.valueOf(Long.parseLong(texto.substring(0, 11)), 2);
        BigDecimal tasa = BigDecimal.valueOf(Long.parseLong(texto.substring(11, 18)), 4);
        int plazo = Integer.parseInt(texto.substring(18, 21));
        int score = Integer.parseInt(texto.substring(21, 24));
        return new SolicitudCredito(monto, tasa, plazo, score);
    }
}
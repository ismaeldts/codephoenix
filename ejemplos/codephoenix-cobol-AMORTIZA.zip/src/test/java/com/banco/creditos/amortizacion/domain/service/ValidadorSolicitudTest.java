package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.math.BigDecimal;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class ValidadorSolicitudTest {

    private final ValidadorSolicitud validador = new ValidadorSolicitud();

    private static SolicitudCredito solicitud(String monto, String tasa, int plazo, int score) {
        return new SolicitudCredito(new BigDecimal(monto), new BigDecimal(tasa), plazo, score);
    }

    @Test
    @DisplayName("R-02 solicitud nominal TC01 no tiene errores")
    void valida() {
        assertTrue(validador.validar(solicitud("10000.00", "18.0000", 12, 700)).isEmpty());
    }

    @ParameterizedTest
    @CsvSource({
        "999.99,18.0000,12,700,E01",
        "500000000.01,18.0000,12,700,E01",
        "1000.00,18.0000,5,700,E02",
        "1000.00,18.0000,361,700,E02",
        "1000.00,18.0000,12,549,E03",
        "1000.00,0.0000,12,700,E04"
    })
    @DisplayName("R-02 R-03 R-04 R-05 cada regla rechaza con su código")
    void rechazos(String monto, String tasa, int plazo, int score, CodigoError esperado) {
        assertEquals(Optional.of(esperado), validador.validar(solicitud(monto, tasa, plazo, score)));
    }

    @ParameterizedTest
    @CsvSource({
        "999.99,0.0000,5,100,E01",
        "1000.00,0.0000,5,100,E02",
        "1000.00,0.0000,12,100,E03"
    })
    @DisplayName("R-01 el primer fallo determina el resultado")
    void primerFalloGana(String monto, String tasa, int plazo, int score, CodigoError esperado) {
        assertEquals(Optional.of(esperado), validador.validar(solicitud(monto, tasa, plazo, score)));
    }
}
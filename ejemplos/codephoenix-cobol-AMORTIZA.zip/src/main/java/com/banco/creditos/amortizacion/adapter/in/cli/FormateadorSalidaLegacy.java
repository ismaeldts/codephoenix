package com.banco.creditos.amortizacion.adapter.in.cli;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.TotalesCredito;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Reproduce las máscaras editadas del legacy (ZZ9, ZZ9.9999, Z(n)9.99) y las líneas DISPLAY.
 * Los campos editados son sin signo: se muestra el valor absoluto (comportamiento legacy).
 */
public final class FormateadorSalidaLegacy {

    private static final int ENTEROS_TASA = 3;
    private static final int ENTEROS_PERIODO = 3;
    private static final int ENTEROS_IMPORTE = 9;
    private static final int ENTEROS_SEGURO = 7;
    private static final int ENTEROS_TOTAL = 11;

    public List<String> formatear(ResultadoSimulacion resultado) {
        if (resultado.rechazada()) {
            return List.of(lineaError(resultado.error()));
        }
        List<String> lineas = new ArrayList<>(resultado.filas().size() + 2);
        lineas.add(lineaCabecera(resultado));
        for (FilaAmortizacion fila : resultado.filas()) {
            lineas.add(lineaDetalle(fila));
        }
        lineas.add(lineaTotales(resultado.totales()));
        return lineas;
    }

    // Regla R-01 · AMORTIZA.cbl:76-78
    String lineaError(CodigoError error) {
        return "ERR|" + error.codigo() + "|" + error.mensaje().trim();
    }

    // Regla R-11 · AMORTIZA.cbl:148-150
    private static String lineaCabecera(ResultadoSimulacion resultado) {
        return "HDR|" + editado(resultado.tasaEfectiva(), ENTEROS_TASA, 4)
                + "|" + editado(BigDecimal.valueOf(resultado.plazo()), ENTEROS_PERIODO, 0)
                + "|" + editado(resultado.cuotaFija(), ENTEROS_IMPORTE, 2);
    }

    // Regla R-15 · AMORTIZA.cbl:175-185
    private static String lineaDetalle(FilaAmortizacion fila) {
        return "DET|" + editado(BigDecimal.valueOf(fila.periodo()), ENTEROS_PERIODO, 0)
                + "|" + editado(fila.cuota(), ENTEROS_IMPORTE, 2)
                + "|" + editado(fila.interes(), ENTEROS_IMPORTE, 2)
                + "|" + editado(fila.amortizacion(), ENTEROS_IMPORTE, 2)
                + "|" + editado(fila.seguro(), ENTEROS_SEGURO, 2)
                + "|" + editado(fila.total(), ENTEROS_IMPORTE, 2)
                + "|" + editado(fila.saldo(), ENTEROS_IMPORTE, 2);
    }

    // Regla R-16 · AMORTIZA.cbl:186-191
    private static String lineaTotales(TotalesCredito totales) {
        return "TOT|" + editado(totales.interes(), ENTEROS_TOTAL, 2)
                + "|" + editado(totales.seguro(), ENTEROS_TOTAL, 2)
                + "|" + editado(totales.pagado(), ENTEROS_TOTAL, 2);
    }

    /**
     * Máscara Z(n-1)9[.9(d)]: {@code enteros} dígitos enteros (el último siempre visible),
     * ceros a la izquierda sustituidos por espacios, trunca dígitos de orden superior sobrantes.
     */
    static String editado(BigDecimal valor, int enteros, int decimales) {
        String plano = valor.abs().setScale(decimales, RoundingMode.DOWN).toPlainString();
        int punto = plano.indexOf('.');
        String parteEntera = punto < 0 ? plano : plano.substring(0, punto);
        String parteDecimal = punto < 0 ? "" : plano.substring(punto);
        String texto = ajustarEnteros(parteEntera, enteros) + parteDecimal;
        int ancho = enteros + parteDecimal.length();
        return " ".repeat(Math.max(0, ancho - texto.length())) + texto;
    }

    private static String ajustarEnteros(String enteros, int digitos) {
        String visibles = enteros.length() > digitos
                ? enteros.substring(enteros.length() - digitos)
                : enteros;
        int inicio = 0;
        while (inicio < visibles.length() - 1 && visibles.charAt(inicio) == '0') {
            inicio++;
        }
        return visibles.substring(inicio);
    }
}
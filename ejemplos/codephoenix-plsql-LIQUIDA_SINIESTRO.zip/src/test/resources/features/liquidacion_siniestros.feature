# language: es
Característica: Liquidación de siniestros de pólizas
  Para liquidar correctamente los siniestros reclamados
  La aseguradora aplica validaciones, carencias, exclusiones, deducibles, topes y retenciones
  Y deja el siniestro actualizado en todos los caminos que alcanzan el final del proceso

  @R-01
  Escenario: El siniestro solicitado no existe
    Dado una póliza 1001 de producto "AUTO" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "10.00"%
    Y un siniestro 1 de la póliza 1001 ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 999
    Entonces la liquidación falla con código -20010 y mensaje "SINIESTRO NO EXISTE"
    Y el siniestro 1 queda en estado "ABIERTO" sin monto liquidado
    Y no se registra ningún pago

  @R-02
  Esquema del escenario: Un siniestro que no está abierto no se reprocesa
    Dado una póliza 1001 de producto "AUTO" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "10.00"%
    Y un siniestro <id> de la póliza <poliza> ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "COLISION" y estado "<estado>"
    Cuando se liquida el siniestro <id>
    Entonces la liquidación falla con código -20011 y mensaje "SINIESTRO YA PROCESADO"
    Y no se registra ningún pago
    Y el siniestro <id> queda en estado "<estado>" con monto liquidado "0"

    Ejemplos:
      | id | poliza | estado    |
      | 3  | 1001   | RECHAZADO |
      | 4  | 1001   | SIN_PAGO  |

  @R-02
  Escenario: El estado procesado se evalúa antes de buscar la póliza
    Dado un siniestro 2 de la póliza 7777 ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "COLISION" y estado "RECHAZADO"
    Cuando se liquida el siniestro 2
    Entonces la liquidación falla con código -20011 y mensaje "SINIESTRO YA PROCESADO"

  @R-03
  Escenario: La póliza del siniestro no existe
    Dado un siniestro 20 de la póliza 8888 ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 20
    Entonces la liquidación falla con código 100 y mensaje "no data found"
    Y el siniestro 20 queda en estado "ABIERTO" sin monto liquidado
    Y no se registra ningún pago

  @R-04 @R-05 @R-14
  Escenario: Póliza suspendida deja el siniestro rechazado con monto cero
    Dado una póliza 1002 de producto "AUTO" en estado "SUSPENDIDA" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "10.00"%
    Y un siniestro 5 de la póliza 1002 ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 5
    Entonces el resultado es estado "RECHAZADO" con monto a pagar "0"
    Y el siniestro 5 queda en estado "RECHAZADO" con monto liquidado "0"
    Y no se registra ningún pago

  @R-05
  Escenario: Póliza cancelada se rechaza
    Dado una póliza 1003 de producto "HOGAR" en estado "CANCELADA" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "0.00"%
    Y un siniestro 6 de la póliza 1003 ocurrido el "2023-06-01" por un monto reclamado de "5000.00" con causa "INCENDIO" y estado "ABIERTO"
    Cuando se liquida el siniestro 6
    Entonces el resultado es estado "RECHAZADO" con monto a pagar "0"
    Y el siniestro 6 queda en estado "RECHAZADO" con monto liquidado "0"
    Y no se registra ningún pago

  @R-06 @R-07
  Esquema del escenario: Periodo de carencia según el producto
    Dado una póliza 1004 de producto "<producto>" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "0.00"%
    Y un siniestro 7 de la póliza 1004 ocurrido el "<ocurrencia>" por un monto reclamado de "5000.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 7
    Entonces el resultado es estado "<estado>" con monto a pagar "<monto>"
    Y el siniestro 7 queda en estado "<estado>" con monto liquidado "<monto>"

    Ejemplos:
      | producto | ocurrencia          | estado    | monto |
      | AUTO     | 2023-01-30          | RECHAZADO | 0     |
      | AUTO     | 2023-01-30 23:59:59 | RECHAZADO | 0     |
      | AUTO     | 2023-01-31          | LIQUIDADO | 4500  |
      | HOGAR    | 2023-01-31          | LIQUIDADO | 4500  |
      | SALUD    | 2023-01-31          | RECHAZADO | 0     |
      | SALUD    | 2023-03-31          | RECHAZADO | 0     |
      | SALUD    | 2023-04-01          | LIQUIDADO | 4500  |

  @R-08
  Esquema del escenario: Exclusiones de cobertura por causa
    Dado una póliza 1006 de producto "<producto>" en estado "VIGENTE" que inició el "2022-01-01" con suma asegurada de "80000.00", deducible de "0.00" y coaseguro de "0.00"%
    Y un siniestro 11 de la póliza 1006 ocurrido el "2023-06-01" por un monto reclamado de "3000.00" con causa "<causa>" y estado "ABIERTO"
    Cuando se liquida el siniestro 11
    Entonces el resultado es estado "<estado>" con monto a pagar "<monto>"
    Y el siniestro 11 queda en estado "<estado>" con monto liquidado "<monto>"

    Ejemplos:
      | producto | causa       | estado    | monto |
      | HOGAR    | GUERRA      | RECHAZADO | 0     |
      | SALUD    | DOLO        | RECHAZADO | 0     |
      | AUTO     | COMPETENCIA | RECHAZADO | 0     |
      | HOGAR    | COMPETENCIA | LIQUIDADO | 3000  |
      | AUTO     | COLISION    | LIQUIDADO | 3000  |

  @R-09
  Esquema del escenario: Deducible y coaseguro con redondeo
    Dado una póliza 1008 de producto "AUTO" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "<deducible>" y coaseguro de "<coaseguro>"%
    Y un siniestro 30 de la póliza 1008 ocurrido el "2023-06-01" por un monto reclamado de "<reclamado>" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 30
    Entonces el resultado es estado "LIQUIDADO" con monto a pagar "<pago>"

    Ejemplos:
      | reclamado | deducible | coaseguro | pago   |
      | 5000.00   | 500.00    | 10.00     | 4050   |
      | 1000.00   | 0.00      | 33.33     | 666.7  |
      | 5000.00   | 500.00    | 0.00      | 4500   |

  @R-10
  Esquema del escenario: Tope por suma asegurada y sublímite de inundación
    Dado una póliza 1009 de producto "<producto>" en estado "VIGENTE" que inició el "2022-01-01" con suma asegurada de "<suma>", deducible de "0.00" y coaseguro de "0.00"%
    Y un siniestro 40 de la póliza 1009 ocurrido el "2023-06-01" por un monto reclamado de "<reclamado>" con causa "<causa>" y estado "ABIERTO"
    Cuando se liquida el siniestro 40
    Entonces el resultado es estado "LIQUIDADO" con monto a pagar "<pago>"

    Ejemplos:
      | producto | causa      | suma     | reclamado | pago  |
      | AUTO     | COLISION   | 50000.00 | 60000.00  | 50000 |
      | HOGAR    | INUNDACION | 80000.00 | 60000.00  | 40000 |
      | HOGAR    | INCENDIO   | 80000.00 | 60000.00  | 60000 |
      | HOGAR    | INUNDACION | 80000.00 | 30000.00  | 30000 |

  @R-11 @R-14
  Escenario: Reclamo que no supera el deducible queda sin pago
    Dado una póliza 1010 de producto "AUTO" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "10.00"%
    Y un siniestro 50 de la póliza 1010 ocurrido el "2023-06-01" por un monto reclamado de "300.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 50
    Entonces el resultado es estado "SIN_PAGO" con monto a pagar "0"
    Y no se registra ningún pago
    Y el siniestro 50 queda en estado "SIN_PAGO" con monto liquidado "0"

  @R-12
  Esquema del escenario: Retención del 2.5 por ciento solo sobre pagos mayores a 10000
    Dado una póliza 1011 de producto "AUTO" en estado "VIGENTE" que inició el "2022-01-01" con suma asegurada de "50000.00", deducible de "0.00" y coaseguro de "0.00"%
    Y un siniestro 60 de la póliza 1011 ocurrido el "2023-06-01" por un monto reclamado de "<reclamado>" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 60
    Entonces se registra para el siniestro 60 un pago de monto "<reclamado>", retención "<retencion>" y neto "<neto>"

    Ejemplos:
      | reclamado | retencion | neto     |
      | 10000.00  | 0         | 10000    |
      | 10000.01  | 250       | 9750.01  |
      | 20000.00  | 500       | 19500    |

  @R-13 @R-14
  Escenario: Pago liquidado se registra y actualiza el siniestro
    Dado una póliza 1004 de producto "AUTO" en estado "VIGENTE" que inició el "2023-01-01" con suma asegurada de "50000.00", deducible de "500.00" y coaseguro de "0.00"%
    Y un siniestro 8 de la póliza 1004 ocurrido el "2023-01-31" por un monto reclamado de "5000.00" con causa "COLISION" y estado "ABIERTO"
    Cuando se liquida el siniestro 8
    Entonces el resultado es estado "LIQUIDADO" con monto a pagar "4500"
    Y se registra para el siniestro 8 un pago de monto "4500", retención "0" y neto "4500"
    Y el siniestro 8 queda en estado "LIQUIDADO" con monto liquidado "4500"
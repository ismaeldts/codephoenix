# Arquitectura destino

Se modela la liquidación de siniestros como un agregado Siniestro y una Poliza, evaluados por un servicio de dominio puro que aplica Specifications (elegibilidad), Strategy (carencia y tope) y cálculo con BigDecimal. El caso de uso orquesta tres puertos de salida (pólizas, siniestros, pagos) con implementaciones en memoria. Un adaptador CLI de caracterización carga filas, ejecuta el caso y vuelca el estado final para demostrar equivalencia con Oracle. El contrato REST permite la coexistencia Strangler Fig. El código muerto CALCULA_IVA no se migra.

Paquete base: `com.banco.siniestros.liquidacion`

```mermaid
flowchart LR
  CLI[CaracterizacionCli]
  REST[AdaptadorRest]
  PIN[LiquidarSiniestroUseCase]
  SVC[LiquidarSiniestroService]
  DOM[LiquidadorSiniestro]
  SPEC[Specifications y Politicas]
  POUT1[SiniestroRepository]
  POUT2[PolizaRepository]
  POUT3[PagoSiniestroRepository]
  MEM[RepositoriosEnMemoria]
  JDBC[AdaptadorJdbcOracle]
  CLI --> PIN
  REST --> PIN
  PIN --> SVC
  SVC --> DOM
  DOM --> SPEC
  SVC --> POUT1
  SVC --> POUT2
  SVC --> POUT3
  MEM -.-> POUT1
  MEM -.-> POUT2
  MEM -.-> POUT3
  JDBC -.-> POUT1
  JDBC -.-> POUT2
  JDBC -.-> POUT3
```

| Elemento | Tipo | Capa | Responsabilidad |
|---|---|---|---|
| Siniestro | ENTITY | DOMINIO | Agregado con fecha de ocurrencia, monto reclamado, causa, estado y monto liquidado. Solo se liquida si está ABIERTO y aplica el resultado final (R-02, R-14). |
| Poliza | ENTITY | DOMINIO | Entidad con producto, estado, fecha de inicio, suma asegurada, deducible y coaseguro. Informa si está vigente (R-05). |
| ResultadoLiquidacion | VALUE_OBJECT | DOMINIO | Record inmutable con estado (LIQUIDADO, SIN_PAGO, RECHAZADO), monto a pagar y retención opcional. Por defecto RECHAZADO con monto 0 (R-04, R-11, R-13). |
| PagoSiniestro | VALUE_OBJECT | DOMINIO | Record con siniestroId, monto, retención y neto (monto - retención), todos con escala 2 (R-13). |
| CarenciaSpecification | SPECIFICATION | DOMINIO | Rechaza si ocurrencia < inicio + días de carencia, comparación estricta con hora. Los días los obtiene de PoliticaCarencia (R-06, R-07). |
| ExclusionCausaSpecification | SPECIFICATION | DOMINIO | Excluye GUERRA y DOLO en todo producto, y COMPETENCIA solo en AUTO (R-08). |
| PoliticaCarencia | DOMAIN_SERVICE | DOMINIO | Strategy que devuelve 90 días para SALUD y 30 para el resto de productos (R-06). |
| PoliticaTope | DOMAIN_SERVICE | DOMINIO | Strategy que calcula el tope: 50% de la suma asegurada para HOGAR con INUNDACION, suma completa en otro caso, redondeado a 2 decimales HALF_UP (R-10). |
| LiquidadorSiniestro | DOMAIN_SERVICE | DOMINIO | Evalúa reglas en secuencia sin GO TO, calcula base con deducible y coaseguro, aplica tope y retención del 2.5% si supera 10000 (R-04, R-05, R-09, R-10, R-11, R-12, R-13). |
| LiquidarSiniestroUseCase | PORT_IN | APLICACION | Puerto de entrada: liquidar(siniestroId) devuelve ResultadoLiquidacion o lanza errores de negocio equivalentes a -20010, -20011 y NO_DATA_FOUND. |
| LiquidarSiniestroService | APPLICATION_SERVICE | APLICACION | Carga siniestro y póliza, valida existencia y estado, invoca al dominio, registra pago si procede y actualiza el siniestro siempre (R-01, R-02, R-03, R-14). |
| SiniestroRepository, PolizaRepository, PagoSiniestroRepository | PORT_IN | APLICACION | Puertos de salida que sustituyen las tablas SINIESTROS, POLIZAS y PAGOS_SINIESTRO: buscar por id, actualizar siniestro e insertar pago. Sin SQL en el dominio. |
| CaracterizacionCli | ADAPTER_IN | ADAPTADOR | Carga filas iniciales en repositorios en memoria, invoca el caso de uso y vuelca SINIESTROS y PAGOS_SINIESTRO finales para comparar con Oracle. |
| Repositorios en memoria (persistence) | ADAPTER_IN | ADAPTADOR | Implementaciones con mapas del JDK de los tres puertos de salida; un adaptador JDBC de producción implementaría los mismos puertos. |

## Decisiones de arquitectura

- [ADR-001: Arquitectura hexagonal con dominio puro](adr/ADR-001.md)
- [ADR-002: Precisión numérica: NUMBER a BigDecimal](adr/ADR-002.md)
- [ADR-003: Eliminación del GO TO a fin_proceso](adr/ADR-003.md)
- [ADR-004: Errores de negocio equivalentes a Oracle](adr/ADR-004.md)
- [ADR-005: Strategy y Specification para reglas variables](adr/ADR-005.md)

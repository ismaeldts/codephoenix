package com.banco.siniestros.liquidacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ResultadoLiquidacionTest {

    @Test
    @DisplayName("R-04 resultado por defecto RECHAZADO con monto 0 (TC05, TC11)")
    void rechazadoPorDefecto() {
        ResultadoLiquidacion r = ResultadoLiquidacion.rechazado();
        assertEquals(EstadoLiquidacion.RECHAZADO, r.estado());
        assertEquals("0", r.montoPagar().stripTrailingZeros().toPlainString());
        assertEquals(0, r.retencion().signum());
        assertFalse(r.requierePago());
    }

    @Test
    @DisplayName("R-11 monto cero queda SIN_PAGO sin registro de pago")
    void sinPago() {
        ResultadoLiquidacion r = ResultadoLiquidacion.sinPago();
        assertEquals(EstadoLiquidacion.SIN_PAGO, r.estado());
        assertEquals(0, r.montoPagar().signum());
        assertFalse(r.requierePago());
    }

    @Test
    @DisplayName("R-13 pago positivo queda LIQUIDADO y requiere pago (TC08: 4500, retención 0)")
    void liquidado() {
        ResultadoLiquidacion r = ResultadoLiquidacion.liquidado(new BigDecimal("4500.00"), BigDecimal.ZERO);
        assertEquals(EstadoLiquidacion.LIQUIDADO, r.estado());
        assertEquals("4500", r.montoPagar().stripTrailingZeros().toPlainString());
        assertEquals(0, r.retencion().signum());
        assertTrue(r.requierePago());
    }

    @Test
    @DisplayName("R-13 el constructor compacto rechaza valores nulos")
    void rechazaNulos() {
        assertThrows(NullPointerException.class,
                () -> new ResultadoLiquidacion(null, BigDecimal.ZERO, BigDecimal.ZERO));
        assertThrows(NullPointerException.class,
                () -> new ResultadoLiquidacion(EstadoLiquidacion.LIQUIDADO, null, BigDecimal.ZERO));
        assertThrows(NullPointerException.class,
                () -> new ResultadoLiquidacion(EstadoLiquidacion.LIQUIDADO, BigDecimal.ZERO, null));
    }
}
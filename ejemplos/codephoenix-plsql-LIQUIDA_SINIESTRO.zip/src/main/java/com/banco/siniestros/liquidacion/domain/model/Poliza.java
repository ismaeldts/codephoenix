package com.banco.siniestros.liquidacion.domain.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.Objects;

/** Póliza con los datos necesarios para liquidar un siniestro. */
public record Poliza(
        long id,
        String tipoProducto,
        String estado,
        LocalDateTime fechaInicio,
        BigDecimal sumaAsegurada,
        BigDecimal deducible,
        BigDecimal porcCoaseguro) {

    private static final int ESCALA = 2;
    private static final String VIGENTE = "VIGENTE";

    public Poliza {
        Objects.requireNonNull(fechaInicio, "fechaInicio");
        Objects.requireNonNull(sumaAsegurada, "sumaAsegurada");
        Objects.requireNonNull(deducible, "deducible");
        Objects.requireNonNull(porcCoaseguro, "porcCoaseguro");
        sumaAsegurada = sumaAsegurada.setScale(ESCALA, RoundingMode.HALF_UP);
        deducible = deducible.setScale(ESCALA, RoundingMode.HALF_UP);
        porcCoaseguro = porcCoaseguro.setScale(ESCALA, RoundingMode.HALF_UP);
    }

    // Regla R-05 · LIQUIDA_SINIESTRO.sql:75-78
    // Con estado NULL la comparación Oracle es desconocida y no se rechaza.
    public boolean noEstaVigente() {
        return estado != null && !VIGENTE.equals(estado);
    }

    public boolean esProducto(String producto) {
        return Objects.equals(tipoProducto, producto);
    }
}
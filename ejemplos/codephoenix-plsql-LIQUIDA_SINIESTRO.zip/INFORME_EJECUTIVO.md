# Informe ejecutivo: migración de LIQUIDA_SINIESTRO (PL/SQL)

## Resumen
Se migró el procedimiento `LIQUIDA_SINIESTRO` (93 líneas, dominio siniestros de seguros generales: AUTO, HOGAR, SALUD) a código moderno. El procedimiento decide si un siniestro se paga, calcula el monto y registra el resultado. El proceso automatizado tomó 5,6 minutos de extremo a extremo, sin contar la revisión humana.

## Reglas de negocio recuperadas
- Se descubrieron 14 reglas: 14 fueron aprobadas o ajustadas por el ingeniero y ninguna fue rechazada.
- Las 14 están trazadas al código moderno.
- Ejemplos: causales de rechazo (póliza no vigente, carencia de 90 días en SALUD y 30 en el resto, causas GUERRA o DOLO, AUTO por COMPETENCIA), tope por suma asegurada (50 % en HOGAR por INUNDACION) y retención del 2,5 % solo si el pago supera 10.000.

## Riesgos mitigados
- **Precisión numérica:** redondeo HALF_UP de Oracle replicado con `BigDecimal` y escalas explícitas.
- **Reglas tácitas:** límite inclusivo de carencia, retención estrictamente mayor a 10.000 y distinción de mayúsculas quedaron documentados.
- **Control de flujo:** los 3 `GO TO` se convirtieron en estructuras claras.
- **Código muerto:** `CALCULA_IVA` (REQ-0877), nunca invocada, no se migró.
- **Datos sensibles:** 4 enmascarados antes de usar IA.
- **Transacciones:** sin `COMMIT`, igual que el original; lo gestiona el llamador.

## Evidencia de calidad
- Equivalencia funcional: 19/19 casos idénticos frente al programa original ejecutado en Oracle Database 23ai Free, en red interna sin acceso a Internet.
- Pruebas unitarias: 129/129 exitosas; cobertura de 97,0 % en líneas y 96,3 % en ramas.
- Análisis de calidad: 0 bloqueantes, 0 críticos; complejidad máxima por método de 5.
- La generación requirió 3 intentos con autocorrección.
- Consumo de IA: 180.933 tokens de entrada y 91.024 de salida.

## Ahorro estimado frente al análisis manual
La estimación manual parte de supuestos: 12 líneas analizadas, migradas y probadas por hora, a US$45/hora. Bajo ellos, el trabajo manual equivaldría a 8 horas y US$360. El proceso automatizado tomó 5,6 minutos, sin incluir la revisión humana, que debe sumarse para una comparación completa. No se dispone de cifras de costo de la IA, por lo que no se calcula un ahorro neto en dinero.

## Próximos pasos
1. Obtener la aprobación formal de auditoría sobre la trazabilidad de las 14 reglas.
2. Ampliar los casos de equivalencia más allá de los 19 actuales, con foco en límites (carencia, 10.000 de retención).
3. Confirmar con el área de negocio que `CALCULA_IVA` puede darse de baja.
4. Validar la gestión transaccional en los sistemas llamadores.
5. Medir el tiempo de revisión humana para completar el cálculo del ahorro.
package com.banco.siniestros.liquidacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class FormateadorSalidaTest {

    @ParameterizedTest
    @CsvSource({"500.00,500", "10661.10,10661.1", "0.00,0", "4500,4500", "0.5,0.5"})
    @DisplayName("R-13 números sin ceros sobrantes ni notación científica")
    void numeros(String valor, String esperado) {
        assertEquals(esperado, FormateadorSalida.numero(new BigDecimal(valor)));
    }

    @Test
    @DisplayName("R-14 nulos se escriben como \\N")
    void nulos() {
        assertEquals("\\N", FormateadorSalida.numero(null));
        assertEquals("\\N", FormateadorSalida.texto(null));
        assertEquals("\\N", FormateadorSalida.fecha(null));
        assertEquals("X", FormateadorSalida.texto("X"));
        assertEquals("2023-01-31 00:00:00", FormateadorSalida.fecha(LocalDateTime.of(2023, 1, 31, 0, 0)));
    }

    @Test
    @DisplayName("R-14 volcado de pagos y siniestros (TC08)")
    void volcado() {
        PagoSiniestro pago = new PagoSiniestro(8, new BigDecimal("4500.00"), BigDecimal.ZERO, new BigDecimal("4500.00"));
        Siniestro s = new Siniestro(8, 1004, LocalDateTime.of(2023, 1, 31, 0, 0), new BigDecimal("5000.00"),
                "COLISION", "LIQUIDADO", new BigDecimal("4500.00"));
        Siniestro sinMonto = new Siniestro(1, 1001, LocalDateTime.of(2023, 6, 1, 0, 0), new BigDecimal("5000.00"),
                "COLISION", "ABIERTO", null);
        assertEquals(List.of(
                "ROW|PAGOS_SINIESTRO|SINIESTRO_ID=8|MONTO=4500|RETENCION=0|NETO=4500",
                "ROW|SINIESTROS|SINIESTRO_ID=8|POLIZA_ID=1004|FECHA_OCURRENCIA=2023-01-31 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=LIQUIDADO|MONTO_LIQUIDADO=4500",
                "ROW|SINIESTROS|SINIESTRO_ID=1|POLIZA_ID=1001|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=ABIERTO|MONTO_LIQUIDADO=\\N"),
                FormateadorSalida.volcar(List.of(pago), List.of(s, sinMonto)));
    }
}
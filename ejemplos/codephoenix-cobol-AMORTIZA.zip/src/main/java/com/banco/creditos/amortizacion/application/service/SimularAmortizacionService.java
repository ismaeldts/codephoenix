package com.banco.creditos.amortizacion.application.service;

import com.banco.creditos.amortizacion.application.port.in.SimularAmortizacionUseCase;
import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.CuotaFrancesa;
import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.model.TablaAmortizacion;
import com.banco.creditos.amortizacion.domain.service.CalculadorCuota;
import com.banco.creditos.amortizacion.domain.service.CalculadorTasaEfectiva;
import com.banco.creditos.amortizacion.domain.service.GeneradorTablaAmortizacion;
import com.banco.creditos.amortizacion.domain.service.ValidadorSolicitud;
import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;

/**
 * Orquesta, en el orden de 0000-PRINCIPAL: validar, ajustar tasa, calcular cuota, generar tabla.
 */
// Regla R-01 · AMORTIZA.cbl:72-85
public final class SimularAmortizacionService implements SimularAmortizacionUseCase {

    private final ValidadorSolicitud validador;
    private final CalculadorTasaEfectiva calculadorTasa;
    private final CalculadorCuota calculadorCuota;
    private final GeneradorTablaAmortizacion generadorTabla;

    public SimularAmortizacionService(
            ValidadorSolicitud validador,
            CalculadorTasaEfectiva calculadorTasa,
            CalculadorCuota calculadorCuota,
            GeneradorTablaAmortizacion generadorTabla) {
        this.validador = Objects.requireNonNull(validador);
        this.calculadorTasa = Objects.requireNonNull(calculadorTasa);
        this.calculadorCuota = Objects.requireNonNull(calculadorCuota);
        this.generadorTabla = Objects.requireNonNull(generadorTabla);
    }

    @Override
    public ResultadoSimulacion simular(SolicitudCredito solicitud) {
        Optional<CodigoError> error = validador.validar(solicitud);
        if (error.isPresent()) {
            return ResultadoSimulacion.rechazada(error.get());
        }
        BigDecimal tasaEfectiva = calculadorTasa.calcular(solicitud);
        CuotaFrancesa cuota =
                calculadorCuota.calcular(solicitud.monto(), solicitud.plazo(), tasaEfectiva);
        TablaAmortizacion tabla = generadorTabla.generar(
                solicitud.monto(), solicitud.plazo(), cuota.tasaMensual(), cuota.cuotaFija());
        return ResultadoSimulacion.exitosa(
                tasaEfectiva, solicitud.plazo(), cuota.cuotaFija(), tabla);
    }
}
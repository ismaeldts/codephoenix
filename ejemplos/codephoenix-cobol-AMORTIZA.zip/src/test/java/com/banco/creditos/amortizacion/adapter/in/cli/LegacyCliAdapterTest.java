package com.banco.creditos.amortizacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LegacyCliAdapterTest {

    private static final String TC06 = "000001000000180000006700";

    @Test
    @DisplayName("R-11 TC01 caso nominal: 14 líneas con HDR, DET y TOT del Golden Master")
    void caso_nominal() {
        List<String> salida = LegacyCliAdapter.process("000010000000180000012700");

        assertEquals(14, salida.size());
        assertEquals("HDR| 18.0000| 12|      916.80", salida.get(0));
        assertEquals(
                "DET|  1|      916.80|      150.00|      766.80|      4.50|      921.30|     9233.20",
                salida.get(1));
        assertEquals(
                "DET|  2|      916.80|      138.50|      778.30|      4.15|      920.95|     8454.90",
                salida.get(2));
        assertEquals(
                "DET|  3|      916.80|      126.82|      789.98|      3.80|      920.60|     7664.92",
                salida.get(3));
        assertEquals(
                "DET|  4|      916.80|      114.97|      801.83|      3.45|      920.25|     6863.09",
                salida.get(4));
        assertEquals(
                "DET| 12|      916.81|       13.55|      903.26|      0.41|      917.22|        0.00",
                salida.get(12));
        assertEquals("TOT|       1001.61|         30.04|      11031.65", salida.get(13));
    }

    @Test
    @DisplayName("R-14 TC06 borde mínimo: salida completa idéntica al legacy")
    void borde_minimo() {
        List<String> esperado = List.of(
                "HDR| 18.0000|  6|      175.53",
                "DET|  1|      175.53|       15.00|      160.53|      0.45|      175.98|      839.47",
                "DET|  2|      175.53|       12.59|      162.94|      0.38|      175.91|      676.53",
                "DET|  3|      175.53|       10.15|      165.38|      0.30|      175.83|      511.15",
                "DET|  4|      175.53|        7.67|      167.86|      0.23|      175.76|      343.29",
                "DET|  5|      175.53|        5.15|      170.38|      0.15|      175.68|      172.91",
                "DET|  6|      175.50|        2.59|      172.91|      0.08|      175.58|        0.00",
                "TOT|         53.15|          1.59|       1054.74");

        assertEquals(esperado, LegacyCliAdapter.process(TC06));
    }

    @Test
    @DisplayName("R-01 un registro más largo de 24 posiciones se trunca antes de validar")
    void registro_largo_se_trunca() {
        List<String> salida = LegacyCliAdapter.process(TC06 + "XYZ");

        assertEquals(8, salida.size());
        assertEquals("HDR| 18.0000|  6|      175.53", salida.get(0));
    }

    @ParameterizedTest(name = "{0}")
    @DisplayName("R-01 R-02 R-03 R-04 R-05 rechazos con salida ERR del legacy")
    @CsvSource({
        "000000999990180000012700,ERR|E01|MONTO FUERA DE RANGO",
        "500000000010180000012700,ERR|E01|MONTO FUERA DE RANGO",
        "ABCDEFGHIJK0180000012700,ERR|E00|REGISTRO DE ENTRADA INVALIDO",
        "00001000000180000012700,ERR|E00|REGISTRO DE ENTRADA INVALIDO",
        "'0000100000018000001 700',ERR|E00|REGISTRO DE ENTRADA INVALIDO",
        "000010000000180000005700,ERR|E02|PLAZO FUERA DE RANGO",
        "000010000000180000361700,ERR|E02|PLAZO FUERA DE RANGO",
        "000010000000180000012549,ERR|E03|SCORE CREDITICIO INSUFICIENTE",
        "000010000000000000012700,ERR|E04|TASA ANUAL INVALIDA"
    })
    void rechazos(String registro, String esperado) {
        assertEquals(List.of(esperado), LegacyCliAdapter.process(registro));
    }

    @Test
    @DisplayName("R-01 registro nulo o vacío se rechaza con E00")
    void registro_nulo_o_vacio() {
        List<String> esperado = List.of("ERR|E00|REGISTRO DE ENTRADA INVALIDO");

        assertEquals(esperado, LegacyCliAdapter.process(null));
        assertEquals(esperado, LegacyCliAdapter.process(""));
    }

    @Test
    @DisplayName("R-01 main lee una línea de stdin y escribe el resultado en stdout")
    void main_con_entrada_estandar() {
        String salida = ejecutarMain("000000999990180000012700\n");

        assertEquals("ERR|E01|MONTO FUERA DE RANGO" + System.lineSeparator(), salida);
    }

    @Test
    @DisplayName("R-01 main con stdin vacío produce E00")
    void main_con_entrada_vacia() {
        String salida = ejecutarMain("");

        assertEquals("ERR|E00|REGISTRO DE ENTRADA INVALIDO" + System.lineSeparator(), salida);
    }

    private static String ejecutarMain(String entrada) {
        InputStream stdinOriginal = System.in;
        PrintStream stdoutOriginal = System.out;
        ByteArrayOutputStream captura = new ByteArrayOutputStream();
        try {
            System.setIn(new ByteArrayInputStream(entrada.getBytes(StandardCharsets.UTF_8)));
            System.setOut(new PrintStream(captura, true, StandardCharsets.UTF_8));
            LegacyCliAdapter.main(new String[0]);
        } finally {
            System.setIn(stdinOriginal);
            System.setOut(stdoutOriginal);
        }
        return captura.toString(StandardCharsets.UTF_8);
    }
}
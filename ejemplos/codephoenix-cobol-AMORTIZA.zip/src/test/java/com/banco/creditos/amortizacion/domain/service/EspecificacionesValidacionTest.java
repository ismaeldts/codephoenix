package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class EspecificacionesValidacionTest {

    private static SolicitudCredito solicitud(String monto, String tasa, int plazo, int score) {
        return new SolicitudCredito(new BigDecimal(monto), new BigDecimal(tasa), plazo, score);
    }

    @Test
    @DisplayName("R-01 las especificaciones se evalúan en orden E01, E02, E03, E04")
    void ordenDeEspecificaciones() {
        List<CodigoError> codigos = EspecificacionesValidacion.enOrden().stream()
                .map(EspecificacionesValidacion.Especificacion::codigo)
                .toList();
        assertEquals(List.of(CodigoError.E01, CodigoError.E02, CodigoError.E03, CodigoError.E04), codigos);
    }

    @ParameterizedTest
    @CsvSource({
        "999.99,true", "1000.00,false", "500000000.00,false", "500000000.01,true"
    })
    @DisplayName("R-02 monto fuera de rango en las fronteras")
    void monto(String monto, boolean esperado) {
        assertEquals(esperado,
                EspecificacionesValidacion.montoFueraDeRango(solicitud(monto, "18.0000", 12, 700)));
    }

    @ParameterizedTest
    @CsvSource({"5,true", "6,false", "360,false", "361,true"})
    @DisplayName("R-03 plazo fuera de rango en las fronteras")
    void plazo(int plazo, boolean esperado) {
        assertEquals(esperado,
                EspecificacionesValidacion.plazoFueraDeRango(solicitud("10000.00", "18.0000", plazo, 700)));
    }

    @ParameterizedTest
    @CsvSource({"549,true", "550,false"})
    @DisplayName("R-04 score insuficiente en la frontera")
    void score(int score, boolean esperado) {
        assertEquals(esperado,
                EspecificacionesValidacion.scoreInsuficiente(solicitud("10000.00", "18.0000", 12, score)));
    }

    @ParameterizedTest
    @CsvSource({"0.0000,true", "0.0001,false"})
    @DisplayName("R-05 tasa anual cero")
    void tasa(String tasa, boolean esperado) {
        assertEquals(esperado,
                EspecificacionesValidacion.tasaAnualCero(solicitud("10000.00", tasa, 12, 700)));
    }

    @Test
    @DisplayName("R-02 Especificacion.rechaza delega en la condición")
    void especificacionRechaza() {
        EspecificacionesValidacion.Especificacion e = EspecificacionesValidacion.enOrden().get(0);
        assertEquals(true, e.rechaza(solicitud("999.99", "18.0000", 12, 700)));
        assertEquals(false, e.rechaza(solicitud("1000.00", "18.0000", 12, 700)));
    }
}
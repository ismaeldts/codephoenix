package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.math.BigDecimal;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.DisplayName;

class CalculadorTasaEfectivaTest {

    private final CalculadorTasaEfectiva calculador = new CalculadorTasaEfectiva();

    @ParameterizedTest
    @CsvSource({
        "700,18.0000,18.0000",
        "800,18.0000,16.5000",
        "800,6.0000,5.0000",
        "600,18.0000,20.0000",
        "600,35.0000,36.0000",
        "700,40.0000,36.0000",
        "700,36.0000,36.0000"
    })
    @DisplayName("R-06 R-07 R-08 tasa efectiva tras score, piso y tope de usura")
    void tasaEfectiva(int score, String tasa, String esperada) {
        SolicitudCredito s = new SolicitudCredito(
                new BigDecimal("10000.00"), new BigDecimal(tasa), 12, score);
        assertEquals(esperada, calculador.calcular(s).toPlainString());
    }
}
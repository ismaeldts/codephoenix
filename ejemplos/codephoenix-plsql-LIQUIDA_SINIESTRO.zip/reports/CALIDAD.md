# Reporte de calidad estática

| Métrica | Valor | Umbral |
|---|---|---|
| Archivos analizados | 29 | - |
| Líneas de código | 746 | - |
| Hallazgos bloqueantes | 0 | 0 |
| Hallazgos críticos | 0 | 0 |
| Complejidad ciclomática máxima por método | 5 | ≤ 10 |

Reglas verificadas: precisión decimal (sin double/float en el núcleo), BigDecimal desde cadena, dependencias hexagonales, secretos en código, catch vacíos, printStackTrace, complejidad.

Sin hallazgos.

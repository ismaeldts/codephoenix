package com.banco.siniestros.liquidacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.siniestros.liquidacion.domain.model.EstadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.specification.CarenciaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.ExclusionCausaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.PolizaNoVigenteSpecification;
import com.banco.siniestros.liquidacion.domain.specification.RechazoSpecification;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LiquidadorSiniestroTest {

    private static LiquidadorSiniestro liquidador() {
        return new LiquidadorSiniestro(
                List.of(new PolizaNoVigenteSpecification(),
                        new CarenciaSpecification(new PoliticaCarencia()),
                        new ExclusionCausaSpecification()),
                new PoliticaTope());
    }

    private static Poliza poliza(String producto, String estado, String inicio, String suma,
                                 String deducible, String porc) {
        return new Poliza(1L, producto, estado, LocalDateTime.parse(inicio),
                new BigDecimal(suma), new BigDecimal(deducible), new BigDecimal(porc));
    }

    private static Siniestro siniestro(String fecha, String reclamado, String causa) {
        return new Siniestro(1L, 1L, LocalDateTime.parse(fecha), new BigDecimal(reclamado),
                causa, "ABIERTO", null);
    }

    private static void assertImporte(String esperado, BigDecimal actual) {
        assertEquals(0, new BigDecimal(esperado).compareTo(actual), "esperado " + esperado + " real " + actual);
    }

    @DisplayName("R-09 R-10 R-11 R-12 R-13 cálculo de pago, retención y rechazos")
    @ParameterizedTest
    @CsvSource({
            "AUTO,COLISION,VIGENTE,5000.00,500.00,0.00,50000.00,LIQUIDADO,4500,0",
            "AUTO,COLISION,VIGENTE,5000.00,500.00,10.00,50000.00,LIQUIDADO,4050,0",
            "AUTO,COLISION,VIGENTE,400.00,500.00,0.00,50000.00,SIN_PAGO,0,0",
            "AUTO,COLISION,VIGENTE,10000.00,0.00,0.00,50000.00,LIQUIDADO,10000,0",
            "AUTO,COLISION,VIGENTE,10000.01,0.00,0.00,50000.00,LIQUIDADO,10000.01,250",
            "AUTO,COLISION,VIGENTE,10000.20,0.00,0.00,50000.00,LIQUIDADO,10000.2,250.01",
            "AUTO,COLISION,VIGENTE,100000.00,0.00,0.00,50000.00,LIQUIDADO,50000,1250",
            "HOGAR,INUNDACION,VIGENTE,100000.00,0.00,0.00,80000.00,LIQUIDADO,40000,1000",
            "AUTO,COLISION,VIGENTE,1000.00,0.00,33.33,50000.00,LIQUIDADO,666.7,0",
            "AUTO,COLISION,SUSPENDIDA,5000.00,500.00,10.00,50000.00,RECHAZADO,0,0",
            "HOGAR,GUERRA,VIGENTE,9000.00,500.00,0.00,80000.00,RECHAZADO,0,0",
            "SALUD,DOLO,VIGENTE,3000.00,0.00,0.00,80000.00,RECHAZADO,0,0",
            "AUTO,COMPETENCIA,VIGENTE,3000.00,0.00,0.00,80000.00,RECHAZADO,0,0"
    })
    void liquidacion(String producto, String causa, String estadoPoliza, String reclamado,
                     String deducible, String porc, String suma,
                     EstadoLiquidacion estado, String monto, String retencion) {
        ResultadoLiquidacion r = liquidador().liquidar(
                siniestro("2023-06-01T00:00:00", reclamado, causa),
                poliza(producto, estadoPoliza, "2022-01-01T00:00:00", suma, deducible, porc));
        assertEquals(estado, r.estado());
        assertImporte(monto, r.montoPagar());
        assertImporte(retencion, r.retencion());
    }

    @DisplayName("R-07 carencia AUTO: un día antes se rechaza (TC07)")
    @Test
    void dentroDeCarencia() {
        ResultadoLiquidacion r = liquidador().liquidar(
                siniestro("2023-01-30T00:00:00", "5000.00", "COLISION"),
                poliza("AUTO", "VIGENTE", "2023-01-01T00:00:00", "50000.00", "500.00", "0.00"));
        assertEquals(EstadoLiquidacion.RECHAZADO, r.estado());
        assertImporte("0", r.montoPagar());
    }

    @DisplayName("R-07 carencia AUTO exacta queda cubierta y paga 4500 (TC08)")
    @Test
    void finDeCarenciaCubierto() {
        ResultadoLiquidacion r = liquidador().liquidar(
                siniestro("2023-01-31T00:00:00", "5000.00", "COLISION"),
                poliza("AUTO", "VIGENTE", "2023-01-01T00:00:00", "50000.00", "500.00", "0.00"));
        assertEquals(EstadoLiquidacion.LIQUIDADO, r.estado());
        assertImporte("4500", r.montoPagar());
        assertImporte("0", r.retencion());
        assertTrue(r.requierePago());
    }

    @DisplayName("R-04 el rechazo no requiere pago y las reglas cortan en la primera que rechaza")
    @Test
    void ordenYCorte() {
        List<String> llamadas = new ArrayList<>();
        RechazoSpecification primera = (s, p) -> {
            llamadas.add("primera");
            return true;
        };
        RechazoSpecification segunda = (s, p) -> {
            llamadas.add("segunda");
            return false;
        };
        ResultadoLiquidacion r = new LiquidadorSiniestro(List.of(primera, segunda), new PoliticaTope())
                .liquidar(siniestro("2023-06-01T00:00:00", "5000.00", "COLISION"),
                        poliza("AUTO", "VIGENTE", "2022-01-01T00:00:00", "50000.00", "0.00", "0.00"));
        assertEquals(List.of("primera"), llamadas);
        assertEquals(EstadoLiquidacion.RECHAZADO, r.estado());
        assertFalse(r.requierePago());
    }

    @DisplayName("R-10 la política de tope es obligatoria")
    @Test
    void topeObligatorio() {
        assertThrows(NullPointerException.class, () -> new LiquidadorSiniestro(List.of(), null));
    }
}
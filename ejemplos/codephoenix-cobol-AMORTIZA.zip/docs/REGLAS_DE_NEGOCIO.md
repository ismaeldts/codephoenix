# Catálogo de reglas de negocio

Especificación versión 1 — El programa valida una solicitud de crédito de consumo (monto, plazo, score, tasa) y ajusta la tasa según score, piso del 5% y tope de usura del 36%. Calcula la cuota fija del sistema francés y genera la tabla de amortización con seguro de desgravamen y totales, con truncamientos y redondeos específicos.

## R-01 · Registro de entrada debe ser numérico

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `AMORTIZA.cbl:90-94` (1000-VALIDAR) |
| Confianza | 95% |
| Condición | WS-ENTRADA NOT NUMERIC |
| Acción | Código E00 'REGISTRO DE ENTRADA INVALIDO' y fin de validaciones |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si el registro completo contiene algún carácter no numérico o es más corto de 24 posiciones, se rechaza con E00. Es la primera validación.

```gherkin
Escenario: Registro no numérico
Dado un registro con letras en el monto
Cuando se valida la solicitud
Entonces se devuelve el error E00
Y no se evalúan más validaciones
```

## R-02 · Monto dentro de rango permitido

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | LIMITE |
| Origen | `AMORTIZA.cbl:95-99` (1000-VALIDAR) |
| Confianza | 97% |
| Condición | IN-MONTO < 1000.00 OR IN-MONTO > 500000000.00 |
| Acción | Código E01 'MONTO FUERA DE RANGO' |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El monto debe estar entre 1000.00 y 500000000.00 inclusive. Fuera de ese rango se rechaza con E01.

```gherkin
Escenario: Monto bajo el mínimo
Dado un monto de 500.00
Cuando se valida la solicitud
Entonces se devuelve el error E01
```

## R-03 · Plazo entre 6 y 360 meses

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | LIMITE |
| Origen | `AMORTIZA.cbl:100-104` (1000-VALIDAR) |
| Confianza | 97% |
| Condición | IN-PLAZO < 6 OR IN-PLAZO > 360 |
| Acción | Código E02 'PLAZO FUERA DE RANGO' |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El plazo debe estar entre 6 y 360 meses inclusive. Si no, se rechaza con E02.

```gherkin
Escenario: Plazo excesivo
Dado un plazo de 400 meses
Cuando se valida la solicitud
Entonces se devuelve el error E02
```

## R-04 · Score mínimo de 550

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `AMORTIZA.cbl:105-109` (1000-VALIDAR) |
| Confianza | 97% |
| Condición | IN-SCORE < 550 |
| Acción | Código E03 'SCORE CREDITICIO INSUFICIENTE' |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Un score inferior a 550 impide el otorgamiento del crédito y se rechaza con E03.

```gherkin
Escenario: Score insuficiente
Dado un score de 500
Cuando se valida la solicitud
Entonces se devuelve el error E03
```

## R-05 · Tasa anual no puede ser cero

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `AMORTIZA.cbl:110-113` (1000-VALIDAR) |
| Confianza | 95% |
| Condición | IN-TASA-ANUAL = 0 |
| Acción | Código E04 'TASA ANUAL INVALIDA' |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Una tasa anual igual a cero se rechaza con E04. Es la última validación y no necesita GO TO.

**Supuestos:**
- Se asume que las validaciones aplican en el orden E00, E01, E02, E03, E04; una solicitud con varios defectos devuelve solo el primero.

```gherkin
Escenario: Tasa cero
Dado una tasa anual de 0.0000
Cuando se valida la solicitud
Entonces se devuelve el error E04
```

## R-06 · Rebaja de tasa con piso para score alto

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `AMORTIZA.cbl:120-126` (2000-AJUSTAR-TASA) |
| Confianza | 93% |
| Condición | IN-SCORE >= 750 |
| Acción | tasa efectiva = max(tasa anual - 1.5, 5.0000) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Con score >= 750 se resta 1.5 puntos a la tasa, sin bajar del piso de 5.0000.

**Supuestos:**
- El piso solo se aplica en el tramo de score >= 750.

```gherkin
Escenario: Score alto con piso
Dado score 800 y tasa anual 6.0000
Cuando se ajusta la tasa
Entonces la tasa efectiva es 5.0000
```

## R-07 · Tramo medio sin ajuste; score bajo recargo

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `AMORTIZA.cbl:127-131` (2000-AJUSTAR-TASA) |
| Confianza | 93% |
| Condición | 650 <= IN-SCORE < 750: sin cambio; IN-SCORE < 650: recargo |
| Acción | Tramo medio: tasa efectiva = tasa anual; tramo bajo: tasa anual + 2 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Con score entre 650 y 749 la tasa no cambia. Con score entre 550 y 649 se suman 2 puntos.

**Supuestos:**
- La rama OTHER solo recibe scores entre 550 y 649, porque R-04 ya descartó los menores.

```gherkin
Escenario: Score bajo con recargo
Dado score 600 y tasa anual 20.0000
Cuando se ajusta la tasa
Entonces la tasa efectiva es 22.0000
```

## R-08 · Tope de tasa de usura 36%

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | LIMITE |
| Origen | `AMORTIZA.cbl:132-134` (2000-AJUSTAR-TASA) |
| Confianza | 95% |
| Condición | WS-TASA-EFECTIVA > 36.0000 |
| Acción | tasa efectiva = 36.0000 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Tras el ajuste por score, la tasa efectiva no puede superar 36.0000, aplicado después del piso.

**Supuestos:**
- El tope se compara contra una tasa nominal aunque el comentario del encabezado dice E.A.

```gherkin
Escenario: Tope de usura
Dado score 600 y tasa anual 35.0000
Cuando se ajusta la tasa
Entonces la tasa efectiva es 36.0000
```

## R-09 · Tasa mensual truncada a 10 decimales

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | PRECISION |
| Origen | `AMORTIZA.cbl:140-140` (3000-CALCULAR-CUOTA) |
| Confianza | 95% |
| Condición | Siempre en el cálculo de cuota |
| Acción | WS-TASA-MENSUAL = (tasa efectiva / 1200) con setScale(10, DOWN) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

La tasa mensual es tasa efectiva / 1200 y se trunca a 10 decimales al no usar ROUNDED.

```gherkin
Escenario: Tasa mensual truncada
Dado una tasa efectiva de 12.0000
Cuando se calcula la tasa mensual
Entonces es 0.0100000000
```

## R-10 · Factor de capitalización truncado por iteración

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | PRECISION |
| Origen | `AMORTIZA.cbl:141-144` (3000-CALCULAR-CUOTA) |
| Confianza | 95% |
| Condición | Para WS-I de 1 a IN-PLAZO |
| Acción | WS-FACTOR = WS-FACTOR * (1 + tasa mensual) truncado a 10 decimales en cada paso, iniciando en 1 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El factor (1+i)^n se calcula multiplicando n veces, truncando a 10 decimales en cada iteración. No equivale a una potencia exacta.

**Supuestos:**
- WS-FACTOR sin signo y con 5 enteros no desborda con los límites de plazo y tasa.

```gherkin
Escenario: Factor iterativo
Dado plazo 12 y tasa mensual 0.0100000000
Cuando se calcula el factor
Entonces se multiplica 12 veces truncando a 10 decimales cada vez
```

## R-11 · Cuota fija del sistema francés redondeada

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:145-147` (3000-CALCULAR-CUOTA) |
| Confianza | 90% |
| Condición | Siempre tras calcular el factor |
| Acción | WS-CUOTA = HALF_UP(monto * tasa mensual * factor / (factor - 1), 2) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

La cuota es monto * i * factor / (factor - 1), redondeada a 2 decimales con ROUNDED.

**Supuestos:**
- Con tasa efectiva 0 el denominador sería cero, pero R-05 y el piso lo evitan salvo tasas muy bajas con truncamiento de la tasa mensual a cero.

```gherkin
Escenario: Cuota fija
Dado monto 10000.00, tasa mensual 0.01 y plazo 12
Cuando se calcula la cuota
Entonces la cuota es 888.49
```

## R-12 · Interés del periodo sobre saldo

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:158-158` (4000-GENERAR-TABLA) |
| Confianza | 92% |
| Condición | Cada periodo de 1 a IN-PLAZO |
| Acción | WS-INTERES = HALF_UP(saldo * tasa mensual, 2) con valor absoluto |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El interés de cada periodo es saldo * tasa mensual, redondeado a 2 decimales. WS-INTERES no tiene signo.

**Supuestos:**
- Si el saldo llegara a ser negativo por el redondeo, el interés pierde el signo (campo sin signo).

```gherkin
Escenario: Interés del primer periodo
Dado saldo 10000.00 y tasa mensual 0.01
Cuando se calcula el interés
Entonces el interés es 100.00
```

## R-13 · Seguro de desgravamen sobre saldo

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:159-159` (4000-GENERAR-TABLA) |
| Confianza | 95% |
| Condición | Cada periodo |
| Acción | WS-SEGURO = HALF_UP(saldo * 0.00045, 2) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

La prima mensual es saldo * 0.00045, redondeada a 2 decimales, y se calcula sobre el saldo previo a la amortización.

```gherkin
Escenario: Seguro mensual
Dado saldo 10000.00
Cuando se calcula el seguro
Entonces el seguro es 4.50
```

## R-14 · Ajuste de la última cuota

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:160-168` (4000-GENERAR-TABLA) |
| Confianza | 95% |
| Condición | WS-PERIODO = IN-PLAZO |
| Acción | Último: amortización = saldo, cuota = amortización + interés; resto: cuota fija, amortización = cuota - interés |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

En el último periodo se amortiza todo el saldo restante y la cuota es amortización + interés. En los demás, la amortización es cuota - interés y la cuota es la fija.

**Supuestos:**
- La diferencia de redondeo se absorbe en la última cuota, que puede diferir de la cuota fija.

```gherkin
Escenario: Última cuota
Dado el periodo 12 de 12 con saldo 880.00 e interés 8.80
Cuando se calcula la cuota
Entonces la cuota del periodo es 888.80
```

## R-15 · Total del periodo incluye seguro

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:168-169` (4000-GENERAR-TABLA) |
| Confianza | 93% |
| Condición | Cada periodo |
| Acción | WS-TOTAL-PERIODO = cuota periodo + seguro; saldo = saldo - amortización |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El total a pagar del periodo es cuota del periodo + seguro. El saldo se reduce por la amortización.

```gherkin
Escenario: Total del periodo
Dado cuota 888.49 y seguro 4.50
Cuando se calcula el total
Entonces el total es 892.99
```

## R-16 · Acumulación de totales del crédito

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `AMORTIZA.cbl:170-172` (4000-GENERAR-TABLA) |
| Confianza | 95% |
| Condición | Cada periodo |
| Acción | TOT-INTERES += interés; TOT-SEGURO += seguro; TOT-PAGADO += total periodo |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Se acumulan por periodo el interés, el seguro y el total pagado, y se informan al final.

```gherkin
Escenario: Totales acumulados
Dado dos periodos con interés 100.00 y 95.00
Cuando se acumulan
Entonces el total de intereses es 195.00
```

## Tablas de decisión

### Ajuste de tasa efectiva por score, piso y usura

Reglas: R-06, R-07, R-08

| ¿Score crediticio? | ¿Tasa tras ajuste por score? | ¿Resultado frente al tope de usura (36.0000)? | → Tasa efectiva final |
|---|---|---|---|
| IN-SCORE >= 750 | (tasa - 1.5) < 5.0000 | - | 5.0000 (piso) |
| IN-SCORE >= 750 | (tasa - 1.5) >= 5.0000 y <= 36.0000 | <= 36.0000 | tasa - 1.5 |
| IN-SCORE >= 750 | (tasa - 1.5) > 36.0000 | > 36.0000 | 36.0000 (usura) |
| 650 <= IN-SCORE < 750 | - | <= 36.0000 | tasa sin cambio |
| 650 <= IN-SCORE < 750 | - | > 36.0000 | 36.0000 (usura) |
| 550 <= IN-SCORE < 650 | tasa + 2 <= 36.0000 | <= 36.0000 | tasa + 2 |
| 550 <= IN-SCORE < 650 | tasa + 2 > 36.0000 | > 36.0000 | 36.0000 (usura) |

### Validaciones de admisibilidad en orden

Reglas: R-01, R-02, R-03, R-04, R-05

| ¿Registro numérico? | ¿Monto en [1000.00, 500000000.00]? | ¿Plazo en [6, 360]? | ¿Score >= 550? | ¿Tasa anual distinta de cero? | → Resultado |
|---|---|---|---|---|---|
| No | - | - | - | - | Error E00 |
| Sí | No | - | - | - | Error E01 |
| Sí | Sí | No | - | - | Error E02 |
| Sí | Sí | Sí | No | - | Error E03 |
| Sí | Sí | Sí | Sí | No (es cero) | Error E04 |
| Sí | Sí | Sí | Sí | Sí | Solicitud admitida, se calcula la tabla |

## Lógica de infraestructura (no es regla de negocio)

- Lectura del registro de entrada de 24 posiciones con ACCEPT (línea 74) y desglose por decimales implícitos (26-30).
- Inicialización de WS-CALCULO a ceros (línea 73).
- Orquestación del flujo principal y STOP RUN (72-85).
- Formato de salida de error 'ERR|código|mensaje' con TRIM (76-78).
- Formato editado de tasa, plazo, cuota y líneas HDR (135, 148-150).
- Formato de líneas DET por periodo (175-185) y TOT de totales (186-191).
- Párrafo 9000-CALCULAR-MORA (195-197) es código muerto, nunca se invoca; no se migra (CT-TASA-MORA incluida).

package com.banco.siniestros.liquidacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PoliticaTopeTest {

    private final PoliticaTope politica = new PoliticaTope();

    private static Poliza poliza(String producto, String suma) {
        return new Poliza(1L, producto, "VIGENTE", LocalDateTime.of(2022, 1, 1, 0, 0),
                new BigDecimal(suma), BigDecimal.ZERO, BigDecimal.ZERO);
    }

    private static Siniestro siniestro(String causa) {
        return new Siniestro(1L, 1L, LocalDateTime.of(2023, 6, 1, 0, 0),
                new BigDecimal("1000"), causa, "ABIERTO", null);
    }

    @DisplayName("R-10 tope = suma asegurada, o 50% en HOGAR con INUNDACION")
    @ParameterizedTest
    @CsvSource({
            "AUTO,COLISION,50000.00,50000",
            "AUTO,INUNDACION,50000.00,50000",
            "HOGAR,INCENDIO,80000.00,80000",
            "HOGAR,INUNDACION,80000.00,40000",
            "HOGAR,INUNDACION,1000.01,500.01"
    })
    void tope(String producto, String causa, String suma, String esperado) {
        BigDecimal tope = politica.tope(siniestro(causa), poliza(producto, suma));
        assertEquals(0, new BigDecimal(esperado).compareTo(tope));
        assertEquals(2, tope.scale());
    }
}
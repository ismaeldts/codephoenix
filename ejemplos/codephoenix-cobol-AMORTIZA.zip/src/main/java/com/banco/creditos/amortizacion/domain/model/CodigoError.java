package com.banco.creditos.amortizacion.domain.model;

/**
 * Códigos de rechazo del simulador con el mensaje legacy (WS-MSG-ERROR PIC X(40)).
 */
// Regla R-01 · AMORTIZA.cbl:90-94
// Regla R-02 · AMORTIZA.cbl:95-99
// Regla R-03 · AMORTIZA.cbl:100-104
// Regla R-04 · AMORTIZA.cbl:105-109
// Regla R-05 · AMORTIZA.cbl:110-113
public enum CodigoError {
    E00("E00", "REGISTRO DE ENTRADA INVALIDO"),
    E01("E01", "MONTO FUERA DE RANGO"),
    E02("E02", "PLAZO FUERA DE RANGO"),
    E03("E03", "SCORE CREDITICIO INSUFICIENTE"),
    E04("E04", "TASA ANUAL INVALIDA");

    private static final int LONGITUD_MAXIMA_MENSAJE = 40;

    private final String codigo;
    private final String mensaje;

    CodigoError(String codigo, String mensaje) {
        if (mensaje.length() > LONGITUD_MAXIMA_MENSAJE) {
            throw new IllegalStateException("Mensaje legacy excede 40 posiciones: " + codigo);
        }
        this.codigo = codigo;
        this.mensaje = mensaje;
    }

    public String codigo() {
        return codigo;
    }

    public String mensaje() {
        return mensaje;
    }
}
package com.banco.creditos.amortizacion.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Totales acumulados del crédito (WS-TOT-INTERES, WS-TOT-SEGURO, WS-TOT-PAGADO).
 */
// Regla R-16 · AMORTIZA.cbl:170-172
public record TotalesCredito(BigDecimal interes, BigDecimal seguro, BigDecimal pagado) {

    public TotalesCredito {
        Objects.requireNonNull(interes, "interes");
        Objects.requireNonNull(seguro, "seguro");
        Objects.requireNonNull(pagado, "pagado");
    }
}
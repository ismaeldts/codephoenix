package com.banco.siniestros.liquidacion.domain.model;

/** Estados posibles del resultado de una liquidación. */
public enum EstadoLiquidacion {
    LIQUIDADO,
    SIN_PAGO,
    RECHAZADO
}
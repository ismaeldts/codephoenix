package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class CodigoErrorTest {

    @ParameterizedTest
    @CsvSource({
        "E00,REGISTRO DE ENTRADA INVALIDO",
        "E01,MONTO FUERA DE RANGO",
        "E02,PLAZO FUERA DE RANGO",
        "E03,SCORE CREDITICIO INSUFICIENTE",
        "E04,TASA ANUAL INVALIDA"
    })
    @DisplayName("R-01 a R-05 · cada código expone su mensaje legacy exacto")
    void codigoYMensajeLegacy(String codigo, String mensaje) {
        CodigoError error = CodigoError.valueOf(codigo);

        assertEquals(codigo, error.codigo());
        assertEquals(mensaje, error.mensaje());
    }

    @org.junit.jupiter.api.Test
    @DisplayName("R-01 · todos los mensajes caben en WS-MSG-ERROR PIC X(40)")
    void mensajesNoExcedenCuarentaPosiciones() {
        assertEquals(5, CodigoError.values().length);
        for (CodigoError error : CodigoError.values()) {
            assertTrue(error.mensaje().length() <= 40, error.codigo());
        }
    }
}
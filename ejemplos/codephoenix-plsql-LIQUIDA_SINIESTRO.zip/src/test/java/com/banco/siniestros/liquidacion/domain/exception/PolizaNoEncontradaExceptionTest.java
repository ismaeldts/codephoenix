package com.banco.siniestros.liquidacion.domain.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class PolizaNoEncontradaExceptionTest {

    @Test
    @DisplayName("R-03 póliza inexistente: NO_DATA_FOUND SQLCODE 100 'no data found'")
    void codigoYMensaje() {
        PolizaNoEncontradaException error = new PolizaNoEncontradaException();
        assertEquals("E03", error.codigo());
        assertEquals(100, error.sqlCode());
        assertEquals("no data found", error.getMessage());
    }
}
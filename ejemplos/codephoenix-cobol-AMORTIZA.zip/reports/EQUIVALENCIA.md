# Reporte de equivalencia funcional

Método: Golden Master. Cada entrada se ejecutó en el programa original (GnuCOBOL en un contenedor sin red) y en el código moderno; se comparó la salida línea a línea y campo a campo.

**Resultado: 20/20 casos idénticos** (intento de generación 1).

| Caso | Tipo | Descripción | Entrada | Líneas | Resultado |
|---|---|---|---|---|---|
| TC01 | NOMINAL | Caso nominal: monto 10.000,00, tasa 18,0000, plazo 12, score 700 (tramo medio sin ajuste). Cuota fija, interés, seguro, última cuota y totales | `000010000000180000012700` | 14 | ✅ idéntico |
| TC02 | ERROR | Registro con letras en el monto: 'ABCDEFGHIJK' en posiciones 1-11. Rechazo E00 | `ABCDEFGHIJK0180000012700` | 1 | ✅ idéntico |
| TC03 | ERROR | Registro incompleto de 23 posiciones (más corto que 24). Rechazo E00 | `00001000000180000012700` | 1 | ✅ idéntico |
| TC04 | ERROR | Registro con espacio y signo no numérico en el plazo/score. Rechazo E00 antes que cualquier otra validación | `0000100000018000001 700` | 1 | ✅ idéntico |
| TC05 | BORDE | Monto justo bajo el mínimo: 999,99. Rechazo E01 | `000000999990180000012700` | 1 | ✅ idéntico |
| TC06 | BORDE | Monto exactamente en el mínimo 1.000,00, plazo 6 (mínimo), score 700, tasa 18,0000. Aceptado | `000001000000180000006700` | 8 | ✅ idéntico |
| TC07 | BORDE | Monto justo sobre el máximo: 500.000.000,01. Rechazo E01 | `500000000010180000012700` | 1 | ✅ idéntico |
| TC08 | BORDE | Monto exactamente en el máximo 500.000.000,00, plazo 6, score 700, tasa 12,0000. Aceptado; prueba magnitudes grandes en totales | `500000000000120000006700` | 8 | ✅ idéntico |
| TC09 | BORDE | Plazo 5 (justo bajo el mínimo). Rechazo E02 | `000010000000180000005700` | 1 | ✅ idéntico |
| TC10 | BORDE | Plazo 361 (justo sobre el máximo). Rechazo E02 | `000010000000180000361700` | 1 | ✅ idéntico |
| TC11 | BORDE | Plazo máximo permitido 360 meses, monto 100.000,00, tasa 12,0000, score 700. Prueba truncamiento acumulado del factor en 360 iteraciones | `000100000000120000360700` | 362 | ✅ idéntico |
| TC12 | BORDE | Score 549 (justo bajo el mínimo). Rechazo E03 | `000010000000180000012549` | 1 | ✅ idéntico |
| TC13 | ERROR | Tasa anual 0 con todo lo demás válido. Rechazo E04 (última validación) | `000010000000000000012700` | 1 | ✅ idéntico |
| TC14 | BORDE | Score 550 (mínimo aceptado, tramo bajo): recargo +2, tasa 10,0000 -> 12,0000 efectiva, plazo 6 | `000020000000100000006550` | 8 | ✅ idéntico |
| TC15 | BORDE | Score 649 (último del tramo bajo): recargo +2 sobre tasa 15,5000 -> 17,5000 | `000015000000155000006649` | 8 | ✅ idéntico |
| TC16 | BORDE | Score 650 (primero del tramo medio): sin cambio, tasa 15,5000 | `000015000000155000006650` | 8 | ✅ idéntico |
| TC17 | BORDE | Score 749 (último del tramo medio) sin rebaja, tasa 20,0000 | `000015000000200000006749` | 8 | ✅ idéntico |
| TC18 | BORDE | Score 750 con rebaja de 1,5 puntos: tasa 20,0000 -> 18,5000 | `000015000000200000006750` | 8 | ✅ idéntico |
| TC19 | BORDE | Score 800 con tasa 6,0000: rebaja daría 4,5 y se aplica piso 5,0000 | `000015000000060000006800` | 8 | ✅ idéntico |
| TC20 | BORDE | Tope de usura: score 600, tasa 35,0000 + 2 = 37 -> tope 36,0000 | `000015000000350000006600` | 8 | ✅ idéntico |

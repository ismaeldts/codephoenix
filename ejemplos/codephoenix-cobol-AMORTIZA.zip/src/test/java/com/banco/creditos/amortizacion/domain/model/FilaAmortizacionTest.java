package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class FilaAmortizacionTest {

    private static BigDecimal[] valoresTc01Periodo1() {
        return new BigDecimal[] {
            new BigDecimal("916.80"), new BigDecimal("150.00"), new BigDecimal("766.80"),
            new BigDecimal("4.50"), new BigDecimal("921.30"), new BigDecimal("9233.20")
        };
    }

    private static FilaAmortizacion crear(BigDecimal[] v) {
        return new FilaAmortizacion(1, v[0], v[1], v[2], v[3], v[4], v[5]);
    }

    @Test
    @DisplayName("R-15 · TC01 periodo 1 conserva cuota, interés, amortización, seguro, total y saldo")
    void conservaValoresDelPeriodo() {
        FilaAmortizacion fila = crear(valoresTc01Periodo1());

        assertEquals(1, fila.periodo());
        assertEquals(new BigDecimal("916.80"), fila.cuota());
        assertEquals(new BigDecimal("150.00"), fila.interes());
        assertEquals(new BigDecimal("766.80"), fila.amortizacion());
        assertEquals(new BigDecimal("4.50"), fila.seguro());
        assertEquals(new BigDecimal("921.30"), fila.total());
        assertEquals(new BigDecimal("9233.20"), fila.saldo());
    }

    @Test
    @DisplayName("R-12 · el saldo y la amortización conservan el signo (campos S9)")
    void conservaSigno() {
        BigDecimal[] v = valoresTc01Periodo1();
        v[2] = new BigDecimal("-1.00");
        v[5] = new BigDecimal("-581.75");

        FilaAmortizacion fila = crear(v);

        assertEquals(new BigDecimal("-1.00"), fila.amortizacion());
        assertEquals(new BigDecimal("-581.75"), fila.saldo());
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3, 4, 5})
    @DisplayName("R-15 · cualquier importe nulo se rechaza")
    void rechazaImportesNulos(int indice) {
        BigDecimal[] v = valoresTc01Periodo1();
        v[indice] = null;

        assertThrows(NullPointerException.class, () -> crear(v));
    }
}
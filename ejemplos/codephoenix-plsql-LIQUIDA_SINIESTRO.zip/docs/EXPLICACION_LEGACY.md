# Explicación del programa legacy

### Propósito
El procedimiento `LIQUIDA_SINIESTRO` liquida un siniestro de seguros generales (AUTO, HOGAR, SALUD): decide si se paga, calcula el monto y registra el resultado.

### Entradas y salidas
- **Entrada:** `P_SINIESTRO_ID`, identificador del siniestro.
- **Salidas:** `P_MONTO_PAGAR` (monto a pagar) y `P_ESTADO` (`LIQUIDADO`, `SIN_PAGO` o `RECHAZADO`).
- **Tablas:** lee `SINIESTROS` y `POLIZAS`; inserta en `PAGOS_SINIESTRO` y actualiza `SINIESTROS`.

### Flujo principal
1. Busca el siniestro; si no existe, error -20010. Si no está `ABIERTO`, error -20011.
2. Lee la póliza. Parte de `RECHAZADO` con monto 0.
3. Salta al cierre (queda rechazado) si: la póliza no está `VIGENTE`; el siniestro ocurre antes de la carencia (90 días en SALUD, 30 en el resto); la causa es `GUERRA` o `DOLO`; o es AUTO con causa `COMPETENCIA`.
4. Base = (reclamado − deducible, mínimo 0) × (1 − coaseguro/100).
5. Tope = suma asegurada (50 % si es HOGAR por `INUNDACION`). Pago = menor entre base y tope.
6. Si el pago es 0 → `SIN_PAGO`. Si no → `LIQUIDADO`, con retención del 2,5 % cuando supera 10.000, e inserción en `PAGOS_SINIESTRO`.
7. Siempre actualiza estado y monto liquidado en `SINIESTROS`.

### Puntos de atención para la migración
- **Precisión numérica:** `V_BASE` y `V_TOPE` son NUMBER(12,2), y `V_FACTOR` es NUMBER(5,4); Oracle redondea al asignar (HALF_UP). Replicar con `BigDecimal` y escalas explícitas. Ojo: `V_BASE * V_FACTOR` se redondea a 2 decimales al asignarse, y `V_TOPE * 0.5` también.
- **Truncamientos:** `P_MONTO_PAGAR` es NUMBER sin escala, pero proviene de valores ya redondeados; la retención usa `ROUND(…, 2)`.
- **Reglas tácitas:**
  - La retención solo aplica con monto estrictamente mayor a 10.000.
  - La carencia suma días a `FECHA_INICIO`, y el límite es inclusivo (ocurrir justo en el día final de carencia sí se paga).
  - Los siniestros rechazados no generan pago, pero sí actualizan el estado.
  - Las comparaciones de estado y causa distinguen mayúsculas.
- **Control de flujo:** `GOTO fin_proceso` debe convertirse en retornos o ramas estructuradas.
- **Código muerto:** `CALCULA_IVA` (19 %) nunca se invoca (REQ-0877); no migrarla.
- **Transacciones:** no hay `COMMIT`; lo gestiona el llamador.
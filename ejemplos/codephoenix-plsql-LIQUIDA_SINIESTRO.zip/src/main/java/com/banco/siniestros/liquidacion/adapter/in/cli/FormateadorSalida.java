package com.banco.siniestros.liquidacion.adapter.in.cli;

import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Formatea la salida según el contrato de caracterización. */
final class FormateadorSalida {

    private FormateadorSalida() {
    }

    static String numero(BigDecimal valor) {
        return valor == null ? ConversorValores.NULO : valor.stripTrailingZeros().toPlainString();
    }

    static String texto(String valor) {
        return valor == null ? ConversorValores.NULO : valor;
    }

    static String fecha(LocalDateTime valor) {
        return valor == null ? ConversorValores.NULO : valor.format(ConversorValores.FORMATO_FECHA);
    }

    static List<String> volcar(List<PagoSiniestro> pagos, List<Siniestro> siniestros) {
        List<String> lineas = new ArrayList<>();
        pagos.forEach(pago -> lineas.add(filaPago(pago)));
        siniestros.forEach(siniestro -> lineas.add(filaSiniestro(siniestro)));
        return lineas;
    }

    private static String filaPago(PagoSiniestro pago) {
        return "ROW|PAGOS_SINIESTRO"
                + "|SINIESTRO_ID=" + pago.siniestroId()
                + "|MONTO=" + numero(pago.monto())
                + "|RETENCION=" + numero(pago.retencion())
                + "|NETO=" + numero(pago.neto());
    }

    private static String filaSiniestro(Siniestro s) {
        return "ROW|SINIESTROS"
                + "|SINIESTRO_ID=" + s.id()
                + "|POLIZA_ID=" + s.polizaId()
                + "|FECHA_OCURRENCIA=" + fecha(s.fechaOcurrencia())
                + "|MONTO_RECLAMADO=" + numero(s.montoReclamado())
                + "|CAUSA=" + texto(s.causa())
                + "|ESTADO=" + texto(s.estado())
                + "|MONTO_LIQUIDADO=" + numero(s.montoLiquidado());
    }
}
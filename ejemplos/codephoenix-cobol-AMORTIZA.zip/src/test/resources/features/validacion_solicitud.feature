# language: es
Característica: Validación de la solicitud de crédito
  Como auditor de crédito
  Quiero que las solicitudes inadmisibles se rechacen con el código correcto y en el orden correcto
  Para garantizar que el simulador nuevo se comporta igual que el programa AMORTIZA original

  @R-01
  Escenario: Registro con letras en el monto se rechaza con E00
    Dado el registro de entrada "ABCDEFGHIJK0180000012700"
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E00|REGISTRO DE ENTRADA INVALIDO"

  @R-01
  Escenario: Registro incompleto de 23 posiciones se rechaza con E00
    Dado el registro de entrada "00001000000180000012700"
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E00|REGISTRO DE ENTRADA INVALIDO"

  @R-01
  Escenario: Registro con un espacio en el plazo se rechaza con E00 antes que cualquier otra validación
    Dado el registro de entrada "0000100000018000001 700"
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E00|REGISTRO DE ENTRADA INVALIDO"

  @R-01
  Escenario: Registro vacío se rechaza con E00
    Dado el registro de entrada ""
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E00|REGISTRO DE ENTRADA INVALIDO"

  @R-01
  Escenario: Un registro más largo de 24 posiciones se trunca antes de validarlo
    Dado el registro de entrada "000010000000180000012700XY"
    Cuando se procesa el registro de entrada
    Entonces la simulación es aceptada
    Y la salida incluye la línea "HDR| 18.0000| 12|      916.80"

  @R-02
  Escenario: Monto justo bajo el mínimo se rechaza con E01
    Dado el registro de entrada "000000999990180000012700"
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E01|MONTO FUERA DE RANGO"

  @R-02
  Escenario: Monto justo sobre el máximo se rechaza con E01
    Dado el registro de entrada "500000000010180000012700"
    Cuando se procesa el registro de entrada
    Entonces la salida es "ERR|E01|MONTO FUERA DE RANGO"

  @R-02
  Esquema del escenario: Montos fuera del rango permitido se rechazan con E01
    Dado una solicitud con monto "<monto>", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces la salida es "ERR|E01|MONTO FUERA DE RANGO"

    Ejemplos:
      | monto        |
      | 0.00         |
      | 999.99       |
      | 500000000.01 |

  @R-02
  Esquema del escenario: Montos en los límites del rango se aceptan
    Dado una solicitud con monto "<monto>", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces la simulación es aceptada

    Ejemplos:
      | monto        |
      | 1000.00      |
      | 500000000.00 |

  @R-03
  Esquema del escenario: Plazos fuera del rango de 6 a 360 meses se rechazan con E02
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo <plazo> y score 700
    Cuando se simula el crédito
    Entonces la salida es "ERR|E02|PLAZO FUERA DE RANGO"

    Ejemplos:
      | plazo |
      | 0     |
      | 5     |
      | 361   |

  @R-03
  Esquema del escenario: Plazos en los límites del rango se aceptan
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo <plazo> y score 700
    Cuando se simula el crédito
    Entonces la simulación es aceptada
    Y la tabla tiene <plazo> periodos

    Ejemplos:
      | plazo |
      | 6     |
      | 360   |

  @R-04
  Esquema del escenario: Score inferior a 550 se rechaza con E03
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score <score>
    Cuando se simula el crédito
    Entonces la salida es "ERR|E03|SCORE CREDITICIO INSUFICIENTE"

    Ejemplos:
      | score |
      | 0     |
      | 400   |
      | 549   |

  @R-04
  Escenario: Score exactamente en 550 se acepta
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 550
    Cuando se simula el crédito
    Entonces la simulación es aceptada

  @R-05
  Escenario: Tasa anual igual a cero se rechaza con E04
    Dado una solicitud con monto "10000.00", tasa anual "0.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces la salida es "ERR|E04|TASA ANUAL INVALIDA"

  @R-02 @R-03 @R-04 @R-05
  Esquema del escenario: La primera validación que falla determina el código de rechazo
    Dado una solicitud con monto "<monto>", tasa anual "<tasa>", plazo <plazo> y score <score>
    Cuando se simula el crédito
    Entonces la salida es "<salida>"

    Ejemplos:
      | monto    | tasa   | plazo | score | salida                                |
      | 500.00   | 0.0000 | 3     | 400   | ERR\|E01\|MONTO FUERA DE RANGO         |
      | 10000.00 | 0.0000 | 3     | 400   | ERR\|E02\|PLAZO FUERA DE RANGO         |
      | 10000.00 | 0.0000 | 12    | 400   | ERR\|E03\|SCORE CREDITICIO INSUFICIENTE |
      | 10000.00 | 0.0000 | 12    | 700   | ERR\|E04\|TASA ANUAL INVALIDA          |
package com.banco.siniestros.liquidacion.domain.service;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.specification.RechazoSpecification;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;

/**
 * Servicio de dominio puro: evalúa las reglas de elegibilidad en secuencia (retorno temprano,
 * sin GO TO) y calcula el pago con BigDecimal.
 */
public final class LiquidadorSiniestro {

    private static final BigDecimal CIEN = BigDecimal.valueOf(100);
    private static final BigDecimal UMBRAL_RETENCION = BigDecimal.valueOf(10000);
    private static final BigDecimal TASA_RETENCION = new BigDecimal("0.025");
    private static final int ESCALA_FACTOR = 4;
    private static final int ESCALA_IMPORTE = 2;

    private final List<RechazoSpecification> rechazos;
    private final PoliticaTope politicaTope;

    /** Las specifications se evalúan en el orden recibido (vigencia, carencia, exclusiones). */
    public LiquidadorSiniestro(List<RechazoSpecification> rechazos, PoliticaTope politicaTope) {
        this.rechazos = List.copyOf(rechazos);
        this.politicaTope = Objects.requireNonNull(politicaTope, "politicaTope");
    }

    // Regla R-04 · LIQUIDA_SINIESTRO.sql:72-73 (resultado por defecto RECHAZADO)
    public ResultadoLiquidacion liquidar(Siniestro siniestro, Poliza poliza) {
        if (esRechazado(siniestro, poliza)) {
            return ResultadoLiquidacion.rechazado();
        }
        BigDecimal base = calcularBase(siniestro, poliza);
        BigDecimal tope = politicaTope.tope(siniestro, poliza);
        return resultadoPara(base.min(tope));
    }

    // Reglas R-05, R-07, R-08 · LIQUIDA_SINIESTRO.sql:75-94 (orden preservado, corte en el primero)
    private boolean esRechazado(Siniestro siniestro, Poliza poliza) {
        return rechazos.stream().anyMatch(regla -> regla.seRechaza(siniestro, poliza));
    }

    // Regla R-09 · LIQUIDA_SINIESTRO.sql:96-99
    private BigDecimal calcularBase(Siniestro siniestro, Poliza poliza) {
        BigDecimal base = siniestro.montoReclamado().subtract(poliza.deducible()).max(BigDecimal.ZERO);
        BigDecimal factor = BigDecimal.ONE
                .subtract(poliza.porcCoaseguro().divide(CIEN))
                .setScale(ESCALA_FACTOR, RoundingMode.HALF_UP);
        return base.multiply(factor).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP);
    }

    // Reglas R-11 y R-13 · LIQUIDA_SINIESTRO.sql:108-118
    private ResultadoLiquidacion resultadoPara(BigDecimal monto) {
        if (monto.signum() == 0) {
            return ResultadoLiquidacion.sinPago();
        }
        return ResultadoLiquidacion.liquidado(monto, calcularRetencion(monto));
    }

    // Regla R-12 · LIQUIDA_SINIESTRO.sql:112-115 (umbral estricto)
    private BigDecimal calcularRetencion(BigDecimal monto) {
        if (monto.compareTo(UMBRAL_RETENCION) > 0) {
            return monto.multiply(TASA_RETENCION).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }
}
# Auditoría de uso de IA

Todo el código enviado al modelo se enmascaró previamente (4 datos sensibles detectados). Se registra el hash SHA-256 de cada prompt, no su contenido.

| Fecha | Agente | Modelo | Hash del prompt | Tokens entrada | Tokens salida | Duración | Resultado |
|---|---|---|---|---|---|---|---|
| 2026-11-13 19:45:23 | Analista | claude-sonnet-5-5 | `8bd18134ffe8c052…` | 4687 | 1156 | 8.994 s | OK |
| 2026-11-13 19:45:52 | Extractor de reglas | claude-sonnet-5-5 | `04e05af9afde5842…` | 8879 | 5388 | 29.054 s | OK |
| 2026-11-13 19:46:17 | Arquitecto | claude-sonnet-5-5 | `7d210413a039abce…` | 6120 | 3952 | 22.866 s | OK |
| 2026-11-13 19:46:54 | QA/Tester | claude-sonnet-5-5 | `47996873b2bb5d10…` | 7792 | 8028 | 37.44 s | OK |
| 2026-11-13 19:49:16 | Desarrollador | claude-sonnet-5-5 | `d79384829485bc6c…` | 14372 | 25697 | 138.659 s | OK |
| 2026-11-13 19:49:55 | QA/Tester (pruebas dominio 1) | claude-sonnet-5-5 | `b3b8de56dea26915…` | 27779 | 5627 | 28.832 s | OK |
| 2026-11-13 19:49:59 | QA/Tester (pruebas aplicación y adaptadores 1) | claude-sonnet-5-5 | `2d75449e84fff21d…` | 27721 | 6448 | 32.841 s | OK |
| 2026-11-13 19:50:23 | QA/Tester (escenarios BDD) | claude-sonnet-5-5 | `32ed6b8104a09a43…` | 28023 | 10109 | 56.331 s | OK |
| 2026-11-13 19:50:24 | QA/Tester (pruebas dominio 2) | claude-sonnet-5-5 | `79907cfde4acd407…` | 27778 | 11449 | 57.585 s | OK |
| 2026-11-13 19:50:29 | QA/Tester (pruebas aplicación y adaptadores 2) | claude-sonnet-5-5 | `384fa1b58039c2c5…` | 27782 | 13170 | 63.206 s | OK |
| 2026-11-13 19:50:54 | Documentador | claude-sonnet-5-5 | `3b41498879111448…` | 1921 | 1238 | 9.047 s | OK |

package com.banco.siniestros.liquidacion.adapter.in.cli;

import com.banco.siniestros.liquidacion.adapter.out.persistence.PagoSiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.PolizaRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.SiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.application.port.in.LiquidarSiniestroUseCase;
import com.banco.siniestros.liquidacion.application.service.LiquidarSiniestroService;
import com.banco.siniestros.liquidacion.domain.exception.LiquidacionException;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.service.LiquidadorSiniestro;
import com.banco.siniestros.liquidacion.domain.service.PoliticaCarencia;
import com.banco.siniestros.liquidacion.domain.service.PoliticaTope;
import com.banco.siniestros.liquidacion.domain.specification.CarenciaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.ExclusionCausaSpecification;
import com.banco.siniestros.liquidacion.domain.specification.PolizaNoVigenteSpecification;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Adaptador CLI de caracterización: reproduce el contrato con el que se ejecutó
 * LIQUIDA_SINIESTRO en Oracle.
 */
public final class LegacyCliAdapter {

    private static final String PARAM_SINIESTRO_ID = "P_SINIESTRO_ID";

    private LegacyCliAdapter() {
    }

    public static List<String> process(List<String> inputLines) {
        EntradaCaracterizacion entrada = EntradaCaracterizacion.leer(inputLines);
        PolizaRepositoryEnMemoria polizas = new PolizaRepositoryEnMemoria();
        SiniestroRepositoryEnMemoria siniestros = new SiniestroRepositoryEnMemoria();
        PagoSiniestroRepositoryEnMemoria pagos = new PagoSiniestroRepositoryEnMemoria();
        new CargadorFilas(polizas, siniestros, pagos).cargar(entrada.filas());

        LiquidarSiniestroUseCase casoDeUso =
                new LiquidarSiniestroService(siniestros, polizas, pagos, construirLiquidador());

        List<String> salida = new ArrayList<>(ejecutar(casoDeUso, entrada));
        salida.addAll(FormateadorSalida.volcar(pagos.todos(), siniestros.todos()));
        return salida;
    }

    private static LiquidadorSiniestro construirLiquidador() {
        return new LiquidadorSiniestro(
                List.of(new PolizaNoVigenteSpecification(),
                        new CarenciaSpecification(new PoliticaCarencia()),
                        new ExclusionCausaSpecification()),
                new PoliticaTope());
    }

    private static List<String> ejecutar(LiquidarSiniestroUseCase casoDeUso, EntradaCaracterizacion entrada) {
        Long siniestroId = ConversorValores.entero(entrada.parametro(PARAM_SINIESTRO_ID));
        try {
            ResultadoLiquidacion resultado = casoDeUso.liquidar(siniestroId);
            return List.of(
                    "OUT|P_MONTO_PAGAR|" + FormateadorSalida.numero(resultado.montoPagar()),
                    "OUT|P_ESTADO|" + resultado.estado().name());
        } catch (LiquidacionException error) {
            return List.of("ERR|" + error.sqlCode() + "|" + error.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        String contenido = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        List<String> lineas = contenido.lines().toList();
        process(lineas).forEach(System.out::println);
    }
}
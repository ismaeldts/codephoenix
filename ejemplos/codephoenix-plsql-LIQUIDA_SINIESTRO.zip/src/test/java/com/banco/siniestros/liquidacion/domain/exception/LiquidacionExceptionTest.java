package com.banco.siniestros.liquidacion.domain.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class LiquidacionExceptionTest {

    @Test
    @DisplayName("R-01 la excepción base conserva código, SQLCODE y mensaje")
    void conservaDatos() {
        LiquidacionException error = new LiquidacionException("E99", -20999, "MENSAJE") { };
        assertEquals("E99", error.codigo());
        assertEquals(-20999, error.sqlCode());
        assertEquals("MENSAJE", error.getMessage());
        assertInstanceOf(RuntimeException.class, error);
    }
}
# Catálogo de reglas de negocio

Especificación versión 1 — El programa liquida siniestros abiertos de seguros generales, validando vigencia, carencia y exclusiones de causa. Calcula el pago aplicando deducible, coaseguro, tope por suma asegurada (sublímite del 50% en inundación de hogar) y retención del 2.5% sobre pagos mayores a 10.000.

## R-01 · Siniestro debe existir

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:59-64` (LIQUIDA_SINIESTRO) |
| Confianza | 97% |
| Condición | No hay fila en SINIESTROS con SINIESTRO_ID = p_siniestro_id |
| Acción | RAISE_APPLICATION_ERROR(-20010, 'SINIESTRO NO EXISTE') |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si no existe el siniestro se aborta con error -20010. No se modifica ninguna tabla.

```gherkin
Escenario: Siniestro inexistente
Dado que no existe el siniestro 999
Cuando se liquida el siniestro 999
Entonces se produce el error -20010 'SINIESTRO NO EXISTE'
```

## R-02 · Solo siniestros abiertos

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:66-68` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | v_sin.ESTADO <> 'ABIERTO' |
| Acción | RAISE_APPLICATION_ERROR(-20011, 'SINIESTRO YA PROCESADO') |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Un siniestro con estado distinto de ABIERTO no se reprocesa y falla con -20011. Se evalúa antes de leer la póliza.

**Supuestos:**
- ESTADO es NOT NULL, por lo que la comparación nunca es desconocida.

```gherkin
Escenario: Siniestro ya liquidado
Dado un siniestro con estado LIQUIDADO
Cuando se intenta liquidar
Entonces se produce el error -20011 'SINIESTRO YA PROCESADO'
```

## R-03 · Póliza inexistente provoca error

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:70-70` (LIQUIDA_SINIESTRO) |
| Confianza | 90% |
| Condición | No existe POLIZAS con POLIZA_ID = v_sin.POLIZA_ID |
| Acción | Se propaga NO_DATA_FOUND (100, 'no data found'); no se actualiza nada |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si la póliza del siniestro no existe, SELECT INTO lanza NO_DATA_FOUND (SQLCODE 100) sin tratamiento. El siniestro permanece sin cambios.

```gherkin
Escenario: Póliza inexistente
Dado un siniestro abierto cuya póliza no existe
Cuando se liquida
Entonces falla con SQLCODE 100 y el siniestro no cambia
```

## R-04 · Resultado por defecto rechazado

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `LIQUIDA_SINIESTRO.sql:72-73` (LIQUIDA_SINIESTRO) |
| Confianza | 93% |
| Condición | Siniestro abierto con póliza encontrada |
| Acción | p_estado := 'RECHAZADO'; p_monto_pagar := 0 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Por defecto el resultado es RECHAZADO con monto 0, que se mantiene en cualquier salto a fin_proceso.

```gherkin
Escenario: Valores iniciales
Dado un siniestro abierto con póliza
Cuando comienza la evaluación
Entonces estado RECHAZADO y monto 0 hasta que se cumplan las reglas
```

## R-05 · Póliza debe estar vigente

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:75-78` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | v_pol.ESTADO <> 'VIGENTE' |
| Acción | Salta a fin_proceso con RECHAZADO y monto 0 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si la póliza no está VIGENTE el siniestro queda RECHAZADO con monto 0. Salta a la actualización final.

```gherkin
Escenario: Póliza suspendida
Dado una póliza SUSPENDIDA
Cuando se liquida un siniestro abierto
Entonces el estado es RECHAZADO y el monto 0
```

## R-06 · Días de carencia por producto

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `LIQUIDA_SINIESTRO.sql:80-85` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | TIPO_PRODUCTO = 'SALUD' → 90; en otro caso → 30 |
| Acción | v_dias_carencia := 90 o 30 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

SALUD tiene 90 días de carencia y los demás productos 30. Se determina el periodo antes de comparar fechas.

```gherkin
Escenario: Carencia de salud
Dado una póliza de SALUD
Cuando se calcula la carencia
Entonces son 90 días
```

## R-07 · Rechazo dentro del periodo de carencia

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:86-88` (LIQUIDA_SINIESTRO) |
| Confianza | 92% |
| Condición | FECHA_OCURRENCIA < FECHA_INICIO + v_dias_carencia |
| Acción | Salta a fin_proceso con RECHAZADO y monto 0 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si la ocurrencia es anterior a inicio + carencia, se rechaza. La fecha igual al fin de carencia sí está cubierta (comparación estricta, con hora incluida).

**Supuestos:**
- DATE incluye hora; si la ocurrencia es el día 30 a las 00:00 y la hora de inicio es 00:00 se acepta.

```gherkin
Escenario: Siniestro en carencia
Dado una póliza AUTO iniciada 2024-01-01
Y ocurrencia 2024-01-20
Cuando se liquida
Entonces RECHAZADO con monto 0
```

## R-08 · Exclusiones de cobertura por causa

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | VALIDACION |
| Origen | `LIQUIDA_SINIESTRO.sql:90-94` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | CAUSA IN ('GUERRA','DOLO') OR (TIPO_PRODUCTO='AUTO' AND CAUSA='COMPETENCIA') |
| Acción | Salta a fin_proceso con RECHAZADO y monto 0 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

GUERRA y DOLO se excluyen en todos los productos. COMPETENCIA se excluye solo en AUTO.

```gherkin
Escenario: Causa excluida
Dado un siniestro AUTO por COMPETENCIA
Cuando se liquida
Entonces RECHAZADO con monto 0
```

## R-09 · Deducible y coaseguro con redondeo

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `LIQUIDA_SINIESTRO.sql:96-99` (LIQUIDA_SINIESTRO) |
| Confianza | 93% |
| Condición | Siniestro elegible |
| Acción | v_base := GREATEST(reclamado - deducible, 0); v_factor := ROUND(1 - PORC/100, 4); v_base := ROUND(v_base * v_factor, 2) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

La base es max(reclamado - deducible, 0) multiplicada por (1 - coaseguro/100). El factor se redondea a 4 decimales y la base a 2 (HALF_UP).

**Supuestos:**
- PORC_COASEGURO tiene 2 decimales, por lo que el factor cabe en 4 decimales sin pérdida real.

```gherkin
Escenario: Deducible y coaseguro
Dado reclamado 10000, deducible 500 y coaseguro 20
Cuando se calcula la base
Entonces factor 0.8 y base 7600
```

## R-10 · Tope por suma asegurada y sublímite

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | LIMITE |
| Origen | `LIQUIDA_SINIESTRO.sql:101-106` (LIQUIDA_SINIESTRO) |
| Confianza | 94% |
| Condición | TIPO_PRODUCTO='HOGAR' AND CAUSA='INUNDACION' → tope = SUMA*0.5; en otro caso SUMA |
| Acción | v_tope := ROUND(tope,2); p_monto_pagar := LEAST(v_base, v_tope) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

El tope es la suma asegurada, o el 50% si es HOGAR con causa INUNDACION. El pago es el mínimo entre base y tope, con el tope redondeado a 2 decimales.

```gherkin
Escenario: Sublímite inundación
Dado una póliza HOGAR con suma 100000 y base 70000
Y causa INUNDACION
Entonces el monto a pagar es 50000
```

## R-11 · Monto cero queda sin pago

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `LIQUIDA_SINIESTRO.sql:108-109` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | p_monto_pagar = 0 |
| Acción | p_estado := 'SIN_PAGO'; sin INSERT |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si el monto a pagar es 0 el estado es SIN_PAGO y no se inserta registro en PAGOS_SINIESTRO.

```gherkin
Escenario: Reclamo bajo deducible
Dado reclamado 300 y deducible 500
Cuando se liquida
Entonces estado SIN_PAGO y monto 0
```

## R-12 · Retención 2.5% sobre pagos grandes

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | CALCULO |
| Origen | `LIQUIDA_SINIESTRO.sql:112-115` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | p_monto_pagar > 10000 |
| Acción | v_retencion := ROUND(p_monto_pagar*0.025, 2); en otro caso 0 |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Si el pago supera 10000 se retiene el 2.5% redondeado a 2 decimales (HALF_UP); en otro caso la retención es 0. El umbral es estricto: 10000 exacto no retiene.

```gherkin
Escenario: Pago con retención
Dado un monto a pagar de 20000
Cuando se liquida
Entonces la retención es 500 y el neto 19500
```

## R-13 · Registro del pago liquidado

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `LIQUIDA_SINIESTRO.sql:110-117` (LIQUIDA_SINIESTRO) |
| Confianza | 93% |
| Condición | p_monto_pagar <> 0 |
| Acción | p_estado := 'LIQUIDADO'; INSERT PAGOS_SINIESTRO(monto, retención, monto - retención) |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

Un pago positivo queda LIQUIDADO y se registra con monto, retención y neto = monto - retención.

```gherkin
Escenario: Pago liquidado
Dado un monto a pagar de 5000
Cuando se liquida
Entonces estado LIQUIDADO y se inserta neto 5000 con retención 0
```

## R-14 · Actualización final del siniestro

| Campo | Valor |
|---|---|
| Estado | APROBADA |
| Categoría | POLITICA |
| Origen | `LIQUIDA_SINIESTRO.sql:120-124` (LIQUIDA_SINIESTRO) |
| Confianza | 95% |
| Condición | Se alcanza fin_proceso (por salto o por flujo normal) |
| Acción | UPDATE SINIESTROS SET ESTADO = p_estado, MONTO_LIQUIDADO = p_monto_pagar |
| Comentario del revisor | Aprobada en prueba de extremo a extremo |

En todos los caminos que llegan al final se guarda el estado y el monto liquidado en el siniestro, incluidos rechazos con monto 0.

```gherkin
Escenario: Rechazo persistido
Dado una póliza CANCELADA
Cuando se liquida
Entonces el siniestro queda RECHAZADO con monto liquidado 0
```

## Tablas de decisión

### Elegibilidad del siniestro para pago

Reglas: R-03, R-04, R-05, R-06

| ¿Estado póliza? | ¿Fecha ocurrencia < inicio + carencia? | ¿Causa excluida (GUERRA, DOLO o AUTO+COMPETENCIA)? | → Resultado |
|---|---|---|---|
| distinto de VIGENTE (incluye NULL no aplica) | - | - | RECHAZADO, monto 0 |
| VIGENTE | Sí | - | RECHAZADO, monto 0 |
| VIGENTE | No | Sí | RECHAZADO, monto 0 |
| VIGENTE | No | No | Continúa al cálculo del monto |

### Resultado según monto a pagar y retención

Reglas: R-10, R-11, R-12

| ¿Monto a pagar? | ¿Monto a pagar > 10000? | → Estado | → Retención | → Inserta pago |
|---|---|---|---|---|
| = 0 | - | SIN_PAGO | 0 | No |
| > 0 | No (<= 10000) | LIQUIDADO | 0 | Sí, neto = monto |
| > 0 | Sí | LIQUIDADO | ROUND(monto*0.025,2) | Sí, neto = monto - retención |

### Tope de cobertura por producto y causa

Reglas: R-09

| ¿Tipo producto? | ¿Causa? | → Tope |
|---|---|---|
| HOGAR | INUNDACION | SUMA_ASEGURADA * 0.5 |
| HOGAR | distinta de INUNDACION | SUMA_ASEGURADA |
| distinto de HOGAR | - | SUMA_ASEGURADA |

## Lógica de infraestructura (no es regla de negocio)

- Lectura del siniestro por SINIESTRO_ID con SELECT INTO (líneas 59-64).
- Lectura de la póliza asociada con SELECT INTO (línea 70).
- Inserción del registro en PAGOS_SINIESTRO (líneas 116-117), efecto de persistencia del pago.
- Función CALCULA_IVA (líneas 53-57) es código muerto, no se invoca y no se migra.
- Creación de tablas DDL (líneas 13-38) y comentarios de cabecera con credenciales enmascaradas (líneas 1-11).

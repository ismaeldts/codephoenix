package com.banco.siniestros.liquidacion.domain.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Pago registrado de un siniestro. Todos los importes con escala 2 (NUMBER(12,2)).
 */
// Regla R-13 · LIQUIDA_SINIESTRO.sql:116-117
public record PagoSiniestro(long siniestroId, BigDecimal monto, BigDecimal retencion, BigDecimal neto) {

    private static final int ESCALA = 2;

    public PagoSiniestro {
        Objects.requireNonNull(monto, "monto");
        Objects.requireNonNull(retencion, "retencion");
        Objects.requireNonNull(neto, "neto");
        monto = monto.setScale(ESCALA, RoundingMode.HALF_UP);
        retencion = retencion.setScale(ESCALA, RoundingMode.HALF_UP);
        neto = neto.setScale(ESCALA, RoundingMode.HALF_UP);
    }

    // Regla R-13 · LIQUIDA_SINIESTRO.sql:116-117 (neto = monto - retención)
    public static PagoSiniestro desde(long siniestroId, ResultadoLiquidacion resultado) {
        BigDecimal monto = resultado.montoPagar();
        BigDecimal retencion = resultado.retencion();
        return new PagoSiniestro(siniestroId, monto, retencion, monto.subtract(retencion));
    }
}
package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TablaAmortizacionTest {

    private static final TotalesCredito TOTALES = new TotalesCredito(
            new BigDecimal("1001.61"), new BigDecimal("30.04"), new BigDecimal("11031.65"));

    private static FilaAmortizacion filaPeriodo1() {
        return new FilaAmortizacion(1, new BigDecimal("916.80"), new BigDecimal("150.00"),
                new BigDecimal("766.80"), new BigDecimal("4.50"), new BigDecimal("921.30"),
                new BigDecimal("9233.20"));
    }

    @Test
    @DisplayName("R-16 · la tabla conserva las filas y los totales")
    void conservaFilasYTotales() {
        FilaAmortizacion fila = filaPeriodo1();

        TablaAmortizacion tabla = new TablaAmortizacion(List.of(fila), TOTALES);

        assertEquals(1, tabla.filas().size());
        assertSame(fila, tabla.filas().get(0));
        assertSame(TOTALES, tabla.totales());
    }

    @Test
    @DisplayName("R-16 · copia defensiva: modificar la lista original no altera la tabla")
    void copiaDefensivaEInmutable() {
        List<FilaAmortizacion> origen = new ArrayList<>();
        origen.add(filaPeriodo1());

        TablaAmortizacion tabla = new TablaAmortizacion(origen, TOTALES);
        origen.clear();

        assertEquals(1, tabla.filas().size());
        List<FilaAmortizacion> filas = tabla.filas();
        FilaAmortizacion otra = filaPeriodo1();
        assertThrows(UnsupportedOperationException.class, () -> filas.add(otra));
    }

    @Test
    @DisplayName("R-16 · totales o filas nulos se rechazan")
    void rechazaNulos() {
        List<FilaAmortizacion> filas = List.of();

        assertThrows(NullPointerException.class, () -> new TablaAmortizacion(filas, null));
        assertThrows(NullPointerException.class, () -> new TablaAmortizacion(null, TOTALES));
    }
}
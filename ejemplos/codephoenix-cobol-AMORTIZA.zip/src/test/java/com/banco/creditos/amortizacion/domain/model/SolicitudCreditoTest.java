package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class SolicitudCreditoTest {

    @Test
    @DisplayName("R-01 · TC01 conserva monto 10000.00, tasa 18.0000, plazo 12, score 700")
    void conservaValoresNominales() {
        SolicitudCredito s = new SolicitudCredito(
                new BigDecimal("10000.00"), new BigDecimal("18.0000"), 12, 700);

        assertEquals(new BigDecimal("10000.00"), s.monto());
        assertEquals(new BigDecimal("18.0000"), s.tasaAnual());
        assertEquals(12, s.plazo());
        assertEquals(700, s.score());
    }

    @Test
    @DisplayName("R-01 · normaliza escalas: monto a 2 y tasa a 4 decimales truncando")
    void normalizaEscalas() {
        SolicitudCredito s = new SolicitudCredito(
                new BigDecimal("1000.999"), new BigDecimal("18.12349"), 6, 550);

        assertEquals(new BigDecimal("1000.99"), s.monto());
        assertEquals(new BigDecimal("18.1234"), s.tasaAnual());
        assertEquals(new BigDecimal("18.0000"),
                new SolicitudCredito(BigDecimal.ONE, new BigDecimal("18"), 6, 550).tasaAnual());
    }

    @Test
    @DisplayName("R-02 · los rangos de negocio no se validan en el registro (999.99 es aceptado)")
    void noValidaRangosDeNegocio() {
        SolicitudCredito s = new SolicitudCredito(
                new BigDecimal("999.99"), BigDecimal.ZERO, 0, 0);

        assertEquals(new BigDecimal("999.99"), s.monto());
        assertEquals(new BigDecimal("0.0000"), s.tasaAnual());
        assertEquals(0, s.plazo());
        assertEquals(0, s.score());
    }

    @ParameterizedTest
    @CsvSource({
        "-0.01,18.0000,12,700",
        "10000.00,-18.0000,12,700",
        "10000.00,18.0000,-1,700",
        "10000.00,18.0000,12,-1"
    })
    @DisplayName("R-01 · campos numéricos sin signo: un valor negativo se rechaza")
    void rechazaNegativos(String monto, String tasa, int plazo, int score) {
        BigDecimal m = new BigDecimal(monto);
        BigDecimal t = new BigDecimal(tasa);

        assertThrows(IllegalArgumentException.class, () -> new SolicitudCredito(m, t, plazo, score));
    }

    @Test
    @DisplayName("R-01 · monto y tasa nulos se rechazan")
    void rechazaNulos() {
        assertThrows(NullPointerException.class,
                () -> new SolicitudCredito(null, BigDecimal.ONE, 12, 700));
        assertThrows(NullPointerException.class,
                () -> new SolicitudCredito(BigDecimal.ONE, null, 12, 700));
    }
}
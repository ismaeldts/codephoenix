package com.banco.siniestros.liquidacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.siniestros.liquidacion.adapter.out.persistence.PagoSiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.PolizaRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.SiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CargadorFilasTest {

    private final PolizaRepositoryEnMemoria polizas = new PolizaRepositoryEnMemoria();
    private final SiniestroRepositoryEnMemoria siniestros = new SiniestroRepositoryEnMemoria();
    private final PagoSiniestroRepositoryEnMemoria pagos = new PagoSiniestroRepositoryEnMemoria();
    private final CargadorFilas cargador = new CargadorFilas(polizas, siniestros, pagos);

    private static EntradaCaracterizacion.Fila fila(String tabla, String... pares) {
        Map<String, String> columnas = new LinkedHashMap<>();
        for (int i = 0; i < pares.length; i += 2) {
            columnas.put(pares[i], pares[i + 1]);
        }
        return new EntradaCaracterizacion.Fila(tabla, columnas);
    }

    @Test
    @DisplayName("R-05 carga póliza con todas sus columnas")
    void cargaPoliza() {
        cargador.cargar(List.of(fila("POLIZAS", "POLIZA_ID", "1002", "TIPO_PRODUCTO", "AUTO",
                "ESTADO", "SUSPENDIDA", "FECHA_INICIO", "2023-01-01", "SUMA_ASEGURADA", "50000.00",
                "DEDUCIBLE", "500.00", "PORC_COASEGURO", "10.00")));
        Poliza p = polizas.buscarPorId(1002L).orElseThrow();
        assertEquals("AUTO", p.tipoProducto());
        assertEquals("SUSPENDIDA", p.estado());
        assertEquals(LocalDateTime.of(2023, 1, 1, 0, 0), p.fechaInicio());
        assertEquals(0, new BigDecimal("10").compareTo(p.porcCoaseguro()));
    }

    @Test
    @DisplayName("R-09 coaseguro ausente se carga como cero")
    void coaseguroAusenteEsCero() {
        cargador.cargar(List.of(fila("POLIZAS", "POLIZA_ID", "1", "TIPO_PRODUCTO", "HOGAR",
                "ESTADO", "VIGENTE", "FECHA_INICIO", "2022-01-01", "SUMA_ASEGURADA", "80000.00",
                "DEDUCIBLE", "0.00", "PORC_COASEGURO", "\\N")));
        assertEquals(0, polizas.buscarPorId(1L).orElseThrow().porcCoaseguro().signum());
    }

    @Test
    @DisplayName("R-01 carga siniestro con monto liquidado nulo")
    void cargaSiniestro() {
        cargador.cargar(List.of(fila("SINIESTROS", "SINIESTRO_ID", "5", "POLIZA_ID", "1002",
                "FECHA_OCURRENCIA", "2023-06-01", "MONTO_RECLAMADO", "5000.00", "CAUSA", "COLISION",
                "ESTADO", "ABIERTO", "MONTO_LIQUIDADO", "\\N")));
        Siniestro s = siniestros.buscarPorId(5L).orElseThrow();
        assertEquals(1002L, s.polizaId());
        assertEquals("COLISION", s.causa());
        assertEquals("ABIERTO", s.estado());
        assertNull(s.montoLiquidado());
    }

    @Test
    @DisplayName("R-13 carga pago existente e ignora tablas desconocidas")
    void cargaPagoEIgnoraDesconocidas() {
        cargador.cargar(List.of(
                fila("PAGOS_SINIESTRO", "SINIESTRO_ID", "8", "MONTO", "4500.00", "RETENCION", "0.00", "NETO", "4500.00"),
                fila("OTRA", "X", "1")));
        assertEquals(1, pagos.todos().size());
        assertEquals(8L, pagos.todos().get(0).siniestroId());
        assertTrue(polizas.buscarPorId(1L).isEmpty());
        assertTrue(siniestros.todos().isEmpty());
    }
}
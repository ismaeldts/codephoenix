package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.FilaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.TablaAmortizacion;
import com.banco.creditos.amortizacion.domain.model.TotalesCredito;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * 4000-GENERAR-TABLA: interés, seguro, ajuste de la última cuota, total, saldo y acumulados.
 */
public final class GeneradorTablaAmortizacion {

    private static final BigDecimal TASA_SEGURO = new BigDecimal("0.00045");
    private static final int ESCALA_IMPORTE = 2;

    public TablaAmortizacion generar(
            BigDecimal monto, int plazo, BigDecimal tasaMensual, BigDecimal cuotaFija) {
        List<FilaAmortizacion> filas = new ArrayList<>(plazo);
        BigDecimal saldo = importe(monto);
        BigDecimal totalInteres = importe(BigDecimal.ZERO);
        BigDecimal totalSeguro = importe(BigDecimal.ZERO);
        BigDecimal totalPagado = importe(BigDecimal.ZERO);
        for (int periodo = 1; periodo <= plazo; periodo++) {
            FilaAmortizacion fila =
                    generarFila(periodo, plazo, saldo, tasaMensual, cuotaFija);
            filas.add(fila);
            saldo = fila.saldo();
            // Regla R-16 · AMORTIZA.cbl:170-172
            totalInteres = importe(totalInteres.add(fila.interes()));
            totalSeguro = importe(totalSeguro.add(fila.seguro()));
            totalPagado = importe(totalPagado.add(fila.total()));
        }
        return new TablaAmortizacion(filas, new TotalesCredito(totalInteres, totalSeguro, totalPagado));
    }

    private FilaAmortizacion generarFila(
            int periodo, int plazo, BigDecimal saldo, BigDecimal tasaMensual, BigDecimal cuotaFija) {
        BigDecimal interes = interesDelPeriodo(saldo, tasaMensual);
        BigDecimal seguro = seguroDelPeriodo(saldo);
        boolean ultimo = periodo == plazo;
        BigDecimal amortizacion = ultimo ? saldo : importe(cuotaFija.subtract(interes));
        BigDecimal cuotaPeriodo = ultimo ? importe(amortizacion.add(interes).abs()) : cuotaFija;
        BigDecimal nuevoSaldo = importe(saldo.subtract(amortizacion));
        BigDecimal total = importe(cuotaPeriodo.add(seguro).abs());
        return new FilaAmortizacion(
                periodo, cuotaPeriodo, interes, amortizacion, seguro, total, nuevoSaldo);
    }

    // Regla R-12 · AMORTIZA.cbl:158-158
    // WS-INTERES es PIC 9(9)V99 sin signo: un saldo negativo se almacena en valor absoluto.
    private static BigDecimal interesDelPeriodo(BigDecimal saldo, BigDecimal tasaMensual) {
        return saldo.multiply(tasaMensual).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP).abs();
    }

    // Regla R-13 · AMORTIZA.cbl:159-159
    // Calculado sobre el saldo previo a la amortización; WS-SEGURO es sin signo.
    private static BigDecimal seguroDelPeriodo(BigDecimal saldo) {
        return saldo.multiply(TASA_SEGURO).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP).abs();
    }

    private static BigDecimal importe(BigDecimal valor) {
        return valor.setScale(ESCALA_IMPORTE, RoundingMode.DOWN);
    }
}
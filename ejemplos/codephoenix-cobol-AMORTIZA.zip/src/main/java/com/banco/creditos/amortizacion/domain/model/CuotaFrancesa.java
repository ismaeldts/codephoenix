package com.banco.creditos.amortizacion.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Resultado del cálculo de cuota: tasa mensual (escala 10) y cuota fija (escala 2).
 */
// Regla R-09 · AMORTIZA.cbl:140-140
// Regla R-11 · AMORTIZA.cbl:145-147
public record CuotaFrancesa(BigDecimal tasaMensual, BigDecimal cuotaFija) {

    public CuotaFrancesa {
        Objects.requireNonNull(tasaMensual, "tasaMensual");
        Objects.requireNonNull(cuotaFija, "cuotaFija");
    }
}
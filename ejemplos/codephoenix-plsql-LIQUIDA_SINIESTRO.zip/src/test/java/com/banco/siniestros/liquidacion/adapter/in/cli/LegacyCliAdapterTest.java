package com.banco.siniestros.liquidacion.adapter.in.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class LegacyCliAdapterTest {

    private static final String POL_AUTO_VIGENTE =
            "ROW|POLIZAS|POLIZA_ID=1004|TIPO_PRODUCTO=AUTO|ESTADO=VIGENTE|FECHA_INICIO=2023-01-01"
                    + "|SUMA_ASEGURADA=50000.00|DEDUCIBLE=500.00|PORC_COASEGURO=0.00";

    private static String siniestro(int id, int poliza, String fecha, String monto, String causa, String estado,
                                    String liquidado) {
        return "ROW|SINIESTROS|SINIESTRO_ID=" + id + "|POLIZA_ID=" + poliza + "|FECHA_OCURRENCIA=" + fecha
                + "|MONTO_RECLAMADO=" + monto + "|CAUSA=" + causa + "|ESTADO=" + estado
                + "|MONTO_LIQUIDADO=" + liquidado;
    }

    @Test
    @DisplayName("R-05 TC05 póliza suspendida: RECHAZADO monto 0")
    void tc05() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|5",
                "ROW|POLIZAS|POLIZA_ID=1002|TIPO_PRODUCTO=AUTO|ESTADO=SUSPENDIDA|FECHA_INICIO=2023-01-01"
                        + "|SUMA_ASEGURADA=50000.00|DEDUCIBLE=500.00|PORC_COASEGURO=10.00",
                siniestro(5, 1002, "2023-06-01", "5000.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|RECHAZADO",
                "ROW|SINIESTROS|SINIESTRO_ID=5|POLIZA_ID=1002|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-08 TC11 exclusión GUERRA en HOGAR")
    void tc11() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|11",
                "ROW|POLIZAS|POLIZA_ID=1006|TIPO_PRODUCTO=HOGAR|ESTADO=VIGENTE|FECHA_INICIO=2022-01-01"
                        + "|SUMA_ASEGURADA=80000.00|DEDUCIBLE=500.00|PORC_COASEGURO=0.00",
                siniestro(11, 1006, "2023-06-01", "9000.00", "GUERRA", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|RECHAZADO",
                "ROW|SINIESTROS|SINIESTRO_ID=11|POLIZA_ID=1006|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=9000|CAUSA=GUERRA|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-08 TC12 exclusión DOLO en SALUD")
    void tc12() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|12",
                "ROW|POLIZAS|POLIZA_ID=1007|TIPO_PRODUCTO=SALUD|ESTADO=VIGENTE|FECHA_INICIO=2022-01-01"
                        + "|SUMA_ASEGURADA=80000.00|DEDUCIBLE=0.00|PORC_COASEGURO=0.00",
                siniestro(12, 1007, "2023-06-01", "3000.00", "DOLO", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|RECHAZADO",
                "ROW|SINIESTROS|SINIESTRO_ID=12|POLIZA_ID=1007|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=3000|CAUSA=DOLO|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-05 TC06 póliza cancelada")
    void tc06() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|6",
                "ROW|POLIZAS|POLIZA_ID=1003|TIPO_PRODUCTO=HOGAR|ESTADO=CANCELADA|FECHA_INICIO=2023-01-01"
                        + "|SUMA_ASEGURADA=50000.00|DEDUCIBLE=500.00|PORC_COASEGURO=0.00",
                siniestro(6, 1003, "2023-06-01", "5000.00", "INCENDIO", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|RECHAZADO",
                "ROW|SINIESTROS|SINIESTRO_ID=6|POLIZA_ID=1003|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=INCENDIO|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-07 TC07 dentro de la carencia AUTO")
    void tc07() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|7", POL_AUTO_VIGENTE,
                siniestro(7, 1004, "2023-01-30", "5000.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|RECHAZADO",
                "ROW|SINIESTROS|SINIESTRO_ID=7|POLIZA_ID=1004|FECHA_OCURRENCIA=2023-01-30 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-13 TC08 carencia exacta: LIQUIDADO 4500 con pago")
    void tc08() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|8", POL_AUTO_VIGENTE,
                siniestro(8, 1004, "2023-01-31", "5000.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|4500", "OUT|P_ESTADO|LIQUIDADO",
                "ROW|PAGOS_SINIESTRO|SINIESTRO_ID=8|MONTO=4500|RETENCION=0|NETO=4500",
                "ROW|SINIESTROS|SINIESTRO_ID=8|POLIZA_ID=1004|FECHA_OCURRENCIA=2023-01-31 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=LIQUIDADO|MONTO_LIQUIDADO=4500"), out);
    }

    @Test
    @DisplayName("R-12 pago mayor a 10000 aplica retención 2.5%")
    void retencion() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|20", POL_AUTO_VIGENTE,
                siniestro(20, 1004, "2023-06-01", "20500.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals("OUT|P_MONTO_PAGAR|20000", out.get(0));
        assertEquals("ROW|PAGOS_SINIESTRO|SINIESTRO_ID=20|MONTO=20000|RETENCION=500|NETO=19500", out.get(2));
    }

    @Test
    @DisplayName("R-11 monto cero queda SIN_PAGO sin insertar pago")
    void sinPago() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|21", POL_AUTO_VIGENTE,
                siniestro(21, 1004, "2023-06-01", "300.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("OUT|P_MONTO_PAGAR|0", "OUT|P_ESTADO|SIN_PAGO",
                "ROW|SINIESTROS|SINIESTRO_ID=21|POLIZA_ID=1004|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=300|CAUSA=COLISION|ESTADO=SIN_PAGO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-01 TC01 siniestro inexistente")
    void tc01() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|999",
                "ROW|POLIZAS|POLIZA_ID=1001|TIPO_PRODUCTO=AUTO|ESTADO=VIGENTE|FECHA_INICIO=2023-01-01"
                        + "|SUMA_ASEGURADA=50000.00|DEDUCIBLE=500.00|PORC_COASEGURO=10.00",
                siniestro(1, 1001, "2023-06-01", "5000.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("ERR|-20010|SINIESTRO NO EXISTE",
                "ROW|SINIESTROS|SINIESTRO_ID=1|POLIZA_ID=1001|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=ABIERTO|MONTO_LIQUIDADO=\\N"), out);
    }

    @Test
    @DisplayName("R-01 parámetro ausente equivale a NULL: siniestro no existe")
    void parametroAusente() {
        List<String> out = LegacyCliAdapter.process(List.of());
        assertEquals(List.of("ERR|-20010|SINIESTRO NO EXISTE"), out);
    }

    @Test
    @DisplayName("R-02 TC02 ya procesado se evalúa antes de leer la póliza")
    void tc02() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|2", POL_AUTO_VIGENTE,
                siniestro(2, 7777, "2023-06-01", "5000.00", "COLISION", "LIQUIDADO", "4000.00")));
        assertEquals(List.of("ERR|-20011|SINIESTRO YA PROCESADO",
                "ROW|SINIESTROS|SINIESTRO_ID=2|POLIZA_ID=7777|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=LIQUIDADO|MONTO_LIQUIDADO=4000"), out);
    }

    @Test
    @DisplayName("R-02 TC03 estado RECHAZADO también falla con -20011")
    void tc03() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|3", POL_AUTO_VIGENTE,
                siniestro(3, 1004, "2023-06-01", "5000.00", "COLISION", "RECHAZADO", "0.00")));
        assertEquals(List.of("ERR|-20011|SINIESTRO YA PROCESADO",
                "ROW|SINIESTROS|SINIESTRO_ID=3|POLIZA_ID=1004|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=RECHAZADO|MONTO_LIQUIDADO=0"), out);
    }

    @Test
    @DisplayName("R-03 póliza inexistente propaga NO_DATA_FOUND (100) sin cambios")
    void polizaInexistente() {
        List<String> out = LegacyCliAdapter.process(List.of("PARAM|P_SINIESTRO_ID|4",
                siniestro(4, 7777, "2023-06-01", "5000.00", "COLISION", "ABIERTO", "\\N")));
        assertEquals(List.of("ERR|100|no data found",
                "ROW|SINIESTROS|SINIESTRO_ID=4|POLIZA_ID=7777|FECHA_OCURRENCIA=2023-06-01 00:00:00"
                        + "|MONTO_RECLAMADO=5000|CAUSA=COLISION|ESTADO=ABIERTO|MONTO_LIQUIDADO=\\N"), out);
    }
}
package com.banco.creditos.amortizacion.domain.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Strategy de ajuste de tasa por tramo de score (EVALUATE TRUE de 2000-AJUSTAR-TASA).
 * El orden de las constantes refleja el orden de evaluación de los WHEN.
 */
public enum EstrategiaTasaPorScore {

    // Regla R-06 · AMORTIZA.cbl:120-126
    ALTO {
        @Override
        public BigDecimal ajustar(BigDecimal tasaAnual) {
            BigDecimal rebajada = tasaAnual.subtract(REBAJA);
            BigDecimal resultado = rebajada.compareTo(PISO) < 0 ? PISO : rebajada;
            return resultado.setScale(4, RoundingMode.DOWN);
        }
    },

    // Regla R-07 · AMORTIZA.cbl:127-128
    MEDIO {
        @Override
        public BigDecimal ajustar(BigDecimal tasaAnual) {
            return tasaAnual.setScale(4, RoundingMode.DOWN);
        }
    },

    // Regla R-07 · AMORTIZA.cbl:129-130
    BAJO {
        @Override
        public BigDecimal ajustar(BigDecimal tasaAnual) {
            // WS-TASA-EFECTIVA es S9(3)V9(4): se conservan solo 3 dígitos enteros.
            return tasaAnual.add(RECARGO).remainder(LIMITE_CAMPO).setScale(4, RoundingMode.DOWN);
        }
    };

    private static final BigDecimal REBAJA = new BigDecimal("1.5");
    private static final BigDecimal RECARGO = new BigDecimal("2");
    private static final BigDecimal PISO = new BigDecimal("5.0000");
    private static final BigDecimal LIMITE_CAMPO = new BigDecimal("1000");
    private static final int SCORE_ALTO = 750;
    private static final int SCORE_MEDIO = 650;

    public abstract BigDecimal ajustar(BigDecimal tasaAnual);

    // Regla R-06 · AMORTIZA.cbl:121-122
    // Regla R-07 · AMORTIZA.cbl:127-129
    public static EstrategiaTasaPorScore para(int score) {
        if (score >= SCORE_ALTO) {
            return ALTO;
        }
        if (score >= SCORE_MEDIO) {
            return MEDIO;
        }
        return BAJO;
    }
}
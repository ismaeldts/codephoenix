package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class SolicitudInvalidaExceptionTest {

    @ParameterizedTest
    @CsvSource({
        "E00,E00 REGISTRO DE ENTRADA INVALIDO",
        "E01,E01 MONTO FUERA DE RANGO",
        "E04,E04 TASA ANUAL INVALIDA"
    })
    @DisplayName("R-01 · la excepción lleva el código de negocio y su mensaje")
    void llevaCodigoYMensaje(String codigo, String mensajeEsperado) {
        CodigoError error = CodigoError.valueOf(codigo);

        SolicitudInvalidaException ex = new SolicitudInvalidaException(error);

        assertSame(error, ex.codigoError());
        assertEquals(mensajeEsperado, ex.getMessage());
    }
}
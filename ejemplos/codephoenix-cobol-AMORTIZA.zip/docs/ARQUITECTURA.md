# Arquitectura destino

Se modela el simulador de amortización como un núcleo de dominio puro (sistema francés) con arquitectura hexagonal. Las validaciones se expresan como Specifications evaluadas en orden, el ajuste de tasa como Strategy por tramo de score y la creación de la solicitud mediante una Factory que parsea el registro de ancho fijo. Un adaptador CLI reproduce el contrato de E/S legacy y un contrato REST soporta el Strangler Fig. El código muerto 9000-CALCULAR-MORA no se migra.

Paquete base: `com.banco.creditos.amortizacion`

```mermaid
flowchart LR
  CLI[AmortizaCli] --> FMT[FormateadorSalidaLegacy]
  CLI --> PIN[SimularAmortizacionUseCase]
  REST[AdaptadorRestFuturo] --> PIN
  PIN --> APP[SimularAmortizacionService]
  APP --> FAC[SolicitudFactory]
  APP --> VAL[ValidadorSolicitud]
  VAL --> SPEC[EspecificacionesValidacion]
  APP --> TASA[CalculadorTasaEfectiva]
  TASA --> STR[EstrategiaTasaPorScore]
  APP --> CUOTA[CalculadorCuota]
  APP --> TABLA[GeneradorTablaAmortizacion]
  TABLA --> RES[ResultadoSimulacion]
```

| Elemento | Tipo | Capa | Responsabilidad |
|---|---|---|---|
| SolicitudCredito | VALUE_OBJECT | DOMINIO | Record inmutable con monto (escala 2), tasa anual (escala 4), plazo y score. Representa el registro de entrada ya interpretado. |
| CodigoError | VALUE_OBJECT | DOMINIO | Enum E00-E04 con mensaje legacy de hasta 40 posiciones. Soporta R-01 a R-05. |
| SolicitudFactory | DOMAIN_SERVICE | DOMINIO | Factory que valida que el registro sea numérico y de al menos 24 posiciones y construye la solicitud con las escalas exactas. Implementa R-01. |
| EspecificacionesValidacion | SPECIFICATION | DOMINIO | Specifications ordenadas: monto en rango, plazo 6-360, score mínimo 550, tasa distinta de cero. Primer fallo corta la evaluación sin GO TO. Implementa R-02 a R-05. |
| ValidadorSolicitud | DOMAIN_SERVICE | DOMINIO | Evalúa las specifications en orden fijo y devuelve el primer CodigoError o vacío, reemplazando 1000-VALIDAR y su EXIT. Cubre R-01 a R-05. |
| EstrategiaTasaPorScore | DOMAIN_SERVICE | DOMINIO | Strategy por tramo: score >=750 resta 1.5 con piso 5.0000, 650-749 sin cambio, <650 suma 2. Implementa R-06 y R-07. |
| CalculadorTasaEfectiva | DOMAIN_SERVICE | DOMINIO | Selecciona la estrategia según score y aplica después el tope de usura 36.0000. Implementa R-06, R-07 y R-08. |
| CalculadorCuota | DOMAIN_SERVICE | DOMINIO | Calcula tasa mensual truncada a 10 decimales, factor iterativo truncado en cada paso y cuota francesa HALF_UP a 2 decimales. Implementa R-09, R-10 y R-11. |
| GeneradorTablaAmortizacion | DOMAIN_SERVICE | DOMINIO | Genera cada periodo: interés, seguro 0.00045 sobre saldo previo, ajuste de última cuota, total y saldo. Acumula totales. Implementa R-12 a R-16. |
| ResultadoSimulacion | VALUE_OBJECT | DOMINIO | Record con tasa efectiva, plazo, cuota fija, lista de FilaAmortizacion y TotalesCredito, o el error de validación. |
| SimularAmortizacionUseCase | PORT_IN | APLICACION | Puerto de entrada que recibe una solicitud y devuelve el ResultadoSimulacion. Lo usan el CLI y el futuro adaptador REST. |
| SimularAmortizacionService | APPLICATION_SERVICE | APLICACION | Orquesta validación, tasa efectiva, cuota y tabla sin lógica propia ni E/S. Implementa el caso de uso respetando el orden del legacy. |
| AmortizaCli | ADAPTER_IN | ADAPTADOR | Lee el registro de ancho fijo desde stdin, invoca el caso de uso y escribe la salida idéntica al legacy con formatos editados. |
| FormateadorSalidaLegacy | ADAPTER_IN | ADAPTADOR | Reproduce las máscaras ZZ9.9999, Z(8)9.99 y similares y los mensajes de error para garantizar equivalencia byte a byte. |

## Decisiones de arquitectura

- [ADR-001: Precisión numérica: COMP-3 a BigDecimal](adr/ADR-001.md)
- [ADR-002: Eliminación del GO TO de validación](adr/ADR-002.md)
- [ADR-003: Arquitectura hexagonal con dominio puro](adr/ADR-003.md)
- [ADR-004: Strategy para ajuste de tasa y exclusión de código muerto](adr/ADR-004.md)

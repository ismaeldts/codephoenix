package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.util.Optional;

/**
 * Sustituye 1000-VALIDAR / 1000-VALIDAR-EXIT: el primer fallo corta la evaluación.
 */
// Regla R-02 · AMORTIZA.cbl:95-99
// Regla R-03 · AMORTIZA.cbl:100-104
// Regla R-04 · AMORTIZA.cbl:105-109
// Regla R-05 · AMORTIZA.cbl:110-113
public final class ValidadorSolicitud {

    public Optional<CodigoError> validar(SolicitudCredito solicitud) {
        return EspecificacionesValidacion.enOrden().stream()
                .filter(especificacion -> especificacion.rechaza(solicitud))
                .map(EspecificacionesValidacion.Especificacion::codigo)
                .findFirst();
    }
}
package com.banco.siniestros.liquidacion.domain.service;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Strategy del tope de pago: suma asegurada o sublímite de inundación en HOGAR. */
// Regla R-10 · LIQUIDA_SINIESTRO.sql:101-106
public final class PoliticaTope {

    private static final String HOGAR = "HOGAR";
    private static final String INUNDACION = "INUNDACION";
    private static final BigDecimal SUBLIMITE_INUNDACION = new BigDecimal("0.5");
    private static final int ESCALA = 2;

    public BigDecimal tope(Siniestro siniestro, Poliza poliza) {
        BigDecimal tope = poliza.sumaAsegurada();
        if (poliza.esProducto(HOGAR) && siniestro.causaEs(INUNDACION)) {
            tope = poliza.sumaAsegurada().multiply(SUBLIMITE_INUNDACION);
        }
        return tope.setScale(ESCALA, RoundingMode.HALF_UP);
    }
}
package com.banco.siniestros.liquidacion.domain.exception;

/**
 * Error de negocio de la liquidación de siniestros.
 * Lleva un código de dominio (E01...) y el SQLCODE equivalente del legacy Oracle.
 */
public abstract class LiquidacionException extends RuntimeException {

    private final String codigo;
    private final int sqlCode;

    protected LiquidacionException(String codigo, int sqlCode, String mensaje) {
        super(mensaje);
        this.codigo = codigo;
        this.sqlCode = sqlCode;
    }

    public String codigo() {
        return codigo;
    }

    public int sqlCode() {
        return sqlCode;
    }
}
package com.banco.siniestros.liquidacion.domain.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class SiniestroYaProcesadoExceptionTest {

    @Test
    @DisplayName("R-02 siniestro ya procesado: -20011 'SINIESTRO YA PROCESADO' (TC02, TC03)")
    void codigoYMensaje() {
        SiniestroYaProcesadoException error = new SiniestroYaProcesadoException();
        assertEquals("E02", error.codigo());
        assertEquals(-20011, error.sqlCode());
        assertEquals("SINIESTRO YA PROCESADO", error.getMessage());
    }
}
package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class EstrategiaTasaPorScoreTest {

    @ParameterizedTest
    @CsvSource({
        "550,BAJO", "649,BAJO", "650,MEDIO", "749,MEDIO", "750,ALTO", "900,ALTO"
    })
    @DisplayName("R-06 R-07 selección de estrategia por tramo de score")
    void seleccion(int score, EstrategiaTasaPorScore esperada) {
        assertEquals(esperada, EstrategiaTasaPorScore.para(score));
    }

    @ParameterizedTest
    @CsvSource({
        "18.0000,16.5000", "6.5000,5.0000", "6.0000,5.0000", "7.0000,5.5000"
    })
    @DisplayName("R-06 score alto rebaja 1.5 con piso 5.0000")
    void alto(String tasa, String esperada) {
        assertEquals(esperada, EstrategiaTasaPorScore.ALTO.ajustar(new BigDecimal(tasa)).toPlainString());
    }

    @ParameterizedTest
    @CsvSource({"18.0000,18.0000", "36.0000,36.0000"})
    @DisplayName("R-07 tramo medio no cambia la tasa")
    void medio(String tasa, String esperada) {
        assertEquals(esperada, EstrategiaTasaPorScore.MEDIO.ajustar(new BigDecimal(tasa)).toPlainString());
    }

    @ParameterizedTest
    @CsvSource({"18.0000,20.0000", "999.5000,1.5000"})
    @DisplayName("R-07 tramo bajo suma 2 puntos (campo de 3 enteros)")
    void bajo(String tasa, String esperada) {
        assertEquals(esperada, EstrategiaTasaPorScore.BAJO.ajustar(new BigDecimal(tasa)).toPlainString());
    }
}
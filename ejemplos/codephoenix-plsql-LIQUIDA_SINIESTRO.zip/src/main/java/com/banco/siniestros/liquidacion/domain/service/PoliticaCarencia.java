package com.banco.siniestros.liquidacion.domain.service;

import com.banco.siniestros.liquidacion.domain.model.Poliza;

/** Strategy de días de carencia por producto. */
// Regla R-06 · LIQUIDA_SINIESTRO.sql:80-85
public final class PoliticaCarencia {

    private static final String SALUD = "SALUD";
    private static final int DIAS_SALUD = 90;
    private static final int DIAS_GENERAL = 30;

    public int diasCarencia(Poliza poliza) {
        return poliza.esProducto(SALUD) ? DIAS_SALUD : DIAS_GENERAL;
    }
}
package com.banco.creditos.amortizacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TotalesCreditoTest {

    private static final BigDecimal INTERES = new BigDecimal("1001.61");
    private static final BigDecimal SEGURO = new BigDecimal("30.04");
    private static final BigDecimal PAGADO = new BigDecimal("11031.65");

    @Test
    @DisplayName("R-16 · TC01 conserva totales de interés 1001.61, seguro 30.04 y pagado 11031.65")
    void conservaTotales() {
        TotalesCredito totales = new TotalesCredito(INTERES, SEGURO, PAGADO);

        assertEquals(INTERES, totales.interes());
        assertEquals(SEGURO, totales.seguro());
        assertEquals(PAGADO, totales.pagado());
    }

    @Test
    @DisplayName("R-16 · cualquier total nulo se rechaza")
    void rechazaNulos() {
        assertThrows(NullPointerException.class, () -> new TotalesCredito(null, SEGURO, PAGADO));
        assertThrows(NullPointerException.class, () -> new TotalesCredito(INTERES, null, PAGADO));
        assertThrows(NullPointerException.class, () -> new TotalesCredito(INTERES, SEGURO, null));
    }
}
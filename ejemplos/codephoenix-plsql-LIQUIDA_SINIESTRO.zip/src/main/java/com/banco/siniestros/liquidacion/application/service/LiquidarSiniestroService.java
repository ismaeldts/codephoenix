package com.banco.siniestros.liquidacion.application.service;

import com.banco.siniestros.liquidacion.application.port.in.LiquidarSiniestroUseCase;
import com.banco.siniestros.liquidacion.application.port.out.PagoSiniestroRepository;
import com.banco.siniestros.liquidacion.application.port.out.PolizaRepository;
import com.banco.siniestros.liquidacion.application.port.out.SiniestroRepository;
import com.banco.siniestros.liquidacion.domain.exception.PolizaNoEncontradaException;
import com.banco.siniestros.liquidacion.domain.exception.SiniestroNoExisteException;
import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.ResultadoLiquidacion;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.service.LiquidadorSiniestro;
import java.util.Objects;

/** Orquesta la liquidación: carga, valida existencia y estado, liquida, registra pago y actualiza. */
public final class LiquidarSiniestroService implements LiquidarSiniestroUseCase {

    private final SiniestroRepository siniestros;
    private final PolizaRepository polizas;
    private final PagoSiniestroRepository pagos;
    private final LiquidadorSiniestro liquidador;

    public LiquidarSiniestroService(SiniestroRepository siniestros, PolizaRepository polizas,
                                    PagoSiniestroRepository pagos, LiquidadorSiniestro liquidador) {
        this.siniestros = Objects.requireNonNull(siniestros, "siniestros");
        this.polizas = Objects.requireNonNull(polizas, "polizas");
        this.pagos = Objects.requireNonNull(pagos, "pagos");
        this.liquidador = Objects.requireNonNull(liquidador, "liquidador");
    }

    @Override
    public ResultadoLiquidacion liquidar(Long siniestroId) {
        Siniestro siniestro = cargarSiniestro(siniestroId);
        siniestro.exigirAbierto();
        Poliza poliza = cargarPoliza(siniestro);
        ResultadoLiquidacion resultado = liquidador.liquidar(siniestro, poliza);
        registrarPagoSiProcede(siniestro, resultado);
        actualizarSiniestro(siniestro, resultado);
        return resultado;
    }

    // Regla R-01 · LIQUIDA_SINIESTRO.sql:59-64
    private Siniestro cargarSiniestro(Long siniestroId) {
        return siniestros.buscarPorId(siniestroId).orElseThrow(SiniestroNoExisteException::new);
    }

    // Regla R-03 · LIQUIDA_SINIESTRO.sql:70-70 (se evalúa después de R-02)
    private Poliza cargarPoliza(Siniestro siniestro) {
        return polizas.buscarPorId(siniestro.polizaId()).orElseThrow(PolizaNoEncontradaException::new);
    }

    // Regla R-13 · LIQUIDA_SINIESTRO.sql:110-117 (R-11: sin INSERT cuando no hay pago)
    private void registrarPagoSiProcede(Siniestro siniestro, ResultadoLiquidacion resultado) {
        if (resultado.requierePago()) {
            pagos.insertar(PagoSiniestro.desde(siniestro.id(), resultado));
        }
    }

    // Regla R-14 · LIQUIDA_SINIESTRO.sql:120-124
    private void actualizarSiniestro(Siniestro siniestro, ResultadoLiquidacion resultado) {
        siniestros.actualizar(siniestro.conResultado(resultado));
    }
}
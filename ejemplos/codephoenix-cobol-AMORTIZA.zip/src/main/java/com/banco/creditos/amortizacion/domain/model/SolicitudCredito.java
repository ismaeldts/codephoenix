package com.banco.creditos.amortizacion.domain.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Registro de entrada ya interpretado (WS-ENTRADA, AMORTIZA.cbl:26-30).
 * Monto con escala 2 (9(9)V99), tasa anual con escala 4 (9(3)V9(4)).
 * Los rangos de negocio NO se validan aquí: los evalúan las Specifications en orden.
 */
// Regla R-01 · AMORTIZA.cbl:26-30
public record SolicitudCredito(BigDecimal monto, BigDecimal tasaAnual, int plazo, int score) {

    public SolicitudCredito {
        Objects.requireNonNull(monto, "monto");
        Objects.requireNonNull(tasaAnual, "tasaAnual");
        if (monto.signum() < 0 || tasaAnual.signum() < 0 || plazo < 0 || score < 0) {
            throw new IllegalArgumentException("Los campos del registro son numéricos sin signo");
        }
        monto = monto.setScale(2, RoundingMode.DOWN);
        tasaAnual = tasaAnual.setScale(4, RoundingMode.DOWN);
    }
}
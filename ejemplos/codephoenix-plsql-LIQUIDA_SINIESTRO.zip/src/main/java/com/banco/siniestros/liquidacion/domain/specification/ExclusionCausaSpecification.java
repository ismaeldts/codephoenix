package com.banco.siniestros.liquidacion.domain.specification;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;

// Regla R-08 · LIQUIDA_SINIESTRO.sql:90-94
public final class ExclusionCausaSpecification implements RechazoSpecification {

    private static final String GUERRA = "GUERRA";
    private static final String DOLO = "DOLO";
    private static final String COMPETENCIA = "COMPETENCIA";
    private static final String AUTO = "AUTO";

    @Override
    public boolean seRechaza(Siniestro siniestro, Poliza poliza) {
        return esExclusionGeneral(siniestro) || esExclusionDeAutomoviles(siniestro, poliza);
    }

    private boolean esExclusionGeneral(Siniestro siniestro) {
        return siniestro.causaEs(GUERRA) || siniestro.causaEs(DOLO);
    }

    private boolean esExclusionDeAutomoviles(Siniestro siniestro, Poliza poliza) {
        return poliza.esProducto(AUTO) && siniestro.causaEs(COMPETENCIA);
    }
}
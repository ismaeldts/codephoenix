package com.banco.siniestros.liquidacion.domain.specification;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.service.PoliticaCarencia;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class CarenciaSpecificationTest {

    private final CarenciaSpecification spec = new CarenciaSpecification(new PoliticaCarencia());

    private static Poliza poliza(String producto) {
        return new Poliza(1004L, producto, "VIGENTE", LocalDateTime.of(2023, 1, 1, 0, 0),
                new BigDecimal("50000"), new BigDecimal("500"), BigDecimal.ZERO);
    }

    private static Siniestro siniestro(String fecha) {
        return new Siniestro(7L, 1004L, LocalDateTime.parse(fecha),
                new BigDecimal("5000"), "COLISION", "ABIERTO", null);
    }

    @DisplayName("R-07 comparación estricta con hora sobre carencia de 30 y 90 días")
    @ParameterizedTest
    @CsvSource({
            "AUTO,2023-01-30T00:00:00,true",
            "AUTO,2023-01-30T23:59:59,true",
            "AUTO,2023-01-31T00:00:00,false",
            "AUTO,2023-06-01T00:00:00,false",
            "HOGAR,2023-01-30T00:00:00,true",
            "SALUD,2023-03-31T00:00:00,true",
            "SALUD,2023-04-01T00:00:00,false"
    })
    void carencia(String producto, String ocurrencia, boolean esperado) {
        assertEquals(esperado, spec.seRechaza(siniestro(ocurrencia), poliza(producto)));
    }

    @DisplayName("R-07 la política de carencia es obligatoria")
    @Test
    void politicaObligatoria() {
        assertThrows(NullPointerException.class, () -> new CarenciaSpecification(null));
    }
}
package com.banco.siniestros.liquidacion.domain.exception;

// Regla R-01 · LIQUIDA_SINIESTRO.sql:59-64
public final class SiniestroNoExisteException extends LiquidacionException {

    public SiniestroNoExisteException() {
        super("E01", -20010, "SINIESTRO NO EXISTE");
    }
}
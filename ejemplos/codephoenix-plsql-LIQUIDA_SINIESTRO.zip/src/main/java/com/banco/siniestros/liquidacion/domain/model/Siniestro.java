package com.banco.siniestros.liquidacion.domain.model;

import com.banco.siniestros.liquidacion.domain.exception.SiniestroYaProcesadoException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.Objects;

/** Agregado Siniestro. Inmutable: aplicar un resultado produce una nueva instancia. */
public record Siniestro(
        long id,
        long polizaId,
        LocalDateTime fechaOcurrencia,
        BigDecimal montoReclamado,
        String causa,
        String estado,
        BigDecimal montoLiquidado) {

    private static final int ESCALA = 2;
    private static final String ABIERTO = "ABIERTO";

    public Siniestro {
        Objects.requireNonNull(fechaOcurrencia, "fechaOcurrencia");
        Objects.requireNonNull(montoReclamado, "montoReclamado");
        montoReclamado = montoReclamado.setScale(ESCALA, RoundingMode.HALF_UP);
        if (montoLiquidado != null) {
            montoLiquidado = montoLiquidado.setScale(ESCALA, RoundingMode.HALF_UP);
        }
    }

    // Regla R-02 · LIQUIDA_SINIESTRO.sql:66-68
    // Con estado NULL la comparación Oracle es desconocida y no se lanza el error.
    public void exigirAbierto() {
        if (estado != null && !ABIERTO.equals(estado)) {
            throw new SiniestroYaProcesadoException();
        }
    }

    // Regla R-14 · LIQUIDA_SINIESTRO.sql:120-124
    public Siniestro conResultado(ResultadoLiquidacion resultado) {
        return new Siniestro(id, polizaId, fechaOcurrencia, montoReclamado, causa,
                resultado.estado().name(), resultado.montoPagar());
    }

    public boolean causaEs(String otraCausa) {
        return Objects.equals(causa, otraCausa);
    }
}
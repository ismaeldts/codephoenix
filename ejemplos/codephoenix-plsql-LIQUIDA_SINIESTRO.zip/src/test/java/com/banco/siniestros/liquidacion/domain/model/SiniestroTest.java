package com.banco.siniestros.liquidacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.banco.siniestros.liquidacion.domain.exception.SiniestroYaProcesadoException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class SiniestroTest {

    private static final LocalDateTime FECHA = LocalDateTime.of(2023, 6, 1, 0, 0, 0);

    private static Siniestro siniestro(String estado, String causa, BigDecimal liquidado) {
        return new Siniestro(5L, 1002L, FECHA, new BigDecimal("5000"), causa, estado, liquidado);
    }

    @DisplayName("R-02 siniestro ABIERTO no lanza error")
    @Test
    void abiertoNoLanza() {
        assertDoesNotThrow(() -> siniestro("ABIERTO", "COLISION", null).exigirAbierto());
    }

    @DisplayName("R-02 estado distinto de ABIERTO falla con -20011")
    @ParameterizedTest
    @CsvSource({"LIQUIDADO", "RECHAZADO", "SIN_PAGO"})
    void noAbiertoLanza(String estado) {
        SiniestroYaProcesadoException ex = assertThrows(SiniestroYaProcesadoException.class,
                () -> siniestro(estado, "COLISION", null).exigirAbierto());
        assertEquals(-20011, ex.sqlCode());
        assertEquals("E02", ex.codigo());
        assertEquals("SINIESTRO YA PROCESADO", ex.getMessage());
    }

    @DisplayName("R-02 estado NULL es comparación desconocida y no lanza error")
    @Test
    void estadoNuloNoLanza() {
        assertDoesNotThrow(() -> siniestro(null, "COLISION", null).exigirAbierto());
    }

    @DisplayName("R-14 conResultado guarda estado y monto liquidado (TC05)")
    @Test
    void conResultadoRechazado() {
        Siniestro actualizado = siniestro("ABIERTO", "COLISION", null)
                .conResultado(ResultadoLiquidacion.rechazado());
        assertEquals("RECHAZADO", actualizado.estado());
        assertEquals(0, BigDecimal.ZERO.compareTo(actualizado.montoLiquidado()));
        assertEquals(2, actualizado.montoLiquidado().scale());
        assertEquals(5L, actualizado.id());
        assertEquals(1002L, actualizado.polizaId());
    }

    @DisplayName("R-14 conResultado liquidado guarda el monto (TC08)")
    @Test
    void conResultadoLiquidado() {
        Siniestro actualizado = siniestro("ABIERTO", "COLISION", null)
                .conResultado(ResultadoLiquidacion.liquidado(new BigDecimal("4500.00"), BigDecimal.ZERO));
        assertEquals("LIQUIDADO", actualizado.estado());
        assertEquals("4500", actualizado.montoLiquidado().stripTrailingZeros().toPlainString());
    }

    @DisplayName("R-08 causaEs compara con null seguro")
    @Test
    void causaEs() {
        assertTrue(siniestro("ABIERTO", "GUERRA", null).causaEs("GUERRA"));
        assertFalse(siniestro("ABIERTO", "GUERRA", null).causaEs("DOLO"));
        assertFalse(siniestro("ABIERTO", null, null).causaEs("DOLO"));
    }

    @DisplayName("R-09 el constructor normaliza importes a escala 2")
    @Test
    void escalaImportes() {
        Siniestro s = siniestro("LIQUIDADO", "COLISION", new BigDecimal("4000"));
        assertEquals(2, s.montoReclamado().scale());
        assertEquals(2, s.montoLiquidado().scale());
        assertNull(siniestro("ABIERTO", "COLISION", null).montoLiquidado());
    }
}
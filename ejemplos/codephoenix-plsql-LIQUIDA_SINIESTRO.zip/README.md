# Migración de LIQUIDA_SINIESTRO.sql — Demo siniestro

Paquete generado por **CodePhoenix**, copiloto de modernización de código legacy.

| Indicador | Resultado |
|---|---|
| Reglas de negocio aprobadas | 14 (especificación v1) |
| Equivalencia legacy vs. moderno | 19/19 casos idénticos |
| Pruebas unitarias | 129/129 exitosas |
| Escenarios BDD (Gherkin ejecutable) | 31/31 aprobados |
| Cobertura | 97.0% líneas / 96.3% ramas |
| Hallazgos bloqueantes / críticos | 0 / 0 |
| Vulnerabilidades críticas (SAST) | 0 (SpotBugs 4.8.6 + FindSecBugs 1.13.0) |

## Ejecutar con un solo comando

```bash
docker build -t migracion . && docker run -i --rm migracion < reports/golden-master/TC05.in
```

La construcción de la imagen compila el código y ejecuta las pruebas unitarias y los escenarios
Gherkin; si alguno falla, la imagen no se construye. Alternativa sin Docker: `gradle test run`.

> En Windows usa Git Bash o `cmd`: Windows PowerShell 5.1 antepone una marca BOM al texto que
> envía por tubería y la entrada llega con un carácter extra (igual que le ocurriría al original).

Clase de entrada: `com.banco.siniestros.liquidacion.adapter.in.cli.LegacyCliAdapter` (lee la entrada con el formato del programa legacy y produce la misma salida).

## Contenido

| Ruta | Contenido |
|---|---|
| `src/main/java` | Código moderno (arquitectura hexagonal) |
| `src/test/java` | Pruebas unitarias JUnit 5 y pasos de Cucumber |
| `src/test/resources/features` | Especificación ejecutable: escenarios Gherkin etiquetados por regla |
| `legacy/` | Programa original (con datos sensibles enmascarados) y, si aplica, su esquema |
| `docs/REGLAS_DE_NEGOCIO.md` | Catálogo de reglas aprobado, con escenarios Gherkin |
| `docs/TRAZABILIDAD.md` | Matriz regla → líneas legacy → código moderno |
| `docs/ARQUITECTURA.md`, `docs/adr/`, `docs/openapi.yaml` | Diseño, decisiones y contrato REST |
| `reports/` | Equivalencia, calidad, seguridad, pruebas, cobertura, auditoría de IA y Golden Master |
| `INFORME_EJECUTIVO.md` | Resumen de una página para negocio |

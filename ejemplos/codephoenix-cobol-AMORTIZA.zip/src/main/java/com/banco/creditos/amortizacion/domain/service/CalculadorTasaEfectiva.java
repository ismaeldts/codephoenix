package com.banco.creditos.amortizacion.domain.service;

import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 2000-AJUSTAR-TASA: ajuste por score y, después, tope de usura.
 */
public final class CalculadorTasaEfectiva {

    private static final BigDecimal TASA_USURA = new BigDecimal("36.0000");

    // Regla R-06 · AMORTIZA.cbl:120-126
    // Regla R-07 · AMORTIZA.cbl:127-131
    // Regla R-08 · AMORTIZA.cbl:132-134
    public BigDecimal calcular(SolicitudCredito solicitud) {
        BigDecimal ajustada = EstrategiaTasaPorScore.para(solicitud.score())
                .ajustar(solicitud.tasaAnual());
        return aplicarTopeUsura(ajustada);
    }

    // Regla R-08 · AMORTIZA.cbl:132-134
    private static BigDecimal aplicarTopeUsura(BigDecimal tasa) {
        BigDecimal resultado = tasa.compareTo(TASA_USURA) > 0 ? TASA_USURA : tasa;
        return resultado.setScale(4, RoundingMode.DOWN);
    }
}
package com.banco.creditos.amortizacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.banco.creditos.amortizacion.domain.model.CodigoError;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;
import com.banco.creditos.amortizacion.domain.model.SolicitudInvalidaException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;

class SolicitudFactoryTest {

    private final SolicitudFactory factory = new SolicitudFactory();

    @Test
    @DisplayName("R-01 registro válido TC01 se decodifica con decimales implícitos")
    void registroValido() {
        SolicitudCredito s = factory.desdeRegistro("000010000000180000012700");
        assertEquals("10000.00", s.monto().toPlainString());
        assertEquals("18.0000", s.tasaAnual().toPlainString());
        assertEquals(12, s.plazo());
        assertEquals(700, s.score());
    }

    @Test
    @DisplayName("R-01 registro más largo se trunca a 24 posiciones")
    void registroLargo() {
        SolicitudCredito s = factory.desdeRegistro("000001000000180000006700999");
        assertEquals("1000.00", s.monto().toPlainString());
        assertEquals(6, s.plazo());
        assertEquals(700, s.score());
    }

    @ParameterizedTest
    @CsvSource({
        "ABCDEFGHIJK0180000012700",
        "00001000000180000012700",
        "0000100000018000001 700"
    })
    @DisplayName("R-01 registro no numérico o corto se rechaza con E00")
    void registroInvalido(String registro) {
        SolicitudInvalidaException ex =
                assertThrows(SolicitudInvalidaException.class, () -> factory.desdeRegistro(registro));
        assertEquals(CodigoError.E00, ex.codigoError());
    }

    @ParameterizedTest
    @NullAndEmptySource
    @DisplayName("R-01 registro nulo o vacío se rechaza con E00")
    void registroNuloOVacio(String registro) {
        SolicitudInvalidaException ex =
                assertThrows(SolicitudInvalidaException.class, () -> factory.desdeRegistro(registro));
        assertEquals(CodigoError.E00, ex.codigoError());
    }
}
package com.banco.siniestros.liquidacion.domain.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PolizaTest {

    private static final LocalDateTime INICIO = LocalDateTime.of(2023, 1, 1, 0, 0);

    private static Poliza poliza(String producto, String estado) {
        return new Poliza(1002, producto, estado, INICIO, new BigDecimal("50000"),
                new BigDecimal("500"), new BigDecimal("10"));
    }

    @ParameterizedTest
    @CsvSource({"VIGENTE,false", "SUSPENDIDA,true", "CANCELADA,true"})
    @DisplayName("R-05 la póliza no vigente se rechaza (TC05 SUSPENDIDA, TC06 CANCELADA)")
    void vigencia(String estado, boolean noVigente) {
        assertEquals(noVigente, poliza("AUTO", estado).noEstaVigente());
    }

    @Test
    @DisplayName("R-05 estado NULL: comparación desconocida, no se rechaza")
    void estadoNulo() {
        assertFalse(poliza("AUTO", null).noEstaVigente());
    }

    @ParameterizedTest
    @CsvSource({"AUTO,AUTO,true", "SALUD,AUTO,false", "HOGAR,SALUD,false"})
    @DisplayName("R-06 identificación del producto de la póliza")
    void producto(String tipo, String consulta, boolean esperado) {
        assertEquals(esperado, poliza(tipo, "VIGENTE").esProducto(consulta));
    }

    @Test
    @DisplayName("R-06 producto NULL no coincide con ningún producto")
    void productoNulo() {
        assertFalse(poliza(null, "VIGENTE").esProducto("AUTO"));
        assertTrue(poliza("AUTO", "VIGENTE").esProducto("AUTO"));
    }

    @Test
    @DisplayName("R-09 importes y coaseguro se normalizan a escala 2 (TC05)")
    void escalas() {
        Poliza p = poliza("AUTO", "VIGENTE");
        assertEquals(new BigDecimal("50000.00"), p.sumaAsegurada());
        assertEquals(new BigDecimal("500.00"), p.deducible());
        assertEquals(new BigDecimal("10.00"), p.porcCoaseguro());
    }

    @Test
    @DisplayName("R-07 los datos obligatorios nulos se rechazan")
    void rechazaNulos() {
        BigDecimal v = BigDecimal.ONE;
        assertThrows(NullPointerException.class, () -> new Poliza(1, "AUTO", "VIGENTE", null, v, v, v));
        assertThrows(NullPointerException.class, () -> new Poliza(1, "AUTO", "VIGENTE", INICIO, null, v, v));
        assertThrows(NullPointerException.class, () -> new Poliza(1, "AUTO", "VIGENTE", INICIO, v, null, v));
        assertThrows(NullPointerException.class, () -> new Poliza(1, "AUTO", "VIGENTE", INICIO, v, v, null));
    }
}
# language: es
Característica: Generación de la tabla de amortización
  Como auditor de operaciones
  Quiero verificar interés, seguro, última cuota, total del periodo y acumulados
  Para asegurar que la tabla coincide con la salida del programa legacy

  @R-12
  Esquema del escenario: El interés del periodo es el saldo por la tasa mensual redondeado a 2 decimales
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces en el periodo <periodo> el interés es "<interes>"

    Ejemplos:
      | periodo | interes |
      | 1       | 150.00  |
      | 2       | 138.50  |
      | 3       | 126.82  |
      | 4       | 114.97  |

  @R-13
  Esquema del escenario: El seguro se calcula sobre el saldo previo a la amortización
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces en el periodo <periodo> el seguro es "<seguro>"

    Ejemplos:
      | periodo | seguro |
      | 1       | 4.50   |
      | 2       | 4.15   |
      | 3       | 3.80   |
      | 12      | 0.41   |

  @R-14
  Escenario: Los periodos intermedios usan la cuota fija y amortizan cuota menos interés
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces en el periodo 1 la cuota es "916.80"
    Y en el periodo 1 la amortización es "766.80"

  @R-14
  Escenario: La última cuota amortiza todo el saldo restante
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces en el periodo 12 la cuota es "916.81"
    Y en el periodo 12 el interés es "13.55"
    Y en el periodo 12 la amortización es "903.26"
    Y en el periodo 12 el saldo es "0.00"

  @R-14
  Escenario: Última cuota de un crédito de 6 meses por 1000,00
    Dado una solicitud con monto "1000.00", tasa anual "18.0000", plazo 6 y score 700
    Cuando se simula el crédito
    Entonces en el periodo 6 la cuota es "175.50"
    Y en el periodo 6 el interés es "2.59"
    Y en el periodo 6 la amortización es "172.91"
    Y en el periodo 6 el saldo es "0.00"

  @R-15
  Esquema del escenario: El total del periodo es la cuota más el seguro y el saldo baja por la amortización
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces en el periodo <periodo> el total a pagar es "<total>"
    Y en el periodo <periodo> el saldo es "<saldo>"

    Ejemplos:
      | periodo | total  | saldo   |
      | 1       | 921.30 | 9233.20 |
      | 2       | 920.95 | 8454.90 |
      | 3       | 920.60 | 7664.92 |
      | 4       | 920.25 | 6863.09 |
      | 12      | 917.22 | 0.00    |

  @R-16
  Escenario: Totales acumulados del crédito de 10000,00 a 12 meses
    Dado una solicitud con monto "10000.00", tasa anual "18.0000", plazo 12 y score 700
    Cuando se simula el crédito
    Entonces el total de intereses es "1001.61"
    Y el total de seguros es "30.04"
    Y el total pagado es "11031.65"

  @R-16
  Escenario: Totales acumulados del crédito de 1000,00 a 6 meses
    Dado una solicitud con monto "1000.00", tasa anual "18.0000", plazo 6 y score 700
    Cuando se simula el crédito
    Entonces el total de intereses es "53.15"
    Y el total de seguros es "1.59"
    Y el total pagado es "1054.74"

  @R-12 @R-13 @R-14 @R-15 @R-16
  Escenario: Salida legacy del caso nominal línea por línea
    Dado el registro de entrada "000010000000180000012700"
    Cuando se procesa el registro de entrada
    Entonces la salida tiene 14 líneas
    Y la línea de salida 1 es "HDR| 18.0000| 12|      916.80"
    Y la línea de salida 2 es "DET|  1|      916.80|      150.00|      766.80|      4.50|      921.30|     9233.20"
    Y la línea de salida 3 es "DET|  2|      916.80|      138.50|      778.30|      4.15|      920.95|     8454.90"
    Y la línea de salida 4 es "DET|  3|      916.80|      126.82|      789.98|      3.80|      920.60|     7664.92"
    Y la línea de salida 5 es "DET|  4|      916.80|      114.97|      801.83|      3.45|      920.25|     6863.09"
    Y la línea de salida 13 es "DET| 12|      916.81|       13.55|      903.26|      0.41|      917.22|        0.00"
    Y la línea de salida 14 es "TOT|       1001.61|         30.04|      11031.65"

  @R-11 @R-14 @R-16
  Escenario: Salida legacy del caso con monto y plazo mínimos
    Dado el registro de entrada "000001000000180000006700"
    Cuando se procesa el registro de entrada
    Entonces la salida tiene 8 líneas
    Y la línea de salida 1 es "HDR| 18.0000|  6|      175.53"
    Y la línea de salida 2 es "DET|  1|      175.53|       15.00|      160.53|      0.45|      175.98|      839.47"
    Y la línea de salida 3 es "DET|  2|      175.53|       12.59|      162.94|      0.38|      175.91|      676.53"
    Y la línea de salida 4 es "DET|  3|      175.53|       10.15|      165.38|      0.30|      175.83|      511.15"
    Y la línea de salida 5 es "DET|  4|      175.53|        7.67|      167.86|      0.23|      175.76|      343.29"
    Y la línea de salida 6 es "DET|  5|      175.53|        5.15|      170.38|      0.15|      175.68|      172.91"
    Y la línea de salida 7 es "DET|  6|      175.50|        2.59|      172.91|      0.08|      175.58|        0.00"
    Y la línea de salida 8 es "TOT|         53.15|          1.59|       1054.74"
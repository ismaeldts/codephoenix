package com.banco.creditos.amortizacion.domain.model;

/**
 * Excepción de dominio: la solicitud no es admisible; lleva el código de negocio (E00-E04).
 */
// Regla R-01 · AMORTIZA.cbl:90-94
public final class SolicitudInvalidaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final CodigoError codigoError;

    public SolicitudInvalidaException(CodigoError codigoError) {
        super(codigoError.codigo() + " " + codigoError.mensaje());
        this.codigoError = codigoError;
    }

    public CodigoError codigoError() {
        return codigoError;
    }
}
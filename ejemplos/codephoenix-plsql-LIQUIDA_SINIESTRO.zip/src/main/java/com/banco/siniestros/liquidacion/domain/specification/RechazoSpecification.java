package com.banco.siniestros.liquidacion.domain.specification;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;

/** Specification de elegibilidad: devuelve true cuando el siniestro debe rechazarse. */
public interface RechazoSpecification {

    boolean seRechaza(Siniestro siniestro, Poliza poliza);
}
package com.banco.siniestros.liquidacion.adapter.in.cli;

import com.banco.siniestros.liquidacion.adapter.out.persistence.PagoSiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.PolizaRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.adapter.out.persistence.SiniestroRepositoryEnMemoria;
import com.banco.siniestros.liquidacion.domain.model.PagoSiniestro;
import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/** Carga las filas iniciales (ROW) en los repositorios en memoria. */
final class CargadorFilas {

    private final PolizaRepositoryEnMemoria polizas;
    private final SiniestroRepositoryEnMemoria siniestros;
    private final PagoSiniestroRepositoryEnMemoria pagos;

    CargadorFilas(PolizaRepositoryEnMemoria polizas, SiniestroRepositoryEnMemoria siniestros,
                  PagoSiniestroRepositoryEnMemoria pagos) {
        this.polizas = polizas;
        this.siniestros = siniestros;
        this.pagos = pagos;
    }

    void cargar(List<EntradaCaracterizacion.Fila> filas) {
        for (EntradaCaracterizacion.Fila fila : filas) {
            cargarFila(fila);
        }
    }

    private void cargarFila(EntradaCaracterizacion.Fila fila) {
        switch (fila.tabla()) {
            case "POLIZAS" -> polizas.agregar(poliza(fila.columnas()));
            case "SINIESTROS" -> siniestros.agregar(siniestro(fila.columnas()));
            case "PAGOS_SINIESTRO" -> pagos.insertar(pago(fila.columnas()));
            default -> { /* tabla fuera del alcance del procedimiento: se ignora */ }
        }
    }

    private static Poliza poliza(Map<String, String> c) {
        BigDecimal porcentaje = ConversorValores.decimal(c.get("PORC_COASEGURO"));
        return new Poliza(
                ConversorValores.entero(c.get("POLIZA_ID")),
                ConversorValores.texto(c.get("TIPO_PRODUCTO")),
                ConversorValores.texto(c.get("ESTADO")),
                ConversorValores.fecha(c.get("FECHA_INICIO")),
                ConversorValores.decimal(c.get("SUMA_ASEGURADA")),
                ConversorValores.decimal(c.get("DEDUCIBLE")),
                porcentaje == null ? BigDecimal.ZERO : porcentaje);
    }

    private static Siniestro siniestro(Map<String, String> c) {
        return new Siniestro(
                ConversorValores.entero(c.get("SINIESTRO_ID")),
                ConversorValores.entero(c.get("POLIZA_ID")),
                ConversorValores.fecha(c.get("FECHA_OCURRENCIA")),
                ConversorValores.decimal(c.get("MONTO_RECLAMADO")),
                ConversorValores.texto(c.get("CAUSA")),
                ConversorValores.texto(c.get("ESTADO")),
                ConversorValores.decimal(c.get("MONTO_LIQUIDADO")));
    }

    private static PagoSiniestro pago(Map<String, String> c) {
        return new PagoSiniestro(
                ConversorValores.entero(c.get("SINIESTRO_ID")),
                ConversorValores.decimal(c.get("MONTO")),
                ConversorValores.decimal(c.get("RETENCION")),
                ConversorValores.decimal(c.get("NETO")));
    }
}
package com.banco.creditos.amortizacion.application.port.in;

import com.banco.creditos.amortizacion.domain.model.ResultadoSimulacion;
import com.banco.creditos.amortizacion.domain.model.SolicitudCredito;

/**
 * Puerto de entrada: simula la amortización de una solicitud ya interpretada.
 */
public interface SimularAmortizacionUseCase {

    ResultadoSimulacion simular(SolicitudCredito solicitud);
}
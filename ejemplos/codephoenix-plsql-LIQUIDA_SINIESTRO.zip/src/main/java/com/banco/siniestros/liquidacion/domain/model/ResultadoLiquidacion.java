package com.banco.siniestros.liquidacion.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * Resultado inmutable de la liquidación.
 * La retención es cero cuando no aplica.
 */
// Regla R-04 · LIQUIDA_SINIESTRO.sql:72-73
public record ResultadoLiquidacion(EstadoLiquidacion estado, BigDecimal montoPagar, BigDecimal retencion) {

    public ResultadoLiquidacion {
        Objects.requireNonNull(estado, "estado");
        Objects.requireNonNull(montoPagar, "montoPagar");
        Objects.requireNonNull(retencion, "retencion");
    }

    // Regla R-04 · LIQUIDA_SINIESTRO.sql:72-73
    public static ResultadoLiquidacion rechazado() {
        return new ResultadoLiquidacion(EstadoLiquidacion.RECHAZADO, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    // Regla R-11 · LIQUIDA_SINIESTRO.sql:108-109
    public static ResultadoLiquidacion sinPago() {
        return new ResultadoLiquidacion(EstadoLiquidacion.SIN_PAGO, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    // Regla R-13 · LIQUIDA_SINIESTRO.sql:110-117
    public static ResultadoLiquidacion liquidado(BigDecimal monto, BigDecimal retencion) {
        return new ResultadoLiquidacion(EstadoLiquidacion.LIQUIDADO, monto, retencion);
    }

    // Regla R-13 · LIQUIDA_SINIESTRO.sql:110-117
    public boolean requierePago() {
        return estado == EstadoLiquidacion.LIQUIDADO;
    }
}
package com.banco.siniestros.liquidacion.domain.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PoliticaCarenciaTest {

    private final PoliticaCarencia politica = new PoliticaCarencia();

    private static Poliza poliza(String producto) {
        return new Poliza(1L, producto, "VIGENTE", LocalDateTime.of(2023, 1, 1, 0, 0),
                new BigDecimal("1000"), BigDecimal.ZERO, BigDecimal.ZERO);
    }

    @DisplayName("R-06 SALUD 90 días y los demás productos 30")
    @ParameterizedTest
    @CsvSource({"SALUD,90", "AUTO,30", "HOGAR,30", "VIDA,30"})
    void dias(String producto, int esperado) {
        assertEquals(esperado, politica.diasCarencia(poliza(producto)));
    }

    @DisplayName("R-06 producto NULL usa 30 días")
    @Test
    void productoNulo() {
        assertEquals(30, politica.diasCarencia(poliza(null)));
    }
}
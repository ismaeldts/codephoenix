package com.banco.siniestros.liquidacion.adapter.in.cli;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Conversión de los valores textuales del contrato de caracterización. */
final class ConversorValores {

    static final String NULO = "\\N";
    static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final int LONGITUD_SOLO_FECHA = 10;

    private ConversorValores() {
    }

    /** `\N` y la cadena vacía son NULL (en Oracle '' es NULL). */
    static String texto(String crudo) {
        if (crudo == null || crudo.isEmpty() || NULO.equals(crudo)) {
            return null;
        }
        return crudo;
    }

    static BigDecimal decimal(String crudo) {
        String texto = texto(crudo);
        return texto == null ? null : new BigDecimal(texto.trim());
    }

    /** Devuelve null si el valor es NULL o no es un entero representable (nunca coincidiría con una clave). */
    static Long entero(String crudo) {
        BigDecimal valor = decimal(crudo);
        if (valor == null) {
            return null;
        }
        try {
            return valor.toBigIntegerExact().longValueExact();
        } catch (ArithmeticException noEntero) {
            return null;
        }
    }

    static LocalDateTime fecha(String crudo) {
        String texto = texto(crudo);
        if (texto == null) {
            return null;
        }
        String limpio = texto.trim();
        if (limpio.length() == LONGITUD_SOLO_FECHA) {
            return LocalDate.parse(limpio).atStartOfDay();
        }
        return LocalDateTime.parse(limpio, FORMATO_FECHA);
    }
}
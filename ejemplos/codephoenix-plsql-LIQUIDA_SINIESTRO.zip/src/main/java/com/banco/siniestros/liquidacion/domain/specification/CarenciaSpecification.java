package com.banco.siniestros.liquidacion.domain.specification;

import com.banco.siniestros.liquidacion.domain.model.Poliza;
import com.banco.siniestros.liquidacion.domain.model.Siniestro;
import com.banco.siniestros.liquidacion.domain.service.PoliticaCarencia;
import java.util.Objects;

// Regla R-07 · LIQUIDA_SINIESTRO.sql:86-88
public final class CarenciaSpecification implements RechazoSpecification {

    private final PoliticaCarencia politicaCarencia;

    public CarenciaSpecification(PoliticaCarencia politicaCarencia) {
        this.politicaCarencia = Objects.requireNonNull(politicaCarencia, "politicaCarencia");
    }

    // Comparación estricta con hora: la ocurrencia igual al fin de carencia sí está cubierta.
    @Override
    public boolean seRechaza(Siniestro siniestro, Poliza poliza) {
        int dias = politicaCarencia.diasCarencia(poliza);
        return siniestro.fechaOcurrencia().isBefore(poliza.fechaInicio().plusDays(dias));
    }
}